"""compare_python_octave.py - مقایسه‌ی نتایج مرجع Octave/Stabil با مدل پایتون (بعد از اجرای run_reference_octave.m)
اجرا:  python compare_python_octave.py   (CSVهای Octave باید کنار این فایل باشند)"""
import os, sys, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "06_Python_Virtual_Lab"))
from kw51lab.analysis.core import Lab, PRESETS
from kw51lab.train.configurations import REFERENCE_PASSAGES, desiro_units

lab_b = Lab(**PRESETS["پیش از مقاوم‌سازی (modal_analysis.m)"])
fpy, _, _ = lab_b.modal(50)
fp = os.path.join(HERE, "octave_modal_before.csv")
if os.path.exists(fp):
    ref = np.loadtxt(fp, delimiter=",")[:, 1]
    n = min(len(ref), len(fpy))
    err = 100 * (fpy[:n] / ref[:n] - 1)
    print("Modal (before retrofit): max |freq diff| over %d modes = %.3f %%  (first 10: %s)" % (n, np.abs(err).max(), np.round(err[:10], 3)))
else:
    print("octave_modal_before.csv not found - run run_reference_octave.m first")
lab_a = Lab(**PRESETS["پس از مقاوم‌سازی (simulate_trainpassage.m)"])
tr = desiro_units(1)
for ip, (name, ps) in enumerate(REFERENCE_PASSAGES.items(), start=1):
    fp = os.path.join(HERE, f"octave_passage{ip}_uz_mid.csv")
    if not os.path.exists(fp):
        print(f"passage {ip}: reference CSV missing"); continue
    d = np.loadtxt(fp, delimiter=","); t = d[:, 0]
    v0 = ps["direction"] * ps["v0"]; a0 = ps["a"]
    uz = []
    for tk in t:
        xf = ps["x0_front"] + v0 * tk + a0 * tk**2 / 2
        xa = xf - np.sign(v0) * tr.axle_pos
        P = lab_a.ld.load_vector(ps["track"], xa, tr.axle_loads, abs(v0 + a0 * tk))
        uz.append(lab_a.response(lab_a.solve(P), "girderA", 58.158, "uz"))
    uz = np.array(uz)
    print(f"passage {ip}: octave min {d[:,1].min()*1e3:.4f} mm | python min {uz.min()*1e3:.4f} mm | max|diff| {np.abs(uz-d[:,1]).max()*1e3:.4f} mm")
