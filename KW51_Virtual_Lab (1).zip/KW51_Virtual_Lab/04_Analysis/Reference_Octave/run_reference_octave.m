% run_reference_octave.m
% بازتولید مثال‌های رسمی KW51 در GNU Octave + Stabil و ذخیره‌ی نتایج مرجع در فایل CSV
% (خروجی‌ها بعداً با نتایج پایتون مقایسه می‌شوند:  python compare_python_octave.py)
%
% روش اجرا:
%   1) پوشه‌ی جاری Octave = 00_Original_Files/KW51_FE_Model  (حاوی model_kw51.m ، xrail_2_P.m ، select_sensors.m)
%   2) مسیر Stabil را در خط addpath زیر اصلاح کنید
%   3) run('<مسیر>/run_reference_octave.m')   - فایل‌های CSV کنار همین اسکریپت ذخیره می‌شوند
%
% نکته‌ها: توابع toolbox/*.p (newfig, get_lims) فایل رمزگذاری‌شده‌ی MATLAB هستند و در Octave اجرا نمی‌شوند؛
% این اسکریپت عمداً هیچ نموداری رسم نمی‌کند (plot_elem=0). هر خطای سازگاری دیگر باید در گزارش بازتولید ثبت شود.
clear all; clc;
STABIL_PATH = 'C:/stabil-3.1';            % <-- اصلاح شود
addpath(genpath(STABIL_PATH));
outdir = fileparts(mfilename('fullpath'));
if isempty(outdir), outdir = pwd; end

%% A) مودال - پیش از مقاوم‌سازی (modal_analysis.m)
[Kr,Mr,T,Nodes,Types,Sections,Materials,Elements,DOF] = ...
    model_kw51(1, 1.1, NaN, 0.06, 0.78, 1, 0, 0, []);
fprintf('Nodes: %d, DOF: %d, reduced DOF: %d\n', size(Nodes,1), numel(DOF), size(Kr,1));
[phir, omega] = eigfem(Kr, Mr, 50);
f = omega(:)/2/pi;
dlmwrite(fullfile(outdir,'octave_modal_before.csv'), [(1:50)', f], 'precision', '%.8f');
dlmwrite(fullfile(outdir,'octave_model_size.csv'), [size(Nodes,1), numel(DOF), size(Kr,1)]);

%% B) عبور شبه‌استاتیکی (simulate_trainpassage.m) - عبور ۱ و ۲، تکیه‌گاه طبق نقشه (fixed=0)
[Kr1,Mr1,T1,Nodes,Types,Sections,Materials,Elements,DOF] = ...
    model_kw51(1, 1.0833, 0, 0.08, 0.88, 0, 0, 1, []);
AL  = [132.0,131.4,116.8,116.4,94.7,94.6,94.6,94.7,116.4,116.8,131.4,132.0]*1e3;
dxa = [0.0,2.3,18.6,20.9,26.1,28.4,44.7,47.0,52.2,54.5,70.8,73.1].';
tracks = {'B';'A'};
x0 = [116.316+dxa, -1*dxa];
v0 = [-27.95, 27.84];
a0 = [-0.343, -0.626];
t  = -2:0.1:10;
iz = find(abs(DOF-(101039+0.03))<1e-6);           % گره‌ی وسط تیر اصلی A (x=58.158 m)، جابه‌جایی z
izC = find(abs(DOF-(102039+0.03))<1e-6);          % تیر اصلی C
for ip = 1:2
    xa = (x0(:,ip) + v0(ip)*t + a0(ip)*t.^2/2).';
    va = (v0(ip) + a0(ip)*t).';
    uz = zeros(numel(t),2);
    for k = 1:numel(t)
        P  = xrail_2_P(tracks{ip}, xa(k,:), AL, va(k));
        Ur = Kr1 \ (T1.' * P);
        U  = T1 * Ur;
        uz(k,:) = [U(iz), U(izC)];
    end
    dlmwrite(fullfile(outdir, sprintf('octave_passage%d_uz_mid.csv', ip)), [t(:), uz], 'precision', '%.10e');
end
disp('Reference run finished. Copy the CSV files next to compare_python_octave.py');
