# KW51 Virtual Lab - آزمایشگاه مجازی پل راه‌آهن KW51

ساختار پوشه‌ها مطابق طرح پروژه است. هسته‌ی پایتون در `06_Python_Virtual_Lab/kw51lab` قرار دارد.

## اجرا
```
cd 06_Python_Virtual_Lab
pip install -r requirements.txt
streamlit run app.py              # رابط گرافیکی (۶ تب)
pytest -q tests                   # آزمون‌های خودکار (۷ آزمون)
python scripts_export.py          # تولید 01_Processed_Data و جداول مدل
python run_validation_suite.py    # همه‌ی اعتبارسنجی‌ها + مطالعه‌ی پارامتری (حدود ۱۰ دقیقه)
python build_documentation.py     # بازتولید Model_Data_Register / Assumptions / Validation_Log
```

## وضعیت (صادقانه؛ جزئیات در 08_Documentation/Validation_Log.xlsx)
| سطح | وضعیت |
|---|---|
| مدل اجزای محدود KW51 (پورت model_kw51.m + المان‌های Stabil) | پیاده‌سازی و راستی‌آزمایی داخلی انجام شد؛ **بازتولید در Octave هنوز انجام نشده** |
| استاتیکی، وزن خود، واکنش، پوش، خط تأثیر | تکمیل (تعادل، حل مستقیم) |
| مودال + جرم مؤثر | تکمیل؛ مقایسه با ۱۴ مود پایش (خطای ۲٫۲–۲٫۷٪، MAC ≥ ۰٫۹۴ برای مودهای ۱–۹) با محدودیت A14 |
| بار متحرک (مودال با جبران مودهای حذف‌شده) | تکمیل؛ برابر حل استاتیکی مستقیم در سرعت آهسته (۰٫۰۰۵ mm) |
| VBI قائم (قطار چندجرمی + فنر تماس) | پیاده‌سازی شد؛ تغییرمکان همگراست؛ **شتاب همگرا نیست**؛ پارامترهای Desiro فرضی |
| جرم متحرک | فقط تغییرمکان قابل استفاده؛ شتاب و جدایی تماس معتبر نیست |
| مدل ریل/تراورس/پد، قطار مفصلی، ناهمواری ریل | **پیاده‌سازی نشده** (stub) |
| مقایسه‌ی سری زمانی با عبور واقعی | **انجام نشده**: فایل‌های traindata_*.mat ارسال نشده‌اند |

## کارهای لازم از طرف شما
1. اجرای `04_Analysis/Reference_Octave/run_reference_octave.m` در Octave+Stabil و سپس `compare_python_octave.py`.
2. ارسال فایل‌های traindata_*.mat (عبورهای واقعی) و تعریف دقیق حسگرها برای اعتبارسنجی سری زمانی.
3. پارامترهای واقعی Desiro MS08 (جرم‌ها، تعلیق) و تأیید فاصله‌ی دو مجموعه‌ی متصل.

## نمودارهای خط تأثیر، برش و لنگر (تصویر + جدول)
`python make_diagrams.py` (در 06_Python_Virtual_Lab) این فایل‌ها را در 05_Results می‌سازد:
* Figures/influence_lines_girderA_multiple_points.png - خط تأثیر تغییرمکان، لنگر، برش، محوری تیر A در x=10…110 m (بار واحد روی خط B)
* Figures/girderA_shear_moment_axial_diagrams.png - نمودار V، M، N در طول تیر A برای پنج موقعیت قطار Desiro
* Figures/envelopes_girderA_girderC.png - پوش V، M، N تیرهای A و C
* Tables/influence_lines_girderA_trackB_{uz,M,V,N}.csv ، girderA_internal_forces_vs_train_position.csv ، envelope_girder{A,C}_desiro_trackB.csv
