% Plot time history of accelerations, strains and displacements
% corresponding to a given train passage
% April 2020
% Kristof Maes, KU Leuven

close all, clear all, clc

fileName='traindata_20191104_080120';
folder=fileName(1:16);

%% Add MATLAB functions
addpath('toolbox')

%% Load data
load(['../traindata/' folder '/' fileName '.mat'])

%% Plot data
sf_case=2;                      % 1: plot in separate figures
                                % 2: plot in 1 figure with subplots

% Time histories
t_a=(predat_a.sdn-predat_a.sdn(1))*24*60*60;    % Time vector acceleration
t_sg=(predat_sg.sdn-predat_a.sdn(1))*24*60*60;  % Time vector strain
if exist('predat_d')==1
    t_d=(predat_d.sdn-predat_a.sdn(1))*24*60*60;% Time vector displacement
end
% x-axis limits & ticks
[xLims_t,xTicks_t]=get_lims(t_a,'min0',[],0,max(t_a)-10); 
% y-axis limits & ticks acceleration
[yLims_a_t,yTicks_a_t]=get_lims(predat_a.tdata,'equal'); 
% y-axis limits & ticks strain bridge
[yLims_sb_t,yTicks_sb_t]=get_lims(predat_sg.tdata(:,1:12),[]); 
[yLims_sr_t,yTicks_sr_t]=get_lims(predat_sg.tdata(:,13:16),[]); 
    
if exist('predat_d')==1
    max1=ceil(max(predat_d.tdata(:,1)-predat_d.tdata(1,1),[],'omitnan')/5e-4)*(5e-4)+(5e-4);
    min1=floor(min(predat_d.tdata(:,1)-predat_d.tdata(1,1),[],'omitnan')/5e-4)*(5e-4)-(5e-4);
    max2=ceil(max(predat_d.tdata(:,2)-predat_d.tdata(1,2),[],'omitnan')/5e-4)*(5e-4)+(5e-4);
    min2=floor(min(predat_d.tdata(:,2)-predat_d.tdata(1,2),[],'omitnan')/5e-4)*(5e-4)-(5e-4);
    yLims_d_t=[min([min1,min2],[],'omitnan'),...
         max([max1,max2],[],'omitnan')];        % y-axis limits displacements
    yTicks_d_t=-0.5:5e-4:0.5;                   % y-axis ticks strain rails
    existd=1;
else
    t_d=t_a;
    predat_d.tdata=NaN(length(t_a),2);
    predat_d.labels={'dABLA','dABLC'};
    yLims_d_t=[-10,10]*1e-4;                    % y-axis limits displacements
    yTicks_d_t=yLims_d_t(1):5e-4:yLims_d_t(2);  % y-axis ticks strain rails
    existd=0;
end

if sf_case==2
    newfig([35,16])
    fs=9;  % Font size
else
    fs=11; % Font size
end

% Plot acceleration measurements
for ind1=1:12
    
    if sf_case==1
        thisFig=newfig([5,3],[1.69 1.15 0.35 0.65]);
    elseif sf_case==2
        subplot(5,9,floor((ind1-1)/4)*9+(ind1-4*floor((ind1-1)/4)))
    end
    plot(t_a,predat_a.tdata(:,ind1),'color',[0,0,1])
    xlabel('Time [$\mathrm{s}$]','interpreter','latex','fontsize',fs) 
    ylabel('Accel. [$\mathrm{m/s^2}$]','interpreter','latex','fontsize',fs)
    set(gca,'fontsize',fs)
    xlim(xLims_t), set(gca,'xtick',xTicks_t)
    ylim(yLims_a_t), set(gca,'ytick',yTicks_a_t)
    text(xLims_t(1)+0.023*(xLims_t(2)-xLims_t(1)),...
        yLims_a_t(2)-0.1*(yLims_a_t(2)-yLims_a_t(1)),predat_a.labels{ind1},...
        'interpreter','latex','fontsize',fs)
    set(gca,'TickLabelInterpreter','latex')
    if isnan(predat_a.tdata(1,ind1))
        if sf_case==1
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_a_t(2)-0.5*(yLims_a_t(2)-yLims_a_t(1)),...
                'No data available','interpreter','latex','fontsize',fs)
        elseif sf_case==2
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_a_t(2)-0.5*(yLims_a_t(2)-yLims_a_t(1)),...
                'No data','interpreter','latex','fontsize',fs)
        end
    end
end

% Plot strain measurements on bridge
for ind1=1:12
    
    if sf_case==1
        thisFig=newfig([5,3],[1.69 1.15 0.35 0.65]);
    elseif sf_case==2
        subplot(5,9,5+floor((ind1-1)/4)*9+(ind1-4*floor((ind1-1)/4)))
    end
    plot(t_sg,predat_sg.tdata(:,ind1),'color',[0,0,1])
    xlabel('Time [$\mathrm{s}$]','interpreter','latex','fontsize',fs) 
    ylabel('Strain [$-$]','interpreter','latex','fontsize',fs)
    set(gca,'fontsize',fs)
    xlim(xLims_t), set(gca,'xtick',xTicks_t)        
    ylim(yLims_sb_t), set(gca,'ytick',yTicks_sb_t)
    text(xLims_t(1)+0.023*(xLims_t(2)-xLims_t(1)),...
        yLims_sb_t(2)-0.1*(yLims_sb_t(2)-yLims_sb_t(1)),predat_sg.labels{ind1},...
        'interpreter','latex','fontsize',fs)
    set(gca,'TickLabelInterpreter','latex')
    if isnan(predat_sg.tdata(1,ind1))
        if sf_case==1
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_sb_t(2)-0.5*(yLims_sb_t(2)-yLims_sb_t(1)),...
                'No data available','interpreter','latex','fontsize',fs)
        elseif sf_case==2
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_sb_t(2)-0.5*(yLims_sb_t(2)-yLims_sb_t(1)),...
                'No data','interpreter','latex','fontsize',fs)
        end
    end
end

% Plot strain measurements on rails
for ind1=1:4
    
    if sf_case==1
        thisFig=newfig([5,3],[1.69 1.15 0.35 0.65]);
    elseif sf_case==2
        subplot(5,9,36+floor((ind1-1)/4)*9+(ind1-4*floor((ind1-1)/4)))
    end
    plot(t_sg,predat_sg.tdata(:,12+ind1),'color',[0,0,1])
    xlabel('Time [$\mathrm{s}$]','interpreter','latex','fontsize',fs) 
    ylabel('Strain [$-$]','interpreter','latex','fontsize',fs)
    set(gca,'fontsize',fs)
    xlim(xLims_t), set(gca,'xtick',xTicks_t)
    ylim(yLims_sr_t), set(gca,'ytick',yTicks_sr_t)
    if sf_case==1
        label_=[predat_sg.labels{12+ind1} ' (track ' predat_sg.labels{12+ind1}(end-1) ')'];
    elseif sf_case==2
        label_=[predat_sg.labels{12+ind1} '(tr' predat_sg.labels{12+ind1}(end-1) ')'];
    end
    text(xLims_t(1)+0.023*(xLims_t(2)-xLims_t(1)),...
        yLims_sr_t(2)-0.1*(yLims_sr_t(2)-yLims_sr_t(1)),...
        label_,'interpreter','latex','fontsize',fs)
    clear label_
    set(gca,'TickLabelInterpreter','latex')
    if isnan(predat_sg.tdata(1,12+ind1))
        if sf_case==1
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_sr_t(2)-0.5*(yLims_sr_t(2)-yLims_sr_t(1)),...
                'No data available','interpreter','latex','fontsize',fs)
        elseif sf_case==2
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_sr_t(2)-0.5*(yLims_sr_t(2)-yLims_sr_t(1)),...
                'No data','interpreter','latex','fontsize',fs)
        end
    end
end

% Plot displacement measurements 
for ind1=1:2
    
    if sf_case==1
        thisFig=newfig([5,3],[1.69 1.15 0.35 0.65]);
    elseif sf_case==2
        subplot(5,9,36+5+floor((ind1-1)/4)*9+(ind1-4*floor((ind1-1)/4)))
    end
    plot(t_d,predat_d.tdata(:,ind1),'color',[0,0,1])
    xlabel('Time [$\mathrm{s}$]','interpreter','latex','fontsize',fs) 
    ylabel('Displacement [$\mathrm{m}$]','interpreter','latex','fontsize',fs)
    set(gca,'fontsize',fs)
    xlim(xLims_t), set(gca,'xtick',xTicks_t)
    if existd==0
        yLims_d_t_sel=yLims_d_t;
    elseif existd==1
        if isnan(predat_d.tdata(1,ind1))==0
            yLims_d_t_sel=yLims_d_t+predat_d.tdata(1,ind1);
        else
            yLims_d_t_sel=yLims_d_t;
        end
    end
    ylim(yLims_d_t_sel)
    set(gca,'ytick',yTicks_d_t)
    text(xLims_t(1)+0.023*(xLims_t(2)-xLims_t(1)),...
        yLims_d_t_sel(2)-0.1*(yLims_d_t_sel(2)-yLims_d_t_sel(1)),...
        predat_d.labels{ind1},...
        'interpreter','latex','fontsize',fs)
    set(gca,'TickLabelInterpreter','latex')
    if isnan(predat_d.tdata(1,ind1))
        if sf_case==1
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_d_t(2)-0.5*(yLims_d_t(2)-yLims_d_t(1)),...
                'No data available','interpreter','latex','fontsize',fs)
        elseif sf_case==2
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_d_t(2)-0.5*(yLims_d_t(2)-yLims_d_t(1)),...
                'No data','interpreter','latex','fontsize',fs)
        end
    end
end
