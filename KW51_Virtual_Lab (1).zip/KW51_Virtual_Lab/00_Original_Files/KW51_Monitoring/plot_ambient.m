% Plot time history and power spectral density (PSD) of ambient 
% acceleration data
% April 2020
% Kristof Maes, KU Leuven

close all, clear all, clc

fileName='ambient_20191228_000000';
folder=fileName(1:14);

%% Add MATLAB functions
addpath('toolbox')

%% Load data
load(['../ambient/' folder '/' fileName '.mat'])

%% Plot data
sf_case=2;                      % 1: plot in separate figures
                                % 2: plot in 1 figure with subplots

% Time histories
t_a=(predat_a.sdn-predat_a.sdn(1))*24*60*60;    % Time vector 
[xLims_t,xTicks_t]=get_lims(t_a,'min0',4);      % x-axis limits & ticks
[yLims_t,yTicks_t]=get_lims(predat_a.tdata,'equal'); % y-axis limits & ticks
% Power spectral densities (PSD)
% Calculate PSD using Pwelch
window=hann(2^14);                      % Hanning window
Noverlap=round(0.66*length(window));    % 66% overlap 
[psd_a,f_a]=pwelch(predat_a.tdata,window,Noverlap,length(window),predat_a.fs,'twosided');
[xLims_f,xTicks_f]=get_lims([0,30],'min0',7);       % x-axis limits & ticks
[yLims_f,yTicks_f]=get_lims(log10(psd_a),[],7,-12); % y-axis limits & ticks
yLims_f=10.^yLims_f; yTicks_f=10.^yTicks_f(yTicks_f==round(yTicks_f));

if sf_case==2
    newfig([18,20]) 
    fs=9; % Font size
else
    fs=11; % Font size
end

for ind1=1:length(predat_a.labels)
    
    % Time histories
    if sf_case==1
        newfig([5,3],[1.69 1.15 0.35 0.5]);
    elseif sf_case==2
        subplot(6,4,(ind1-1)*2+1)
    end
    plot(t_a,predat_a.tdata(:,ind1),'color',[0,0,1])
    xlabel('Time [$\mathrm{s}$]','interpreter','latex','fontsize',fs) 
    ylabel('Accel. [$\mathrm{m/s^2}$]','interpreter','latex','fontsize',fs)
    set(gca,'fontsize',fs)
    xlim(xLims_t), set(gca,'xtick',xTicks_t)
    ylim(yLims_t), set(gca,'ytick',yTicks_t)
    text(xLims_t(1)+0.023*(xLims_t(2)-xLims_t(1)),...
        yLims_t(2)-0.1*(yLims_t(2)-yLims_t(1)),predat_a.labels{ind1},...
        'interpreter','latex','fontsize',fs)
    set(gca,'TickLabelInterpreter','latex')
    if isnan(predat_a.tdata(1,ind1))
        if sf_case==1
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_t(2)-0.5*(yLims_t(2)-yLims_t(1)),...
                'No data available','interpreter','latex','fontsize',fs)
        elseif sf_case==2
            text(xLims_t(1)+0.2*(xLims_t(2)-xLims_t(1)),...
                yLims_t(2)-0.5*(yLims_t(2)-yLims_t(1)),...
                'No data','interpreter','latex','fontsize',fs)
        end
    end
    
    % PSD
    if sf_case==1
        newfig([5,3],[1.69 1.15 0.35 0.5]);
    elseif sf_case==2
        subplot(6,4,(ind1-1)*2+2)
    end
    semilogy(f_a,psd_a(:,ind1),'color',[0,0,1])
    xlabel('Frequency [$\mathrm{Hz}$]','interpreter','latex','fontsize',fs) 
    ylabel('\hspace{-0.2em}PSD [$\mathrm{(m/s^2)^2/Hz}$]',...
        'interpreter','latex','fontsize',fs)
    set(gca,'fontsize',fs)
    xlim(xLims_f), set(gca,'xtick',xTicks_f)
    ylim(yLims_f), set(gca,'ytick',yTicks_f)
    text(xLims_f(1)+0.023*(xLims_f(2)-xLims_f(1)),...
        10^(log10(yLims_f(1))+0.9*log10(yLims_f(2)/yLims_f(1))),...
        predat_a.labels{ind1},'interpreter','latex','fontsize',fs)
    set(gca,'TickLabelInterpreter','latex')
    
end
