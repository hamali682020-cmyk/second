% Plot the time history of the identified natural frequencies and the
% measured air and bridge surface temperature
% April 2020
% Kristof Maes, KU Leuven

close all, clear all, clc

%% Add MATLAB functions
addpath('toolbox')

%% Load data
load('../trackedmodes/trackedmodes.mat') 

%% Plot natural frequencies
% Creat a new figure with fixed size and margins
newfig([14 6],[1.0 1.2 0.2 0.2])
% Boundaries of the gray filled rectangle indicating the retrofitting time
% interval
xm=[datetime(datenum(2019,05,15),'ConvertFrom','datenum'),...
    datetime(datenum(2019,09,27),'ConvertFrom','datenum'),...
    datetime(datenum(2019,09,27),'ConvertFrom','datenum'),...
    datetime(datenum(2019,05,15),'ConvertFrom','datenum')];
ym=[0,0,10,10];
% Create gray filled rectangle indicating the retrofitting time interval
fill(xm,ym,[0.9,0.9,0.9],'edgecolor','w')
hold on
% Plot the natural frequencies in different colors which indicate the mode
% type
colors_=zeros(size(modes.f,2),3);
% arch modes - blue
colors_([1,2,4,7,8,14],3)=1;    
% lateral modes of the bridge deck - red
colors_([3,11],1)=1;            
% global vertical modes - green
colors_([5,6,10,12,13],2)=0.5;  % green
% torsional modes - cyan
colors_(9,:)=[1,0,1];           % cyan
for ind1=1:size(colors_,1)
    plot(datetime(modes.sdn,'ConvertFrom','datenum'),modes.f(:,ind1),'.',...
        'markersize',2,'color',colors_(ind1,:))
end
ylabel('Natural frequency [$\mathrm{Hz}$]','interpreter','latex')
ylim([0,7.5])
xtickangle(45)
set(gca,'fontsize',7.5)
set(gca,'TickLabelInterpreter','latex')
set(gca,'xtick',datetime(...
    [datenum(2018,10,01),datenum(2018,11,01),datenum(2018,12,01),...
    datenum(2019,01,01),datenum(2019,02,01),datenum(2019,03,01),...
    datenum(2019,04,01),datenum(2019,05,01),datenum(2019,06,01),...
    datenum(2019,07,01),datenum(2019,08,01),datenum(2019,09,01),...
    datenum(2019,10,01),datenum(2019,11,01),datenum(2019,12,01),...
    datenum(2020,01,01)],'ConvertFrom','datenum'))
set(gca,'xticklabel',{...
    '1 Oct 2018','1 Nov 2018','1 Dec 2018','1 Jan 2019','1 Feb 2019',...
    '1 Mar 2019','1 Apr 2019','1 May 2019','1 Jun 2019','1 Jul 2019',...
    '1 Aug 2019','1 Sep 2019','1 Oct 2019','1 Nov 2019','1 Dec 2019',...
    '1 Jan 2020'})
xlim(datetime([datenum(2018,10,1),datenum(2020,01,16,00,00,00)],...
    'ConvertFrom','datenum'))

%% Plot temperatures
% Creat a new figure with fixed size and margins
newfig([14 3.5],[1.0 1.2 0.2 0.2])
% Boundaries of the gray filled rectangle indicating the retrofitting time
% interval
ym=[-10,-10,45,45];
% Create gray filled rectangle indicating the retrofitting time interval
fill(xm,ym,[0.9,0.9,0.9],'edgecolor','w')
hold on
% Plot the steel surface temperature recorded on site (Ts) and the air
% temperature recorded at the Vliet building (Ta)
Ts=modes.env(:,1); Ta=modes.env(:,3);
plot(datetime(modes.sdn,'ConvertFrom','datenum'),Ts,'k.','markersize',4)
hold on, plot(datetime(modes.sdn,'ConvertFrom','datenum'),Ta,'b.','markersize',4)
hold on, plot(datetime([min(modes.sdn),max(modes.sdn)],'ConvertFrom','datenum'),[0,0],'k:')
ylabel('Temperature [$^\circ \mathrm{C}$]','interpreter','latex')
ylim([-10,45])
xtickangle(45)
set(gca,'fontsize',7.5)
set(gca,'TickLabelInterpreter','latex')
set(gca,'xtick',datetime(...
    [datenum(2018,10,01),datenum(2018,11,01),datenum(2018,12,01),...
    datenum(2019,01,01),datenum(2019,02,01),datenum(2019,03,01),...
    datenum(2019,04,01),datenum(2019,05,01),datenum(2019,06,01),...
    datenum(2019,07,01),datenum(2019,08,01),datenum(2019,09,01),...
    datenum(2019,10,01),datenum(2019,11,01),datenum(2019,12,01),...
    datenum(2020,01,01)],'ConvertFrom','datenum'))
set(gca,'xticklabel',{...
    '1 Oct 2018','1 Nov 2018','1 Dec 2018','1 Jan 2019','1 Feb 2019',...
    '1 Mar 2019','1 Apr 2019','1 May 2019','1 Jun 2019','1 Jul 2019',...
    '1 Aug 2019','1 Sep 2019','1 Oct 2019','1 Nov 2019','1 Dec 2019',...
    '1 Jan 2020'})
xlim(datetime([datenum(2018,10,1),datenum(2020,01,16,00,00,00)],...
    'ConvertFrom','datenum'))
