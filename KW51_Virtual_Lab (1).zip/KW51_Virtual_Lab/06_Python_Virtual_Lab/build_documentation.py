"""build_documentation.py - تولید Model_Data_Register.xlsx ، Assumptions.xlsx ، Validation_Log.xlsx
(مقادیر از مدل و از 05_Results/Validation_Reports/validation_results.json خوانده می‌شود)"""
import os, sys, json, datetime
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kw51lab.analysis.core import Lab, PRESETS
from kw51lab.bridge.geometry import key_dimensions
from kw51lab.bridge.sections import sections_table, NAMES
from kw51lab.analysis.static import self_weight

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
P = lambda *a: os.path.join(ROOT, *a)
J = json.load(open(P("05_Results/Validation_Reports/validation_results.json"), encoding="utf-8"))
DATE = "2026-11-15"
labA = Lab(**PRESETS["پس از مقاوم‌سازی (simulate_trainpassage.m)"]); labB = Lab(**PRESETS["پیش از مقاوم‌سازی (modal_analysis.m)"])
kd = key_dimensions(labA.m)

HDR = PatternFill("solid", fgColor="1F3864"); thin = Side(style="thin", color="BBBBBB")
FILL = {"واقعی": "E2EFDA", "استخراج‌شده": "DDEBF7", "فرضی": "FCE4D6", "کالیبره‌شده": "FFF2CC",
        "قبول": "E2EFDA", "قبول با محدودیت": "FFF2CC", "انجام‌نشده": "F8CBAD", "پیاده‌سازی‌نشده": "F8CBAD", "ناقص": "FFF2CC", "رد": "F4B084"}


def write(path, sheet, headers, rows, widths, status_col=None):
    wb = Workbook(); ws = wb.active; ws.title = sheet; ws.sheet_view.rightToLeft = True
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(name="Arial", bold=True, color="FFFFFF"); c.fill = HDR
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for r in rows:
        ws.append(r)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font = Font(name="Arial", size=10); c.alignment = Alignment(vertical="top", wrap_text=True)
            c.border = Border(top=thin, bottom=thin, left=thin, right=thin)
        if status_col is not None:
            v = row[status_col].value
            if v in FILL:
                row[status_col].fill = PatternFill("solid", fgColor=FILL[v])
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
    os.makedirs(os.path.dirname(path), exist_ok=True); wb.save(path)


# ======================================================================= Model_Data_Register
MOD = "model_kw51.m"
rows = []
def E(name, value, unit, source, status, conf, verif, notes=""):
    rows.append([name, value, unit, source, status, conf, verif, notes])

E("طول کل مدل (x)", round(kd["model_length"], 3), "m", f"{MOD} - NODES DEFINITION (xn)", "استخراج‌شده", "متوسط", "مقایسه با نقشه‌ها انجام نشده", "عدد کلی «حدود ۱۱۵ m» در پروپوزال با طول مدل تفاوت دارد؛ ملاک، مدل است")
E("فاصله‌ی تکیه‌گاه‌ها (x)", round(kd["bearing_distance"], 3), "m", f"{MOD} - گره‌های ۱..۴", "استخراج‌شده", "متوسط", "مقایسه با نقشه‌ها انجام نشده")
E("فاصله‌ی تیرهای اصلی A و C (y)", kd["girder_spacing"], "m", f"{MOD} - گره‌های 101xxx/102xxx", "استخراج‌شده", "متوسط", "مقایسه با نقشه‌ها انجام نشده", "عرض کل ۱۲٫۴ m در پروپوزال شامل اجزای دیگر است")
E("ارتفاع تاج قوس (z)", round(kd["arch_crown_z"], 3), "m", f"{MOD} - zarch(x) = -0.0056679878x² + 0.659277672x + 0.341695", "استخراج‌شده", "متوسط", "مقایسه با نقشه‌ها انجام نشده", f"ارتفاع نسبت به تیر اصلی {kd['arch_rise_above_girder']:.3f} m")
E("تراز ورق عرشه", kd["deck_plate_z"], "m", f"{MOD}", "واقعی", "متوسط", "مقایسه با نقشه‌ها انجام نشده")
E("تعداد گره‌های طولی (شبکه‌ی x)", kd["n_x_nodes"], "-", f"{MOD}", "استخراج‌شده", "بالا", "شمارش مدل پایتون = ۷۸ (پورت)")
E("تعداد تیرهای عرضی / تیر U", f"{kd['n_transverse_beams']} / {kd['n_ubeams']}", "-", f"{MOD}", "استخراج‌شده", "بالا", "شمارش مدل پایتون")
E("تعداد المان‌های تیر / پوسته", f"{len(labA.m.beams)} / {len(labA.m.shells)}", "-", "پورت پایتون از model_kw51.m", "استخراج‌شده", "متوسط", "تطبیق با خروجی Octave: انجام نشده (باید اجرا شود)")
for sdict in sections_table(labA.m):
    E(f"مقطع {sdict['section']}: {sdict['name']}", f"A={sdict['A']:.4g}; ky={sdict['ky']}; kz={sdict['kz']}; Ixx={sdict['Ixx']:.4g}; Iyy={sdict['Iyy']:.4g}; Izz={sdict['Izz']:.4g}",
      "m², -, -, m⁴", f"{MOD} - SECTIONS DEFINITION", "واقعی" if sdict["section"] not in (9, 10) else "کالیبره‌شده", "متوسط",
      "Stabil: سطح برشی = k·A (از کد منبع kelcs_beam.m)", "محور y محلی به‌سمت گره‌ی مرجع (trans_beam.m)؛ بدون گره مرجع: مبدأ مختصات")
E("فولاد: E، ν، ρ", "200e9 × Es_rel ; 0.3 ; 7850", "Pa, -, kg/m³", f"{MOD} - MATERIALS DEFINITION", "واقعی", "بالا", "مقایسه با مدل رسمی")
E("بالاست: E، ν، ρ", "550e6 ; 0.3 ; 1700", "Pa, -, kg/m³", f"{MOD}", "واقعی", "متوسط", "مقایسه با مدل رسمی")
E("ضخامت بالاست (پیش از مقاوم‌سازی)", labB.m.h_ballast, "m", f"{MOD}: 0.6·hb_rel، hb_rel=1.1 (modal_analysis.m)", "کالیبره‌شده", "متوسط", "به‌روزرسانی مدل توسط نویسندگان (Maes et al. 2022)")
E("ضخامت بالاست (پس از مقاوم‌سازی)", labA.m.h_ballast, "m", f"{MOD}: hb_rel=1.0833 (simulate_trainpassage.m)", "کالیبره‌شده", "متوسط", "به‌روزرسانی مدل توسط نویسندگان (Maes & Lombaert 2023)")
E("Id_rel / Ad_rel پیش از مقاوم‌سازی", "0.06 / 0.78", "-", "modal_analysis.m", "کالیبره‌شده", "متوسط", "توسط نویسندگان مدل با داده‌ی پایش تنظیم شده؛ بنابراین مقایسه‌ی مودال من با همان داده «اعتبارسنجی مستقل کامل» نیست")
E("Id_rel / Ad_rel پس از مقاوم‌سازی", "0.08 / 0.88", "-", "simulate_trainpassage.m", "کالیبره‌شده", "متوسط", "همان توضیح بالا")
E("جرم جعبه‌های مقاوم‌سازی", 333, "kg (هر گره‌ی میانی آویز، ۳ جهت انتقالی)", f"{MOD} - ACCOUNT FOR THE MASS OF THE STEEL BOXES", "واقعی", "متوسط", "مقایسه با مدل رسمی")
sw = self_weight(labA)
E("جرم کل مدل (پس از مقاوم‌سازی)", round(sw["mass"]), "kg", "ماتریس جرم مدل پایتون", "استخراج‌شده", "متوسط", f"مجموع واکنش‌ها = وزن (خطا {J['self_weight_Rz_err_pct']:.4f}%)", "ریل، تراورس و اجزای جانبی در مدل رسمی نیست")
E("تکیه‌گاه N1", "ux,uy,uz بسته", "-", f"{MOD} - ADD CONSTRAINT EQUATIONS", "واقعی", "بالا", "مقایسه با کد")
E("تکیه‌گاه N2", "ux,uz بسته", "-", f"{MOD}", "واقعی", "بالا", "مقایسه با کد")
E("تکیه‌گاه N3 (fixed=0)", "uy,uz بسته؛ ux آزاد با فنر kxx", "-", f"{MOD}", "واقعی", "متوسط", "رفتار غیرخطی تکیه‌گاه در مدل نیست (نیاز به مقاله‌ی van de Velde 2023)")
E("تکیه‌گاه N4 (fixed=0)", "uz بسته؛ ux,uy آزاد با فنر kxx", "-", f"{MOD}", "واقعی", "متوسط", "همان توضیح بالا")
E("سختی فنر kxx", "0 (پس از) / NaN-مقید (پیش از)", "N/m", "simulate_trainpassage.m / modal_analysis.m", "واقعی", "متوسط", "—")
E("میرایی سازه (مدل اجزای محدود)", "در مدل رسمی تعریف نشده", "-", "model_kw51.m", "واقعی", "بالا", "—", "برای دینامیک: ζ=1% فرض شده (A05)")
E("میرایی اندازه‌گیری‌شده (میانه‌ی ξ مودها)", "0.19 … 1.55 (فرض: درصد)", "%", "trackedmodes.mat - modes.xi", "استخراج‌شده", "پایین", "واحد در فایل مستند نشده؛ بزرگی عددی با درصد سازگار است", "باید در مقاله‌ی مرجع بررسی شود")
E("فرکانس‌های اندازه‌گیری‌شده (۱۴ مود)", "0.51 … 6.9 (میانه‌ی پیش از مقاوم‌سازی)", "Hz", "trackedmodes.mat", "واقعی", "بالا", "—", "تاریخ آغاز/پایان مقاوم‌سازی فرض شده (A09)")
E("اثر دما بر فرکانس", "dfdT از -0.0001 تا -0.0058، همبستگی تا -0.84", "Hz/°C", "trackedmodes.mat (tBD31A)", "استخراج‌شده", "متوسط", "رگرسیون خطی ساده؛ اثرات دیگر کنترل نشده", "01_Processed_Data/Monitoring_Processed/modal_summary.csv")
E("ریل و اجزای متصل", "ریل/تراورس/پد جداگانه مدل نشده", "-", "xrail_2_P.m", "واقعی", "بالا", "—", "بار مستقیماً روی گره‌های بالاست پخش می‌شود")
E("ناحیه‌ی پخش بار محوری (نیم‌طول × نیم‌عرض)", "2.4 × 1.3175", "m", "xrail_2_P.m (force_distr)", "واقعی", "متوسط", "پورت پایتون با همان فرمول")
E("مسیر خط B و A (y(x) سهمی)", "B: 3.24→4.80→3.24 ; A: 7.24→8.81→7.24", "m", "xrail_2_P.m", "واقعی", "متوسط", "—")
E("شعاع قوس مسیر B / A", "1121 / 1125", "m", "xrail_2_P.m", "واقعی", "متوسط", "—", "برای نیروی گریز از مرکز")
E("ناهمواری ریل", "صفر (داده‌ای در دسترس نیست)", "mm", "—", "فرضی", "پایین", "—", "A06")
E("قطار Desiro MS08: آرایش و بار ۱۲ محور", "جمع ۱۳۷۱٫۸ kN ؛ فاصله‌ها ۰ … ۷۳٫۱ m", "kN, m", "simulate_trainpassage.m (Maes & Lombaert 2023، جدول ۳)", "واقعی", "بالا", "هم‌خوانی داخلی: مجموع بار مدل چندجرمی = جمع بار محورها", "")
E("قطار Desiro: جرم‌ها و تعلیق", "از آنالوگ ICE2 ERRI (واگن میانی)", "kg, N/m, Ns/m", "zenodo_conventional.xlsx", "فرضی", "پایین", "—", "A03؛ باید با اطلاعات واقعی AM08/Desiro MS08 جایگزین شود")
E("فاصله‌ی بین دو مجموعه‌ی متصل", 5.2, "m", "فرض: برابر فاصله‌ی بین واگنی الگوی Desiro", "فرضی", "پایین", "—", "A04؛ ترکیب ۲ و ۳ مجموعه تأیید عملیاتی ندارد")
E("سختی تماس چرخ-ریل k_H", 1e9, "N/m", "مرتبه‌ی بزرگی متداول در ادبیات", "فرضی", "پایین", "حساسیت‌سنجی انجام نشده", "A07")
E("عبورهای مرجع (سرعت/شتاب/موقعیت)", "عبور۱: v=-27.95، a=-0.343 (خط B) ؛ عبور۲: v=+27.84، a=-0.626 (خط A)", "m/s, m/s²", "simulate_trainpassage.m", "واقعی", "بالا", "—")
E("مجموعه‌داده‌های قطار Zenodo", "۱۳ قطار متعارف قابل استفاده؛ Railjet ناسازگار؛ ۶ قطار مفصلی پیاده‌سازی نشده", "-", "zenodo_conventional.xlsx / zenodo_articulated.xlsx", "استخراج‌شده", "متوسط", "وزن مدل چندجرمی = جمع بار محورها (نسبت ۱٫۰۰۰۰)", "بیشتر قطارهای پرسرعت‌اند؛ سازگاری با خط KW51 تأیید نشده")
write(P("08_Documentation/Model_Data_Register.xlsx"), "Model_Data_Register",
      ["نام پارامتر", "مقدار", "واحد", "منبع استخراج", "وضعیت (واقعی/استخراج‌شده/فرضی/کالیبره‌شده)", "میزان اطمینان", "روش تأیید", "توضیحات"],
      rows, [34, 40, 16, 40, 18, 12, 34, 50], status_col=4)

# ======================================================================= Assumptions
A = [
 ["A01", "اعداد کلی پروپوزال (۱۱۵ m دهانه، ۱۲٫۴ m عرض) به‌جای مدل استفاده نمی‌شود", "الزام پروژه", "—", "ملاک: مقادیر مدل رسمی (۱۱۶٫۳۱۶ m طول، ۱۱۴٫۱۹۸ m فاصله‌ی تکیه‌گاه، ۱۱٫۷۵ m فاصله‌ی تیرها)", "اعمال‌شده"],
 ["A02", "عناصر Stabil (تیر تیموشنکو، پوسته‌ی Q4+DKT) از کد منبع Stabil 3.1 به پایتون پورت شده‌اند", "اجرای MATLAB/Octave در این محیط ممکن نبود", "تفاوت‌های عددی ریز نسبت به Stabil ممکن است", "مقایسه با Octave با run_reference_octave.m (انجام نشده)", "باز"],
 ["A03", "پارامترهای دینامیکی Desiro MS08 (جرم بدنه/بوژی/چرخ‌ست، تعلیق) از قطار آنالوگ ICE2 ERRI گرفته شده؛ جرم بدنه از بار محورها محاسبه می‌شود", "داده‌ی واقعی در دسترس نیست", "VBI فقط برای مطالعه‌ی روند معتبر است، نه پیش‌بینی دقیق Desiro", "جایگزینی با داده‌ی سازنده/اندازه‌گیری", "باز"],
 ["A04", "فاصله‌ی ۵٫۲ m بین مجموعه‌ها برای ۲ و ۳ مجموعه‌ی متصل", "داده‌ی عملیاتی نیست", "فقط سناریوی فرضی", "تأیید عملیاتی", "باز"],
 ["A05", "میرایی مودال پل ζ=1% در همه‌ی مودها", "مدل رسمی میرایی ندارد", "دامنه‌ی ارتعاش (شتاب) به‌شدت حساس است", "استفاده از ξ اندازه‌گیری‌شده (واحد باید تأیید شود)", "باز"],
 ["A06", "ناهمواری ریل صفر", "داده‌ی مرجع نیست", "شتاب چرخ/پل و VBI را دست‌کم می‌گیرد", "ناهمواری اندازه‌گیری یا مرجع معتبر", "باز"],
 ["A07", "فنر تماس خطی هرتز k_H=1e9 N/m و تماس دائم (جدایی فقط تشخیص داده می‌شود)", "ساده‌سازی", "پاسخ مدل‌های VBI/جرم متحرک", "مطالعه‌ی حساسیت k_H", "باز"],
 ["A08", "VBI فقط قائم و صفحه‌ای است (بدون جانبی، پیچش، نیروی گریز از مرکز در VBI)", "دامنه‌ی نسخه‌ی اول", "اثر جانبی/پیچشی قطار در VBI لحاظ نشده", "توسعه‌ی مدل سه‌بعدی قطار", "باز"],
 ["A09", "تاریخ مقاوم‌سازی 2019-05-15 تا 2019-09-30", "در فایل‌های ارسالی ذکر نشده", "تفکیک فرکانس‌های پیش/پس", "تأیید با مقاله‌ی Maes & Lombaert 2021", "باز"],
 ["A10", "ریل، تراورس، پد و بالاست جدا مدل نشده", "مدل رسمی چنین مدلی ندارد", "ادعای Train-Track-Bridge ممنوع", "پیاده‌سازی مرحله‌ای (track/)", "باز"],
 ["A11", "کرنش در تار فرضی (y=-0.4 m) فقط برای نمایش روند", "تطبیق محل کرنش‌سنج واقعی بررسی نشده", "اعداد کرنش «نمایشی»", "پیاده‌سازی تعریف دقیق حسگرها از select_sensors.m و تطبیق علامت‌ها", "باز"],
 ["A12", "مدل جرم متحرک با فنر تماس سخت و پخش سطحی بار", "ساده‌سازی", "شتاب جرم متحرک (جهش‌های عددی) معتبر نیست", "هموارسازی پخش بار یا فرمول‌بندی مرجع", "باز"],
 ["A13", "ضریب بار محوری عمومی واگن 110 kN و ابعاد فرضی (فقط در ابزار «قطار ساده‌ی واگنی»)", "مثال آموزشی", "نباید در نتایج پژوهشی استفاده شود", "—", "باز"],
 ["A14", "اعتبارسنجی مودال با داده‌ای که نویسندگان مدل برای به‌روزرسانی مدل استفاده کرده‌اند انجام شده", "تنها داده‌ی در دسترس", "این مقایسه استقلال کامل ندارد", "کنار گذاشتن بلوک‌های زمانی (split) برای هر کالیبراسیون آینده", "باز"],
]
write(P("08_Documentation/Assumptions.xlsx"), "Assumptions", ["شناسه", "فرض", "دلیل", "اثر بر نتایج", "روش بررسی/رفع", "وضعیت"], A, [8, 60, 30, 40, 44, 12])

# ======================================================================= Validation_Log
mp, mq = J["modal_pre"], J["modal_post"]
rp = J["reference_passages"]
V = []
def Lg(id_, test, crit, result, status, evid, notes=""):
    V.append([id_, DATE, test, crit, result, status, evid, notes])
Lg("V01", "المان تیر: طره‌ی تیموشنکو در برابر حل دقیق", "خطا < 0.01%", f"{J['beam_cantilever_err_pct']:.5f}%", "قبول", "tests/test_core.py::test_beam_cantilever_timoshenko")
Lg("V02", "المان پوسته: ورق ساده‌تکیه‌گاه با بار مرکزی (۸×۸)", "خطا < 1%", f"{J['plate_center_err_pct']:.2f}%", "قبول", "run_validation_suite.py")
Lg("V03", "تعادل: بار واحد ۱۰۰۰ kN وسط دهانه", "خطا < 0.01%", f"{J['equilibrium_unit_load_err_pct']:.5f}%", "قبول", "run_validation_suite.py")
Lg("V04", "تعادل: وزن خود در برابر مجموع واکنش‌ها", "خطا < 0.01%", f"{J['self_weight_Rz_err_pct']:.5f}%  (جرم {J['self_weight_mass_t']:.0f} t)", "قبول", "run_validation_suite.py")
Lg("V05", "مودال پیش از مقاوم‌سازی در برابر پایش: خطای میانگین فرکانس مودهای ۱–۹", "< 5%", f"{mp['mean_abs_err_1_9']:.2f}%  (همه‌ی مودهای جور‌شده: {mp['mean_abs_err_all']:.2f}%)", "قبول با محدودیت", "05_Results/Tables/modal_validation_pre.csv", "پارامترهای مدل را نویسندگان با همین داده تنظیم کرده‌اند (A14)؛ مودهای ۱۰–۱۴ ضعیف‌ترند")
Lg("V06", "مودال: MAC مودهای ۱–۹", "> 0.9", f"min = {mp['min_MAC_1_9']:.2f}", "قبول با محدودیت", "modal_validation_pre.csv", "MAC با ۱۲ حسگر")
Lg("V07", "مودال پس از مقاوم‌سازی (تکیه‌گاه مفصلی fixed=1) در برابر پایش پس از مقاوم‌سازی", "< 5% برای مودهای ۱–۹", f"{mq['mean_abs_err_1_9']:.2f}%  ؛ min MAC {mq['min_MAC_1_9']:.2f}", "قبول با محدودیت", "modal_validation_post.csv", "همان محدودیت A14")
mf = J["modal_post_free_supports"]
Lg("V07b", "مودال پس از مقاوم‌سازی با تکیه‌گاه لغزنده‌ی ایده‌آل (fixed=0، حالت نقشه‌ها) در برابر پایش", "< 5% و MAC > 0.9", f"{mf['mean_abs_err_1_9']:.2f}% ؛ min MAC {mf['min_MAC_1_9']:.3f}", "رد", "modal_validation_post_free_supports.csv", "یافته: ارتعاش محیطی دامنه‌کوچک با تکیه‌گاه مقید سازگار است نه لغزنده‌ی ایده‌آل؛ نیاز به بررسی مقاله‌ی رفتار غیرخطی تکیه‌گاه‌ها (van de Velde 2023). برای مودال از fixed=1 استفاده می‌شود.")
Lg("V08", "مدل مودال بار متحرک آهسته در برابر حل استاتیکی مستقیم", "اختلاف < 0.05 mm", f"{J['slow_modal_vs_direct_max_diff_mm']:.4f} mm  (کمینه خیز {J['slow_direct_min_uz_mm']:.3f} mm)", "قبول", "run_validation_suite.py")
Lg("V09", "VBI در سرعت آهسته در برابر بار متحرک", "اختلاف < 1%", f"{J['slow_vbi_vs_movingload_pct']:.3f}%", "قبول", "tests/test_core.py::test_vbi_slow_limit_equals_moving_load")
c = J["convergence"]
Lg("V10", "همگرایی گام زمانی (VBI، عبور مرجع ۱)", "تغییر تغییرمکان < 0.1%", " | ".join(f"{k}: {v['min_uz_mm']:.4f} mm، a={v['peak_acc']:.3f}" for k, v in c.items() if k.startswith('dt')), "قبول با محدودیت", "validation_results.json", "تغییرمکان همگراست؛ بیشینه‌ی شتاب هنوز با dt تغییر می‌کند")
Lg("V10b", "همگرایی بیشینه‌ی شتاب (VBI) نسبت به گام زمانی و تعداد مود", "تغییر < 10%", "dt: " + ", ".join(f"{v['peak_acc']:.3f}" for k, v in c.items() if k.startswith('dt')) + " | modes: " + ", ".join(f"{v['peak_acc']:.3f}" for k, v in c.items() if k.startswith('modes')) + " m/s²", "رد", "validation_results.json", "بیشینه‌ی شتاب همگرا نیست؛ نتایج شتاب فقط کیفی‌اند تا اصلاح روش (پخش بار هموار، مودهای بیشتر، گام کوچک‌تر)")
Lg("V11", "همگرایی تعداد مودها (VBI)", "تغییر تغییرمکان < 1%", " | ".join(f"{k}: {v['min_uz_mm']:.4f} mm" for k, v in c.items() if k.startswith('modes')), "قبول", "validation_results.json")
Lg("V12", "مجموعه‌داده‌های قطار: وزن مدل چندجرمی = جمع بار محورها", "نسبت 1.000±0.001", f"{J['dataset_n_ok']} قطار؛ نسبت {J['dataset_weight_ratio_min_max'][0]:.4f}–{J['dataset_weight_ratio_min_max'][1]:.4f}", "قبول", "01_Processed_Data/Train_Axles/dataset_qc.csv", "Railjet: جدول بدنه ۶۴ محور، جدول قطار ۳۰ محور (ناسازگاری فایل منبع؛ اصلاح نشد)")
Lg("V13", "نتایج عبور مرجع: سه مدل بار", "—", "؛ ".join(f"{n[:6]}: " + " / ".join(f"{m} {v['min_uz_mm']:.3f}mm" for m, v in d.items()) for n, d in rp.items()), "قبول با محدودیت", "05_Results/Figures/reference_passages_models.png", "با داده‌ی واقعی عبور مقایسه نشده (داده موجود نیست)")
Lg("V14", "جرم متحرک: شتاب و جدایی تماس", "بدون جدایی", "; ".join(f"{n[:6]}: جدایی={d['جرم متحرک']['separation']}، a={d['جرم متحرک']['peak_acc']:.2f}" for n, d in rp.items()), "رد", "validation_results.json", "فقط تغییرمکان قابل استفاده است (A12)")
Lg("V15", "بازتولید مدل رسمی در Octave/Stabil", "فرکانس‌ها و عبور شبه‌استاتیکی بازتولید شود", "اجرا نشده (Octave روی سیستم کاربر)", "انجام‌نشده", "04_Analysis/Reference_Octave", "run_reference_octave.m + compare_python_octave.py آماده است")
Lg("V16", "مقایسه‌ی سری زمانی شتاب/کرنش/تغییرمکان با عبور واقعی", "NRMSE، همبستگی، تفاوت قله", "داده‌ی traindata_*.mat ارسال نشده", "انجام‌نشده", "validation/signal_validation.py", "فقط روی سیگنال مصنوعی آزمون شد")
Lg("V17", "مدل ریل/تراورس/پد (Train–Track–Bridge)", "اجزا در معادلات حضور داشته باشند", "پیاده‌سازی نشده", "پیاده‌سازی‌نشده", "kw51lab/track/", "هیچ ادعایی ثبت نمی‌شود")
Lg("V18", "قطارهای مفصلی (Thalys, TGV, ...)", "—", "پیاده‌سازی نشده", "پیاده‌سازی‌نشده", "train/vehicle.py")
Lg("V19", "تفکیک داده‌ی کالیبراسیون/اعتبارسنجی", "بلوک‌های زمانی مستقل", "تابع آماده است؛ هنوز کالیبراسیونی انجام نشده", "انجام‌نشده", "validation/metrics.py::split_calibration_validation")
Lg("V20", "تطبیق تعریف دقیق کرنش‌سنج‌ها با select_sensors.m", "علامت و محل", "پیاده‌سازی نشده (فقط کرنش عمومی)", "انجام‌نشده", "analysis/static.py::strain_functional", "اعداد کرنش «نمایشی»")
write(P("08_Documentation/Validation_Log.xlsx"), "Validation_Log", ["شناسه", "تاریخ", "آزمون", "معیار پذیرش (پیشنهادی)", "نتیجه", "وضعیت", "شاهد", "توضیحات"], V, [7, 12, 52, 28, 56, 16, 40, 50], status_col=5)
print("documentation written")
