"""scripts_export.py - تولید داده‌های پردازش‌شده (01_Processed_Data, 02_Bridge_Model, 03_Train_Model)"""
import os, sys, json, csv
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kw51lab.analysis.core import Lab, PRESETS
from kw51lab.analysis.static import self_weight
from kw51lab.bridge.geometry import *
from kw51lab.bridge.materials import materials_table
from kw51lab.bridge.sections import sections_table
from kw51lab.bridge.supports import bearings_table
from kw51lab.data.import_data import read_train_sheet, list_sheets, load_trackedmodes
from kw51lab.train.vehicle import vehicle_from_sheet
from kw51lab.train.configurations import desiro_units, vehicle_from_axles
from kw51lab.validation.modal_validation import periods

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
P = lambda *a: os.path.join(ROOT, *a)

def wcsv(path, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not rows: return
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

labs = {k: Lab(**v) for k, v in PRESETS.items()}
after = labs["پس از مقاوم‌سازی (simulate_trainpassage.m)"]; before = labs["پیش از مقاوم‌سازی (modal_analysis.m)"]
m = after.m
wcsv(P("01_Processed_Data/Geometry/nodes.csv"), nodes_table(m))
wcsv(P("01_Processed_Data/Geometry/beam_elements.csv"), beams_table(m))
wcsv(P("01_Processed_Data/Geometry/shell_elements.csv"), shells_table(m))
wcsv(P("01_Processed_Data/Geometry/key_dimensions.csv"), [dict(parameter=k, value=v) for k, v in key_dimensions(m).items()])
wcsv(P("01_Processed_Data/Material_Properties/materials.csv"), materials_table(m))
wcsv(P("01_Processed_Data/Material_Properties/sections.csv"), sections_table(m))
wcsv(P("02_Bridge_Model/Supports/bearings.csv"), bearings_table(m))
# masses
mass_rows = []
for k, lab in labs.items():
    sw = self_weight(lab); mass_rows.append(dict(model=k, total_mass_kg=sw["mass"], weight_kN=sw["weight"] / 1e3, Rz_each_kN=sw["R"][0, 2] / 1e3))
wcsv(P("02_Bridge_Model/FEM/model_masses.csv"), mass_rows)
# sensors (accelerometers)
labels = lab.SENSOR_LABELS
Sa = after.accel_matrix().tocoo()
rows = []
for i, j, v in zip(Sa.row, Sa.col, Sa.data):
    node, c = after.m.dof_list[j]
    rows.append(dict(sensor=labels[i], node=node, dof="xyzXYZ"[c], coef=v, x=after.m.nodes[node][0], y=after.m.nodes[node][1], z=after.m.nodes[node][2]))
wcsv(P("01_Processed_Data/Sensors/accelerometers_fe_definition.csv"), rows)
# train data
qc, axrows, carrows = [], [], []
for fname in ("zenodo_conventional.xlsx", "zenodo_articulated.xlsx"):
    path = P("00_Original_Files/Train_Datasets", fname)
    for sh in list_sheets(path):
        status, note = "ok", ""
        try:
            s = read_train_sheet(path, sh)
            for i, (x, pa) in enumerate(s.axles):
                axrows.append(dict(dataset=fname, train=sh, axle=i + 1, x_m=x, P_N=pa))
            try:
                v = vehicle_from_sheet(s); W, Pp = v.weight_check()
                for c in v.cars:
                    carrows.append(dict(train=sh, car=c.name, m_kg=c.m, I_kgm2=c.I, mb1=c.mb[0], mb2=c.mb[1], Ib1=c.Ib[0], Ib2=c.Ib[1],
                                        ks_N_m=c.sus_s[0].ks, cs_Ns_m=c.sus_s[0].cs, kp_N_m=c.sus_p[0].kp, cp_Ns_m=c.sus_p[0].cp,
                                        mw_kg=c.mw[0], aws_m=c.aws[0]))
                note = f"model weight / sum(P_axle) = {W/Pp:.4f}"
            except NotImplementedError as e:
                status, note = "not implemented", str(e)[:80]
            except ValueError as e:
                status, note = "dataset inconsistency", str(e)
            qc.append(dict(file=fname, train=sh, n_axles=len(s.axles), total_weight_kN=s.axles[:, 1].sum() / 1e3,
                           first_to_last_axle_m=s.axles[:, 0].max() - s.axles[:, 0].min(), status=status, note=note))
        except Exception as e:
            qc.append(dict(file=fname, train=sh, n_axles="", total_weight_kN="", first_to_last_axle_m="", status="parse error", note=repr(e)[:80]))
wcsv(P("01_Processed_Data/Train_Axles/dataset_train_axles.csv"), axrows)
wcsv(P("01_Processed_Data/Train_Axles/dataset_qc.csv"), qc)
wcsv(P("03_Train_Model/Vehicle_Parameters/dataset_vehicle_parameters.csv"), carrows)
d = desiro_units(1)
wcsv(P("03_Train_Model/Axle_Loads/desiro_ms08_reference.csv"),
     [dict(axle=i + 1, x_m=d.axle_pos[i], P_N=d.axle_loads[i], source="simulate_trainpassage.m (Maes & Lombaert 2023, table 3)") for i in range(12)])
for n in (1, 2, 3):
    t = desiro_units(n)
    wcsv(P(f"03_Train_Model/Train_Configurations/desiro_x{n}.csv"),
         [dict(axle=i + 1, x_m=t.axle_pos[i], P_N=t.axle_loads[i]) for i in range(len(t.axle_pos))])
# monitoring processed
md = load_trackedmodes(P("00_Original_Files/KW51_Monitoring/trackedmodes.mat"))
pre, post = periods(md)
envlab = None
rows = []
import scipy.io as sio
raw = sio.loadmat(P("00_Original_Files/KW51_Monitoring/trackedmodes.mat"), squeeze_me=True, struct_as_record=False)["modes"]
env_labels = list(raw.labels_env)
T = raw.env[:, 0]
for k in range(14):
    ok = pre & ~np.isnan(md["f"][:, k]) & ~np.isnan(T)
    slope = np.polyfit(T[ok], md["f"][ok, k], 1)[0] if ok.sum() > 10 else np.nan
    r = np.corrcoef(T[ok], md["f"][ok, k])[0, 1] if ok.sum() > 10 else np.nan
    rows.append(dict(mode=k + 1, f_pre_median=np.nanmedian(md["f"][pre, k]), f_post_median=np.nanmedian(md["f"][post, k]),
                     f_pre_p5=np.nanpercentile(md["f"][pre, k], 5), f_pre_p95=np.nanpercentile(md["f"][pre, k], 95),
                     xi_pre_median_assumed_percent=np.nanmedian(md["xi"][pre, k]), n_pre=int(ok.sum()),
                     dfdT_Hz_per_degC=slope, corr_f_T=r, temperature_channel=env_labels[0]))
wcsv(P("01_Processed_Data/Monitoring_Processed/modal_summary.csv"), rows)
print("env labels:", env_labels)
print("exports done")
