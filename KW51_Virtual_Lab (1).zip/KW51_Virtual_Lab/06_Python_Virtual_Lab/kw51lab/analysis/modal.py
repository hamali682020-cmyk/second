"""modal.py - تحلیل مودال: فرکانس، شکل مود، جرم مؤثر و ضریب مشارکت + پایه‌ی مودال برای تحلیل دینامیکی."""
import numpy as np
from .load_distribution import BRIDGE_LEN, track_y


def modal_table(lab, n=60):
    """frequencies, effective modal mass and mass participation ratio for x,y,z translations."""
    f, Phi, Vr = lab.modal(n)
    m = lab.m
    Mr = m.Mr
    # rigid-body influence vectors in the reduced space (translations of every node)
    dirs = []
    rows = {}
    for c in range(3):
        v = np.zeros(m.ndof)
        for node in m.node_ids:
            v[m.dofi[(int(node), c)]] = 1.0
        dirs.append(v)
    # reduced-space unit-translation vector r s.t. T r ~ rigid translation  (least squares)
    out = {"f": f, "Meff": np.zeros((n, 3)), "ratio": np.zeros((n, 3))}
    Mtot = np.array([d @ (m.M @ d) for d in dirs])
    for c in range(3):
        d = dirs[c]
        L = Vr.T @ (m.T.T @ (m.M @ d))             # participation factors  Phi_r^T T^T M d   (M-orthonormal Vr)
        out["Meff"][:, c] = L**2
        out["ratio"][:, c] = L**2 / Mtot[c]
    out["Mtot"] = Mtot
    out["cum"] = np.cumsum(out["ratio"], axis=0)
    return out


class ModalBridge:
    """Truncated modal basis of the bridge used by moving-load / moving-mass / VBI solvers."""

    def __init__(self, lab, nmodes=120, zeta=0.01):
        self.lab = lab
        self.n = nmodes
        self.f, self.Phi, self.Vr = lab.modal(nmodes)
        self.w = 2 * np.pi * self.f
        self.zeta = zeta
        self.PhiZ = self.Phi[lab.ld.dof[2], :]                  # vertical modal values at the ballast load nodes
        self._Sa = None

    # ---- load / contact interpolation vector ----------------------------------------------
    def h(self, track, x):
        idx, w = self.lab.ld.weights(x, track_y(track, x))
        if len(idx) == 0:
            return np.zeros(self.n)
        return w @ self.PhiZ[idx]

    # ---- modal functional of a response ---------------------------------------------------
    def fvec(self, group, x, kind):
        lab = self.lab
        if kind in ("ux", "uy", "uz"):
            node = lab.nearest_in_group(group, x)
            return self.Phi[lab.m.dofi[(node, "xyz".index(kind[1]))], :]
        ei, s = lab.locate(group, x)
        dofs, c = lab.beam_functional(ei, kind, s)
        return c @ self.Phi[dofs, :]

    def accel_modal(self):
        if self._Sa is None:
            self._Sa = self.lab.accel_matrix() @ self.Phi
        return self._Sa

    def static_residual_il(self, track, fv, step=0.5, cache=None):
        """IL_exact - IL_modal on the grid (unit downward load): used to correct mode truncation."""
        xs, U = cache if cache is not None else self.lab.influence(track, step)
        # exact IL for the functional given by modal vector is not available from fv alone -> caller passes exact IL
        raise NotImplementedError

    def residual_from_il(self, track, il_exact, fv, xs):
        """returns IL_exact - IL_modal on grid xs (both for unit downward load)"""
        H = np.array([self.h(track, x) for x in xs])               # (npos, n)
        il_modal = -(H / self.w**2) @ fv
        return il_exact - il_modal


def kinematics(train, x0_front, v0, a0, t):
    """MATLAB convention (simulate_trainpassage.m): front axle x_f = x0 + v0 t + a0 t^2/2 (signed v0, a0);
    other axles trail behind the front axle. returns xa (nt, naxle) and speed magnitude (nt)"""
    t = np.asarray(t)
    xf = x0_front + v0 * t + a0 * t**2 / 2
    sgn = np.sign(v0)
    xa = xf[:, None] - sgn * train.axle_pos[None, :]
    va = np.abs(v0 + a0 * t)
    return xa, va


def newmark_modal(w, zeta, F, dt, beta=0.25, gamma=0.5):
    """vectorised modal Newmark (average acceleration). F: (n, nt). returns q, qd, qdd"""
    n, nt = F.shape
    q = np.zeros((n, nt)); v = np.zeros((n, nt)); a = np.zeros((n, nt))
    a[:, 0] = F[:, 0]
    c = 2 * zeta * w
    Keff = 1 + gamma * dt * c + beta * dt**2 * w**2
    for k in range(1, nt):
        qp = q[:, k - 1] + dt * v[:, k - 1] + dt**2 * (0.5 - beta) * a[:, k - 1]
        vp = v[:, k - 1] + dt * (1 - gamma) * a[:, k - 1]
        a[:, k] = (F[:, k] - c * vp - w**2 * qp) / Keff
        q[:, k] = qp + beta * dt**2 * a[:, k]
        v[:, k] = vp + gamma * dt * a[:, k]
    return q, v, a
