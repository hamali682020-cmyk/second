"""influence_line.py - خطوط تأثیر: تغییرمکان، نیروی محوری، برش، لنگر، واکنش تکیه‌گاهی"""
import numpy as np


def reaction_il(lab, track="B", step=0.5):
    """vertical reaction influence lines of the four bearings for a unit downward load on `track`"""
    xs = np.arange(0.0, 116.316 + 1e-9, step)
    R = []
    for x in xs:
        P = lab.ld.load_vector(track, [x], [1.0], 0.0, centrifugal=False)
        U = lab.solve(P)
        R.append(lab.reactions(U, P)[:, 2])
    return xs, np.array(R)                    # (npos, 4)


def critical_axle_position(train, xs, il, direction=+1):
    """front-axle position that maximises/minimises sum(P_i * IL(x_i)); returns (fronts, response)"""
    from ..train.axle_loads import axle_positions
    fronts = np.arange(-train.length, xs.max() + train.length, 0.25)
    resp = np.array([sum(P * np.interp(x, xs, il, left=0, right=0) for x, P in
                         zip(axle_positions(train, f, direction), train.axle_loads)) for f in fronts])
    return fronts, resp
