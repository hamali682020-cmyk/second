"""moving_mass.py - جرم متحرک: هر محور = جرم متمرکز P/g که با فنر تماس سخت به پل متصل است (اینرسی لحاظ، تعلیق صفر)."""
from .vbi import run_vbi
from ..train.configurations import moving_mass_vehicle


def run_moving_mass(lab, mb, train, track, x0_front, v0, a0, dt=0.002, kH=1.0e10, **kw):
    return run_vbi(lab, mb, train, None, track, x0_front, v0, a0, dt=dt, kH=kH, masses=moving_mass_vehicle(train), **kw)
