"""static.py - تحلیل استاتیکی: وزن خود، واکنش، بار قطار در موقعیت‌های مختلف، پوش نیروهای داخلی، کرنش."""
import numpy as np
import scipy.sparse as sp

G = 9.81


def functional_matrix(lab, specs):
    """specs: list of (element_index, kind, s)  ->  sparse matrix (nf x ndof) so that values = Fm @ U_full"""
    rows, cols, vals = [], [], []
    for i, (ei, kind, s) in enumerate(specs):
        dofs, c = lab.beam_functional(ei, kind, s)
        rows += [i] * len(dofs); cols += list(dofs); vals += list(c)
    return sp.csr_matrix((vals, (rows, cols)), shape=(len(specs), lab.m.ndof))


def self_weight(lab):
    """gravity load of everything that has mass in the model (beams, plates, ballast, retrofit boxes).
    Rails, sleepers, fittings are NOT in the official model."""
    m = lab.m
    ez = np.zeros(m.ndof)
    for node in m.node_ids:
        ez[m.dofi[(int(node), 2)]] = 1.0
    P = -G * (m.M @ ez)
    U = lab.solve(P)
    R = lab.reactions(U, P)
    mass_z = float(ez @ (m.M @ ez))
    return dict(U=U, P=P, R=R, mass=mass_z, weight=mass_z * G, Rz_sum=float(R[:, 2].sum()))


def girder_specs(lab, side="A"):
    specs, xs = [], []
    for ei in lab.beam_by_group["girder" + side]:
        b = lab.m.beams[ei]; L = lab.m.beam_info[ei][3]
        specs += [(ei, "M", 0.0), (ei, "V", 0.0), (ei, "N", 0.0)]
        xs.append(lab.m.nodes[b["n1"]][0])
    last = lab.beam_by_group["girder" + side][-1]
    L = lab.m.beam_info[last][3]; b = lab.m.beams[last]
    specs += [(last, "M", L), (last, "V", L), (last, "N", L)]
    xs.append(lab.m.nodes[b["n2"]][0])
    return specs, np.array(xs)


def envelope(lab, train, track, direction=+1, speed=27.8, step=0.5, side="A"):
    """pass the train (quasi-static, loads at every `step` m of front position) and return the envelopes
    of sagging moment / vertical shear / axial force along a main girder (values at nodes)."""
    from ..train.axle_loads import axle_positions
    from .load_distribution import BRIDGE_LEN
    fronts = np.arange(-2.0, BRIDGE_LEN + train.length + 2.0, step) if direction > 0 else \
        np.arange(BRIDGE_LEN + 2.0, -train.length - 2.0, -step)
    P = np.column_stack([lab.ld.load_vector(track, axle_positions(train, f, direction), train.axle_loads, speed, centrifugal=False)
                         for f in fronts])
    U = lab.solve(P)
    specs, xs = girder_specs(lab, side)
    Fm = functional_matrix(lab, specs)
    Y = Fm @ U
    out = {"x": xs}
    for j, k in enumerate(("M", "V", "N")):
        # element-end values: first nel entries use node 1 of each element; the last row is node 2 of the last element
        nel = len(lab.beam_by_group["girder" + side])
        idx = [3 * e + j for e in range(nel)] + [3 * nel + j]
        out[k + "_max"] = Y[idx].max(axis=1); out[k + "_min"] = Y[idx].min(axis=1)
    return out


def strain_functional(lab, ei, s, y_off=0.0, z_off=0.0):
    """longitudinal strain at a fibre (y_off, z_off in the local axes) of beam element ei at distance s from node 1:
       eps = N/(EA) + z*My/(E*Iyy) - y*Mz/(E*Izz)       (internal forces, tension positive)
    NOTE: local axes follow the model (y towards the reference node). Correspondence with the physical strain-gauge
    positions of the monitoring data is NOT verified."""
    b = lab.m.beams[ei]
    E = lab.m.mats[b["mat"]][0]
    A, ky, kz, Ixx, Iyy, Izz = lab.m.secs[b["sec"]]
    d1, c1 = lab.beam_functional(ei, "N", s)
    d2, c2 = lab.beam_functional(ei, "My", s)
    d3, c3 = lab.beam_functional(ei, "Mz", s)
    return d1, c1 / (E * A) + z_off * c2 / (E * Iyy) - y_off * c3 / (E * Izz)
