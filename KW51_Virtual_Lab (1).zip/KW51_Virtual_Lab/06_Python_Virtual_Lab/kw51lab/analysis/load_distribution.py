"""
loads.py - بارگذاری قطار (پورت xrail_2_P.m): پخش بار محوری روی گره‌های بالاست
Train load vectors: port of xrail_2_P.m / force_distr (ballast node area distribution).
"""
import numpy as np

BRIDGE_LEN = 116.316
_xBr = np.array([0, 58.158, 115.658])
POLY = {"B": np.polyfit(_xBr, 3.24 + np.array([0, 1.56, 0]), 2),
        "A": np.polyfit(_xBr, 7.24 + np.array([0, 1.57, 0]), 2)}
RADIUS = {"B": 1121.0, "A": 1125.0}


def track_y(track, x):
    return np.polyval(POLY[track], x)


class LoadDistributor:
    """Distributes an axle load to the ballast nodes (areas assigned to each node)."""

    def __init__(self, model):
        m = self.m = model
        lines1 = sorted(list(range(2820, 2960, 10)) + list(range(2835, 2955, 10)))
        lines2 = list(range(2830, 2950, 10)) + list(range(2835, 2955, 10))
        ids, yL, yR, xT, xB = [], [], [], [], []
        for ln in lines2:
            pos = lines1.index(ln)
            for ix in range(2, 77):
                nid = 100 * ln + ix
                x0, y0, _ = m.nodes[nid]
                yl = y0 + 0.5 * (m.nodes[100 * lines1[pos + 1] + ix][1] - y0)
                yr = y0 + 0.5 * (m.nodes[100 * lines1[pos - 1] + ix][1] - y0)
                xt = x0 + 0.5 * (m.nodes[nid + 1][0] - x0)
                xb = x0 + 0.5 * (m.nodes[nid - 1][0] - x0)
                ids.append(nid); yL.append(yl); yR.append(yr); xT.append(xt); xB.append(xb)
        self.ids = np.array(ids)
        self.yL, self.yR, self.xT, self.xB = map(np.array, (yL, yR, xT, xB))
        self.dof = {c: np.array([m.dofi[(int(n), c)] for n in self.ids]) for c in range(6)}
        self.infl_x = 0.6 * 4
        self.infl_y = 1.435 / 2 + 0.6

    def weights(self, xP, yP):
        yLI, yRI = yP + self.infl_y, yP - self.infl_y
        xTI, xBI = xP + self.infl_x, xP - self.infl_x
        yl = np.minimum(self.yL, yLI); yr = np.maximum(self.yR, yRI)
        xt = np.minimum(self.xT, xTI); xb = np.maximum(self.xB, xBI)
        ok = (yl > yr) & (xt > xb)
        if not ok.any():
            return np.array([], int), np.array([])
        Ap = (yl - yr) * (xt - xb)
        Ap = np.where(ok, Ap, 0.0)
        if xBI < 0:
            sc = (xTI - 0) / (xTI - xBI)
        elif xTI > BRIDGE_LEN:
            sc = (BRIDGE_LEN - xBI) / (xTI - xBI)
        else:
            sc = 1.0
        sc = max(sc, 0.0)
        idx = np.nonzero(ok)[0]
        return idx, sc * Ap[idx] / Ap.sum()

    def load_vector(self, track, xaxles, axle_loads, speed=0.0, H=2.5, centrifugal=True):
        """Full-dof load vector for axles at curvilinear positions xaxles (m)."""
        P = np.zeros(self.m.ndof)
        Rad = RADIUS[track]
        for x, AL in zip(np.atleast_1d(xaxles), np.atleast_1d(axle_loads)):
            if x < -self.infl_x or x > BRIDGE_LEN + self.infl_x:
                continue
            idx, w = self.weights(x, track_y(track, x))
            if len(idx) == 0:
                continue
            P[self.dof[2][idx]] += -AL * w
            if centrifugal and speed != 0.0:
                f = AL / 9.81 * speed**2 / Rad
                P[self.dof[1][idx]] += f * w
                P[self.dof[3][idx]] += -f * H * w
        return P
