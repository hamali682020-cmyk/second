"""sensitivity.py - تحلیل حساسیت: پارامترهای مدل -> فرکانس‌ها؛ سرعت قطار -> پاسخ (تشدید)"""
import numpy as np
from .core import Lab, PRESETS


def frequency_sensitivity(base="پیش از مقاوم‌سازی (modal_analysis.m)", param="hb_rel", values=(0.9, 1.0, 1.1, 1.2), nmodes=10):
    out = []
    for v in values:
        p = dict(PRESETS[base]); p[param] = v
        lab = Lab(**p)
        f, _, _ = lab.modal(nmodes)
        out.append(f[:nmodes])
    return np.array(values), np.array(out)


def speed_sweep(lab, mb, train, track, group, x, kind, speeds_kmh, il_cache, dt=0.004, direction=+1, x0=None):
    """peak |response| of the dynamic moving-load solution for a range of constant speeds"""
    from .moving_load import run_moving_load, response
    out = []
    for vk in speeds_kmh:
        v = vk / 3.6
        v0 = direction * v
        xs = 0.0 if direction > 0 else 116.316
        res = run_moving_load(lab, mb, train, track, xs, v0, 0.0, dt=dt)
        r = response(mb, res, group, x, kind, il_cache=il_cache)
        out.append(np.abs(r).max())
    return np.array(out)
