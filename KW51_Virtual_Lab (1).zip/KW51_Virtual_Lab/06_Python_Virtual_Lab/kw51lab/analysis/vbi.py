"""
vbi.py - اندرکنش قطار و پل (Vehicle-Bridge Interaction) با پایه‌ی مودال پل و مدل چندجرمی قطار.

فرمول‌بندی: پل در مختصات مودال (n مود، M-orthonormal)، قطار صفحه‌ای ۱۰ درجه‌ی آزادی برای هر واگن،
تماس چرخ-ریل = فنر خطی هرتز k_H (بدون جدایی). حل یکپارچه‌ی نیومارک (میانگین شتاب) با ماتریس سختی متغیر با زمان.
 معادلات (حول تعادل استاتیکی قطار روی ریل صلب):
   پل  : q'' + 2ζω q' + ω² q = -Σ_w h_w [P_w + k_H (h_w·q + r_w - z_w)]
   قطار: M_v z'' + C_v z' + K_v z = Σ_w e_w k_H (h_w·q + r_w - z_w)
 h_w(t) = بردار درونیابی مودال نقطه‌ی تماس (پخش سطحی بار روی گره‌های بالاست).
محدودیت‌ها (ثبت‌شده): فقط ارتعاش قائم، تماس دائم (جدایی فقط تشخیص داده می‌شود)، ناهمواری ریل پیش‌فرض صفر،
مدل ریل/تراورس/بالاست مجزا وجود ندارد (مدل Track در این نسخه پیاده‌سازی نشده است).
"""
import numpy as np
from .modal import kinematics
from .load_distribution import BRIDGE_LEN
from .moving_load import time_vector

KH_DEFAULT = 1.0e9      # [N/m] linearised wheel-rail contact stiffness  (ASSUMPTION, typical order of magnitude)


def run_vbi(lab, mb, train, vehicle, track, x0_front, v0, a0, dt=0.002, kH=KH_DEFAULT, t=None,
            rail_irregularity=None, masses=None):
    """vehicle: Vehicle (multi-body)  or None together with `masses` (list of axle masses) for the moving-mass model."""
    if t is None:
        t = time_vector(train, x0_front, v0, a0, dt)
    nt = len(t); n = mb.n
    xa, va = kinematics(train, x0_front, v0, a0, t)
    nax = len(train.axle_pos)
    if vehicle is not None:
        Mv, Cv, Kv = vehicle.assemble(); wdof = vehicle.wheel_dofs(); P = vehicle.axle_P
        # vehicle axle order == train axle order
        assert len(wdof) == nax
    else:
        Mv = np.diag(np.asarray(masses, float)); Cv = np.zeros_like(Mv); Kv = np.zeros_like(Mv)
        wdof = np.arange(nax); P = train.axle_loads
    m = Mv.shape[0]
    N = n + m
    M = np.zeros((N, N)); C = np.zeros((N, N)); K0 = np.zeros((N, N))
    M[:n, :n] = np.eye(n); M[n:, n:] = Mv
    C[:n, :n] = np.diag(2 * mb.zeta * mb.w); C[n:, n:] = Cv
    K0[:n, :n] = np.diag(mb.w**2); K0[n:, n:] = Kv
    beta, gam = 0.25, 0.5
    x = np.zeros(N); v = np.zeros(N); a = np.zeros(N)
    q_hist = np.zeros((n, nt)); qd_hist = np.zeros((n, nt)); qdd_hist = np.zeros((n, nt))
    Fc = np.zeros((nt, nax)); z_w = np.zeros((nt, nax))
    sgn_dir = np.sign(v0)
    for k in range(nt):
        # contact vectors at this instant
        U = np.zeros((nax, N)); r = np.zeros(nax)
        Kt = K0.copy(); F = np.zeros(N)
        for w in range(nax):
            xw = xa[k, w]
            U[w, n + wdof[w]] = -1.0
            if -5 < xw < BRIDGE_LEN + 5:
                U[w, :n] = mb.h(track, xw)
            if rail_irregularity is not None:
                r[w] = rail_irregularity(xw)
            u = U[w]
            Kt += kH * np.outer(u, u)
            F[:n] += -mb.h(track, xw) * (P[w] + kH * r[w]) if np.any(U[w, :n]) else 0.0
            F[n + wdof[w]] += kH * r[w]
        if k == 0:
            a = np.linalg.solve(M, F - K0 @ x)            # train starts off-bridge in equilibrium
            q_hist[:, 0] = x[:n]; qdd_hist[:, 0] = a[:n]
            Fc[0] = P
            continue
        xp = x + dt * v + dt**2 * (0.5 - beta) * a
        vp = v + dt * (1 - gam) * a
        Aeff = M + gam * dt * C + beta * dt**2 * Kt
        rhs = F - C @ vp - Kt @ xp
        a_new = np.linalg.solve(Aeff, rhs)
        x = xp + beta * dt**2 * a_new
        v = vp + gam * dt * a_new
        a = a_new
        q_hist[:, k] = x[:n]; qd_hist[:, k] = v[:n]; qdd_hist[:, k] = a[:n]
        for w in range(nax):
            ub = U[w, :n] @ x[:n]
            zw = x[n + wdof[w]]
            Fc[k, w] = P[w] + kH * (ub + r[w] - zw)
            z_w[k, w] = zw
    return dict(t=t, q=q_hist, qd=qd_hist, qdd=qdd_hist, xa=xa, va=va, Fw=Fc, track=track, z_wheel=z_w,
                separation=bool((Fc < 0).any()), min_contact_force=float(Fc.min()), kH=kH,
                model="VBI" if vehicle is not None else "moving mass")
