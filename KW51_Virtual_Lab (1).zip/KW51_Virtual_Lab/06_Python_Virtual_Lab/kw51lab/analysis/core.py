"""
analysis.py - هسته تحلیل آزمایشگاه مجازی: استاتیکی، خط تأثیر، مودال، دینامیکی، تطبیق با داده پایش
"""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as sla
from ..bridge.fem_model import KW51Model
from .load_distribution import LoadDistributor, BRIDGE_LEN, track_y
from ..train.axle_loads import axle_positions

PRESETS = {
    "پیش از مقاوم‌سازی (modal_analysis.m)": dict(Es_rel=1, hb_rel=1.1, kxx=1e13, Id_rel=0.06, Ad_rel=0.78, fixed=1, addmass=0),
    "پس از مقاوم‌سازی (simulate_trainpassage.m)": dict(Es_rel=1, hb_rel=1.0833, kxx=0, Id_rel=0.08, Ad_rel=0.88, fixed=0, addmass=1),
}


class Lab:
    def __init__(self, **params):
        self.m = KW51Model(**params)
        self.ld = LoadDistributor(self.m)
        self.lu = sla.splu(self.m.Kr.tocsc())
        self._modal = None
        self.beam_by_group = {}
        for i, b in enumerate(self.m.beams):
            self.beam_by_group.setdefault(b["group"], []).append(i)
        self._sens = None

    # ------------------------------------------------------------------ static
    def solve(self, P_full):
        """full-dof load vector(s) -> full-dof displacement(s)"""
        Pr = self.m.T.T @ P_full
        return self.m.T @ self.lu.solve(np.asarray(Pr))

    def reactions(self, U, P):
        """bearing reactions [N1..N4] x (Rx,Ry,Rz) for U (full) and applied load P (full)"""
        m = self.m
        r = m.T0.T @ (m.K @ U - P)
        idx = {d: i for i, d in enumerate(m.masters0)}
        out = np.zeros((4, 3))
        for n in range(1, 5):
            for c in range(3):
                out[n - 1, c] = r[idx[(n, c)]]
        return out

    # ------------------------------------------------------------------ beam functionals
    def beam_functional(self, ei, kind, s=0.0):
        """returns (dofs, coef) such that value = coef @ U_full[dofs]   (kinds: N, V, M, Vy, Vz, My, Mz, T)
        N: tension +;  V: vertical shear (up on the left face +); M: sagging +  (global-vertical-plane moment)
        s = distance from node 1 (m)."""
        dofs, Tm, Kl, L = self.m.beam_info[ei]
        A = Kl @ Tm
        B = Tm.T @ A
        ex = Tm[0, :3]
        h = np.cross(ex, [0, 0, 1.0]); nh = np.linalg.norm(h)
        h = h / nh if nh > 1e-9 else np.zeros(3)
        xi = s / L
        if kind == "N":   c = A[6]
        elif kind == "V":  c = B[2]
        elif kind == "M":  c = (1 - xi) * (-(h @ B[3:6])) + xi * (h @ B[9:12])
        elif kind == "Vy": c = A[1]
        elif kind == "Vz": c = A[2]
        elif kind == "T":  c = A[3]
        elif kind == "My": c = (1 - xi) * (-A[4]) + xi * A[10]
        elif kind == "Mz": c = (1 - xi) * (-A[5]) + xi * A[11]
        else: raise ValueError(kind)
        return dofs, c

    def locate(self, group, x):
        """element of `group` containing x -> (element index, s)"""
        best = None
        for ei in self.beam_by_group[group]:
            b = self.m.beams[ei]
            x1, x2 = self.m.nodes[b["n1"]][0], self.m.nodes[b["n2"]][0]
            if min(x1, x2) - 1e-9 <= x <= max(x1, x2) + 1e-9:
                L = self.m.beam_info[ei][3]
                return ei, (x - x1) / (x2 - x1) * L
            d = min(abs(x - x1), abs(x - x2))
            if best is None or d < best[0]:
                best = (d, ei)
        ei = best[1]; b = self.m.beams[ei]
        x1, x2 = self.m.nodes[b["n1"]][0], self.m.nodes[b["n2"]][0]
        L = self.m.beam_info[ei][3]
        return ei, float(np.clip((x - x1) / (x2 - x1), 0, 1)) * L

    def response(self, U, group, x, kind):
        """kind in {'uz','uy','ux'} -> displacement of nearest node of the group; or beam force kind"""
        if kind in ("ux", "uy", "uz"):
            n = self.nearest_in_group(group, x)
            return U[self.m.dofi[(n, "xyz".index(kind[1]))]]
        ei, s = self.locate(group, x)
        dofs, c = self.beam_functional(ei, kind, s)
        return c @ U[dofs]

    def nearest_in_group(self, group, x):
        ei, s = self.locate(group, x)
        b = self.m.beams[ei]
        L = self.m.beam_info[ei][3]
        return b["n1"] if s < L / 2 else b["n2"]

    def girder_diagram(self, U, side="A"):
        """x, N, V, M(sag) along main girder A or C (values at nodes, element-end values)"""
        g = "girder" + side
        xs, Ms, Vs, Ns = [], [], [], []
        for ei in self.beam_by_group[g]:
            b = self.m.beams[ei]; L = self.m.beam_info[ei][3]
            x1 = self.m.nodes[b["n1"]][0]; x2 = self.m.nodes[b["n2"]][0]
            for (x, s) in ((x1, 0.0), (x2, L)):
                dofs, c = self.beam_functional(ei, "M", s); Ms.append(c @ U[dofs])
                dofs, c = self.beam_functional(ei, "V", s); Vs.append(c @ U[dofs])
                dofs, c = self.beam_functional(ei, "N", s); Ns.append(c @ U[dofs])
                xs.append(x)
        return np.array(xs), np.array(Ns), np.array(Vs), np.array(Ms)

    # ------------------------------------------------------------------ influence lines
    def influence(self, track="B", step=0.5, comps=("z",)):
        """Unit vertical load (1 N down) moving along a track. Returns positions and U_full (ndof x npos)."""
        xs = np.arange(0.0, BRIDGE_LEN + 1e-9, step)
        cols = [self.ld.load_vector(track, [x], [1.0], 0.0, centrifugal=False) for x in xs]
        P = np.column_stack(cols)
        U = self.solve(P)
        return xs, U

    def influence_line(self, track, group, xr, kind, step=0.5, cache=None):
        xs, U = cache if cache is not None else self.influence(track, step)
        if kind in ("ux", "uy", "uz"):
            n = self.nearest_in_group(group, xr)
            il = U[self.m.dofi[(n, "xyz".index(kind[1]))]]
        else:
            ei, s = self.locate(group, xr)
            dofs, c = self.beam_functional(ei, kind, s)
            il = c @ U[dofs]
        return xs, il

    def deck_point_il(self, track, x, y, step=0.5, cache=None):
        """vertical displacement IL at the plate/deck node nearest to (x,y)"""
        xs, U = cache if cache is not None else self.influence(track, step)
        n = self.nearest_deck_node(x, y)
        return xs, U[self.m.dofi[(n, 2)]], n

    def nearest_deck_node(self, x, y):
        """deck (steel plate) node nearest to (x, y)"""
        best, bd = None, 1e18
        for n, (xx, yy, zz) in self.m.nodes.items():
            if 181 <= n // 1000 <= 196 and (n % 1000) != 0:
                d = (xx - x) ** 2 + (yy - y) ** 2
                if d < bd:
                    best, bd = n, d
        return best

    # ------------------------------------------------------------------ train passage
    def passage(self, train, track="B", speed=27.78, direction=+1, dt=None, pad=5.0, centrifugal=True):
        """quasi-static passage. returns t, front positions, P matrix (full), U matrix (full)"""
        span = BRIDGE_LEN + train.length + 2 * pad
        if dt is None:
            dt = 0.25 / speed                       # one point every 0.25 m
        t = np.arange(0, span / speed + dt, dt)
        front = (-pad + speed * t) if direction > 0 else (BRIDGE_LEN + pad - speed * t)
        cols = []
        for fx in front:
            xa = axle_positions(train, fx, direction)
            cols.append(self.ld.load_vector(track, xa, train.axle_loads, speed, centrifugal=centrifugal))
        P = np.column_stack(cols)
        U = self.solve(P)
        return t, front, P, U

    # ------------------------------------------------------------------ modal
    def modal(self, n=40):
        if self._modal is None or self._modal[0] < n:
            vals, vecs = sla.eigsh(self.m.Kr, k=n, M=self.m.Mr, sigma=0, which="LM")
            o = np.argsort(vals)
            vals, vecs = vals[o], vecs[:, o]
            f = np.sqrt(np.abs(vals)) / (2 * np.pi)
            Phi = self.m.T @ vecs
            self._modal = (n, f, Phi, vecs)
        n_, f, Phi, vecs = self._modal
        return f[:n], Phi[:, :n], vecs[:, :n]

    # ------------------------------------------------------------------ dynamic (modal superposition)
    def dynamic(self, t, P, nmodes=40, zeta=0.01, U_qs=None):
        """Modal-superposition response with mode-acceleration (static) correction.
        P: full load matrix (ndof x nt). Returns U_dyn (ndof x nt)."""
        f, Phi, Vr = self.modal(nmodes)
        w = 2 * np.pi * f
        Pr = self.m.T.T @ P
        F = Vr.T @ Pr                                # modal forces (n x nt) (Vr is M-orthonormal)
        dt = t[1] - t[0]
        n, nt = F.shape
        q = np.zeros((n, nt)); v = np.zeros(n); a = F[:, 0].copy()
        beta, gam = 0.25, 0.5
        c = 2 * zeta * w
        Keff = w**2 + gam / (beta * dt) * c + 1 / (beta * dt**2)
        for k in range(1, nt):
            rhs = (F[:, k]
                   + (1 / (beta * dt**2) * q[:, k - 1] + 1 / (beta * dt) * v + (1 / (2 * beta) - 1) * a)
                   + c * (gam / (beta * dt) * q[:, k - 1] + (gam / beta - 1) * v + dt * (gam / (2 * beta) - 1) * a))
            q[:, k] = rhs / Keff
            an = 1 / (beta * dt**2) * (q[:, k] - q[:, k - 1]) - 1 / (beta * dt) * v - (1 / (2 * beta) - 1) * a
            v = v + dt * ((1 - gam) * a + gam * an); a = an
        qs = F / w[:, None] ** 2                       # modal static part
        if U_qs is None:
            U_qs = self.solve(P)
        return U_qs + Phi @ (q - qs)

    # ------------------------------------------------------------------ sensors (accelerometers) & MAC
    def accel_matrix(self):
        if self._sens is not None:
            return self._sens
        m = self.m
        spec = [(101, 34.558, [(1, 2, 1.0)]), (101, 58.158, [(1, 1, 1.0), (3, 0.12194, 0)]),
                ]
        def row(grp, x, terms):
            node = grp * 1000 + int(np.argmin(abs(m.xn - x))) + 1
            r = {}
            for comp, coef in terms:
                r[m.dofi[(node, comp)]] = r.get(m.dofi[(node, comp)], 0) + coef
            return r
        arch = lambda g, x: row(g, x, [(1, 1.0), (3, (271.94 - 150) / 1000)])
        rows = [
            row(101, 34.558, [(2, 1.0)]),
            row(101, 58.158, [(1, 1.0), (3, (271.94 - 150) / 1000)]),
            row(101, 58.158, [(2, 1.0)]),
            row(102, 58.158, [(2, 1.0)]),
            row(101, 81.758, [(1, 1.0), (3, (271.94 - 150) / 1000)]),
            row(101, 81.758, [(2, 1.0)]),
            arch(103, 28.658), arch(104, 28.658), arch(103, 52.258), arch(104, 52.258),
            arch(103, 75.858), arch(104, 75.858)]
        S = sp.lil_matrix((12, m.ndof))
        for i, r in enumerate(rows):
            for d, c in r.items():
                S[i, d] = c
        self._sens = S.tocsr()
        return self._sens

    SENSOR_LABELS = ['aBD11Az', 'aBD17Ay', 'aBD17Az', 'aBD17Cz', 'aBD23Ay', 'aBD23Az',
                     'aAR0910Ay', 'aAR0910Cy', 'aAR1516Ay', 'aAR1516Cy', 'aAR2122Ay', 'aAR2122Cy']

    def fe_sensor_shapes(self, n=40):
        f, Phi, _ = self.modal(n)
        return f, self.accel_matrix() @ Phi


def mac(a, b):
    a = np.asarray(a); b = np.asarray(b)
    num = np.abs(np.conj(a).T @ b) ** 2
    return num / (np.sum(np.abs(a) ** 2, axis=0)[:, None] * np.sum(np.abs(b) ** 2, axis=0)[None, :])


def measured_modes(path):
    """load trackedmodes.mat -> dict with time, f (nt x 14), xi, shapes (14 x 12 real), temp"""
    import scipy.io as sio
    d = sio.loadmat(path, squeeze_me=True, struct_as_record=False)["modes"]
    shapes = np.full((14, 12), np.nan)
    for k in range(14):
        X = d.m[:, k, :]
        ok = ~np.isnan(X).any(axis=1)
        if ok.sum() < 5:
            continue
        X = X[ok]
        X = X / np.linalg.norm(X, axis=1, keepdims=True)
        w, V = np.linalg.eigh(X.conj().T @ X)
        v = V[:, -1]
        v = v * np.exp(-1j * np.angle(v[np.argmax(np.abs(v))]))
        shapes[k] = np.real(v) / np.linalg.norm(np.real(v))
    return dict(sdn=d.sdn, f=d.f, xi=d.xi, shapes=shapes, temp=d.env[:, 0], labels=list(d.labels_m))


def match_modes(f_fe, S_fe, f_meas, shapes, window=0.12):
    """For each measured mode: FE mode with the highest MAC among FE modes within +-window of the measured frequency."""
    Mc = mac(S_fe, shapes.T)
    out = []
    for k in range(shapes.shape[0]):
        if np.isnan(f_meas[k]) or np.isnan(shapes[k]).any():
            out.append((k, None, np.nan, np.nan)); continue
        cand = np.nonzero(np.abs(f_fe / f_meas[k] - 1) <= window)[0]
        if len(cand) == 0:
            out.append((k, None, np.nan, np.nan)); continue
        j = cand[np.argmax(Mc[cand, k])]
        out.append((k, int(j), float(Mc[j, k]), float(100 * (f_fe[j] / f_meas[k] - 1))))
    return out, Mc
