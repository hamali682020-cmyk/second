"""moving_load.py - بار متحرک: حل شبه‌استاتیکی (مستقیم) و دینامیکی (برهم‌نهی مودال، با جبران مودهای حذف‌شده)."""
import numpy as np
from .modal import ModalBridge, kinematics, newmark_modal
from .load_distribution import BRIDGE_LEN


def time_vector(train, x0_front, v0, a0, dt, t_start=-2.0, pad=3.0):
    """from t_start until the last axle has left the bridge (+pad seconds).
    Only the FIRST crossing is simulated: if the train decelerates to a stop (v0*a0<0) the kinematics are cut
    at the stopping time, so that the (non-physical) return of the polynomial trajectory is never included."""
    t_stop = 400.0
    if a0 * v0 < 0:
        t_stop = -v0 / a0
    t_all = np.arange(t_start, t_stop, dt)
    xa, _ = kinematics(train, x0_front, v0, a0, t_all)
    inside = ((xa > -5) & (xa < BRIDGE_LEN + 5)).any(axis=1)
    first = int(np.argmax(inside))
    after = np.nonzero(~inside[first:])[0]
    end = (first + int(after[0])) if len(after) else len(t_all) - 1
    end = min(end + int(pad / dt), len(t_all) - 1)
    return t_all[:end + 1]


def run_moving_load(lab, mb, train, track, x0_front, v0, a0, dt=0.01, t=None, centrifugal=False):
    """Dynamic moving-load response (modal). returns dict(t, q, qd, qdd, xa, Fw)"""
    if t is None:
        t = time_vector(train, x0_front, v0, a0, dt)
    xa, va = kinematics(train, x0_front, v0, a0, t)
    n = mb.n
    F = np.zeros((n, len(t)))
    for k in range(len(t)):
        for x, AL in zip(xa[k], train.axle_loads):
            if -5 < x < BRIDGE_LEN + 5:
                F[:, k] -= AL * mb.h(track, x)
    q, qd, qdd = newmark_modal(mb.w, mb.zeta, F, t[1] - t[0])
    return dict(t=t, q=q, qd=qd, qdd=qdd, xa=xa, va=va, Fw=np.tile(train.axle_loads, (len(t), 1)), track=track)


def response(mb, res, group, x, kind, il_cache=None, il_exact=None):
    """time history of a response functional from a modal result; mode-truncation is corrected with the
    exact influence line (static residual) when `il_cache`=(xs,U) of the same track is given."""
    fv = mb.fvec(group, x, kind)
    r = fv @ res["q"]
    if il_cache is not None:
        xs, U = il_cache
        lab = mb.lab
        if il_exact is None:
            _, il_exact = lab.influence_line(res["track"], group, x, kind, cache=il_cache)
        corr = mb.residual_from_il(res["track"], il_exact, fv, xs)
        for j in range(res["xa"].shape[1]):
            r = r + res["Fw"][:, j] * np.interp(res["xa"][:, j], xs, corr, left=0, right=0)
    return r


def acceleration(mb, res, sensor_index):
    return mb.accel_modal()[sensor_index] @ res["qdd"]
