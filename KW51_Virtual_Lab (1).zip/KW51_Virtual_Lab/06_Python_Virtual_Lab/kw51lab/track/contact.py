"""contact.py - مدل ریل/مسیر (Train-Track-Bridge Interaction)  *** پیاده‌سازی نشده ***

وضعیت: STUB. طبق الزامات پروژه، تا زمانی که اجزای این مدل در معادلات و حل عددی حضور نداشته باشند،
هیچ ادعایی درباره‌ی مدل «قطار–ریل–پل» ثبت نمی‌شود. بار قطار در نسخه‌ی فعلی مستقیماً روی گره‌های بالاست
اعمال می‌شود (پورت xrail_2_P.m) و ریل/تراورس/پد جداگانه مدل نشده‌اند. ناهمواری ریل: داده‌ی مرجع در دست نیست.
"""
IMPLEMENTED = False


def build(*args, **kwargs):
    raise NotImplementedError("track model (contact) is not implemented - see 08_Documentation/Validation_Log.xlsx")
