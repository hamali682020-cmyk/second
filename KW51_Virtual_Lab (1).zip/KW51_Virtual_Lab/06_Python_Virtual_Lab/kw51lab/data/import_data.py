"""import_data.py - خواندن داده‌های ورودی: مجموعه‌داده‌ی قطارهای Zenodo (xlsx) و مودهای ردیابی‌شده‌ی KW51."""
import numpy as np
import openpyxl
from dataclasses import dataclass, field


def _clean(v):
    if isinstance(v, str):
        s = v.strip().strip("'").strip('"')
        if s.lower() == "nan":
            return np.nan
        return s
    return v


@dataclass
class RawTrainSheet:
    name: str
    meta: dict
    carbodies: list          # list of dicts (one per car, in train order)
    bogies: dict
    wheels: dict
    axles: np.ndarray        # (n,2): x [m], P [N]
    source_file: str = ""


def read_train_sheet(path, sheet):
    ws = openpyxl.load_workbook(path, data_only=True)[sheet]
    rows = [[_clean(c) for c in r] for r in ws.iter_rows(values_only=True)]
    def find(label, start=0):
        for i in range(start, len(rows)):
            if isinstance(rows[i][0], str) and rows[i][0].lower().startswith(label):
                return i
        raise KeyError(label)
    meta = dict(name=sheet, type=rows[1][1] if rows[1][0] == "type" else rows[1][1],
                year=rows[2][1] if rows[2][0] and "source" in str(rows[2][0]) else None,
                author=rows[3][1] if len(rows[3]) > 1 else None, title=rows[4][1] if len(rows[4]) > 1 else None)
    # carbodies
    i = find("carbodies"); hdr = find("name", i); j = hdr + 1
    cols = rows[hdr]
    cars = []
    while j < len(rows) and rows[j][0] not in (None, "bogies"):
        cars.append({str(cols[k]): rows[j][k] for k in range(len(cols)) if cols[k] is not None}); j += 1
    # bogies
    i = find("bogies", j); hdr = find("name", i); j = hdr + 1; cols = rows[hdr]; bogies = {}
    while j < len(rows) and rows[j][0] not in (None,):
        if str(rows[j][0]).startswith("wheels"):
            break
        bogies[rows[j][0]] = {str(cols[k]): rows[j][k] for k in range(len(cols)) if cols[k] is not None}; j += 1
    # wheels
    i = find("wheels", j); hdr = find("name", i); j = hdr + 1; cols = rows[hdr]; wheels = {}
    while j < len(rows) and rows[j][0] not in (None,):
        wheels[rows[j][0].strip("'")] = {str(cols[k]): rows[j][k] for k in range(len(cols)) if cols[k] is not None}; j += 1
    # axles
    i = find("train", j) if any(isinstance(r[0], str) and r[0].lower() == "train" for r in rows[j:]) else find("xaxle", j)
    hdr = find("xaxle", i) if not str(rows[i][0]).lower().startswith("xaxle") else i
    ax = []
    for r in rows[hdr + 1:]:
        if isinstance(r[0], (int, float)) and isinstance(r[1], (int, float)):
            ax.append((float(r[0]), float(r[1])))
    return RawTrainSheet(sheet, meta, cars, {k.strip("'"): v for k, v in bogies.items()}, wheels, np.array(ax), path)


def list_sheets(path):
    return openpyxl.load_workbook(path, read_only=True).sheetnames


def load_trackedmodes(path):
    """trackedmodes.mat -> dict (sdn, f, xi, shapes (14x12 real), temp, labels)"""
    from ..analysis.core import measured_modes
    return measured_modes(path)
