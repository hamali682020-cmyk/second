"""
trains.py - تعریف قطار (کوتاه / بلند) با واگن یکسان  |  Train definitions.
"""
import numpy as np
from dataclasses import dataclass


@dataclass
class Train:
    name: str
    axle_loads: np.ndarray        # N
    axle_pos: np.ndarray          # m, measured from the front axle backwards (0 = front axle)

    @property
    def length(self):
        return float(self.axle_pos.max() - self.axle_pos.min())

    @property
    def total_weight(self):
        return float(self.axle_loads.sum())


def wagon_train(n_wagons, axle_load=110e3, bogie_wheelbase=2.5, bogie_spacing=19.0,
                wagon_length=26.4, name=None):
    """Identical wagons: each has 2 bogies x 2 axles. wagon_length = distance between
    the centres of two successive wagons (coupling to coupling)."""
    pos, k = [], 0
    for w in range(n_wagons):
        c = w * wagon_length                       # wagon centre
        for b in (-bogie_spacing / 2, +bogie_spacing / 2):
            for a in (-bogie_wheelbase / 2, +bogie_wheelbase / 2):
                pos.append(c + b + a)
    pos = np.array(pos); pos -= pos.min()
    return Train(name or f"{n_wagons} wagons", np.full(len(pos), float(axle_load)), pos)


def desiro_ms08():
    """Axle pattern of the Desiro train used in simulate_trainpassage.m (kN -> N)."""
    AL = np.array([132.0, 131.4, 116.8, 116.4, 94.7, 94.6, 94.6, 94.7, 116.4, 116.8, 131.4, 132.0]) * 1e3
    dxa = np.array([0.0, 2.3, 18.6, 20.9, 26.1, 28.4, 44.7, 47.0, 52.2, 54.5, 70.8, 73.1])
    return Train("Desiro (از simulate_trainpassage.m)", AL, dxa)


def axle_positions(train, front_x, direction=+1):
    """Curvilinear x of each axle when the front axle is at front_x.
    direction=+1: moving to +x (front is the highest x)."""
    return front_x - direction * train.axle_pos
