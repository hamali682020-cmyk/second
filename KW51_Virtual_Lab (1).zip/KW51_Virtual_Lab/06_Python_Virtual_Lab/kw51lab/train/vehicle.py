"""
vehicle.py - مدل چندجرمی قطار در صفحه‌ی قائم (بدنه + ۲ بوژی + ۴ چرخ‌ست برای هر واگن)
Planar (vertical) multi-body model following the Glatz & Fink / Kouroussis data layout of the Zenodo train sets.
DOF per car: [zc, thc, zb1, thb1, zb2, thb2, zw1..zw4]   (z up, th = rotation with z_point = z + s*th, s along +x)
Only 'conventional' (non-articulated) cars are implemented; articulated trains raise NotImplementedError.
"""
import numpy as np
from dataclasses import dataclass, field
from .suspension import Suspension

G = 9.81


@dataclass
class Car:
    name: str
    m: float; I: float
    mb: list; Ib: list; aws: list           # per bogie (2)
    mw: list                                # wheelset mass per axle (4)
    sus_s: list                             # secondary Suspension per bogie (2)  (kp,cp unused)
    sus_p: list                             # primary Suspension per axle (4)
    s_bogie: list                           # bogie centre offset from carbody CG (2)  [m]
    x_axles: list                           # absolute axle positions (4) [m]
    P_axles: list                           # published static axle loads (4) [N]
    kind: str = "conventional"


@dataclass
class Vehicle:
    name: str
    cars: list
    source: dict = field(default_factory=dict)
    assumptions: list = field(default_factory=list)

    @property
    def axle_x(self):
        return np.array([x for c in self.cars for x in c.x_axles])

    @property
    def axle_P(self):
        return np.array([p for c in self.cars for p in c.P_axles])

    @property
    def length_axles(self):
        return float(self.axle_x.max() - self.axle_x.min())

    @property
    def mass_model(self):
        return sum(c.m + sum(c.mb) + sum(c.mw) for c in self.cars)

    def weight_check(self):
        """model weight vs published axle loads (N)"""
        return self.mass_model * G, float(self.axle_P.sum())

    @property
    def ndof(self):
        return 10 * len(self.cars)

    def wheel_dofs(self):
        return np.array([10 * k + 6 + j for k in range(len(self.cars)) for j in range(4)])

    def assemble(self):
        """dense M, C, K of the free vehicle (no contact)"""
        n = self.ndof
        M = np.zeros((n, n)); C = np.zeros((n, n)); K = np.zeros((n, n))
        for k, c in enumerate(self.cars):
            o = 10 * k
            M[o, o] = c.m; M[o + 1, o + 1] = c.I
            for j in range(2):
                M[o + 2 + 2 * j, o + 2 + 2 * j] = c.mb[j]; M[o + 3 + 2 * j, o + 3 + 2 * j] = c.Ib[j]
            for a in range(4):
                M[o + 6 + a, o + 6 + a] = c.mw[a]

            def spring(L, kk, cc):
                nonlocal K, C
                K += kk * np.outer(L, L); C += cc * np.outer(L, L)
            for j in range(2):                                  # secondary
                L = np.zeros(n); L[o] = 1; L[o + 1] = c.s_bogie[j]; L[o + 2 + 2 * j] = -1
                spring(L, c.sus_s[j].ks, c.sus_s[j].cs)
            for a in range(4):                                  # primary
                j = a // 2
                off = c.x_axles[a] - (c.x_axles[2 * j] + c.x_axles[2 * j + 1]) / 2
                L = np.zeros(n); L[o + 2 + 2 * j] = 1; L[o + 3 + 2 * j] = off; L[o + 6 + a] = -1
                spring(L, c.sus_p[a].kp, c.sus_p[a].cp)
        return M, C, K

    def natural_frequencies(self, on_rigid_track=False):
        """free vehicle (rigid-body modes dropped) or, with on_rigid_track=True, wheelsets clamped to the rails"""
        M, C, K = self.assemble()
        if on_rigid_track:
            keep = np.setdiff1d(np.arange(self.ndof), self.wheel_dofs())
            M, K = M[np.ix_(keep, keep)], K[np.ix_(keep, keep)]
        w = np.linalg.eigvals(np.linalg.solve(M, K))
        f = np.sort(np.sqrt(np.abs(w.real))) / (2 * np.pi)
        return f[f > 1e-3]


def vehicle_from_sheet(sheet):
    """RawTrainSheet (conventional train) -> Vehicle with data exactly as published in the dataset."""
    from ..data.import_data import RawTrainSheet
    s = sheet
    if "articulated" in str(s.meta.get("type", "")).lower() or any("articulated" in str(c.get("type", "")) for c in s.carbodies):
        raise NotImplementedError("articulated trains (shared bogies / carbody coupling) are not implemented yet")
    ax = s.axles
    n_decl = sum(int(cb["naxles"]) for cb in s.carbodies)
    if n_decl != len(ax):
        raise ValueError(f"dataset inconsistency in '{s.name}': carbody table declares {n_decl} axles, train table has {len(ax)}")
    cars, idx = [], 0
    for ci, cb in enumerate(s.carbodies):
        na = int(cb["naxles"])
        if na != 4:
            raise NotImplementedError("only 4-axle cars supported")
        xa = ax[idx:idx + 4, 0]; Pa = ax[idx:idx + 4, 1]; idx += 4
        b = [s.bogies[cb["bogie1"]], s.bogies[cb["bogie2"]]]
        wn = [cb["wheel1"], cb["wheel2"], cb["wheel3"], cb["wheel4"]]
        w = [s.wheels[x] for x in wn]
        c1 = (xa[0] + xa[1]) / 2; c2 = (xa[2] + xa[3]) / 2
        cg = c1 + cb["ab1 [m]"]                                   # bogie1 -> CG distance given by the dataset
        cars.append(Car(
            name=f"{cb['name']}({cb['label']})", m=cb["m [kg]"], I=next(v for k, v in cb.items() if k.startswith("I") and "kgm2" in k),
            mb=[bb["m [kg]"] for bb in b], Ib=[bb["I [kgm2]"] for bb in b], aws=[bb["aws [m]"] for bb in b],
            mw=[2 * ww["m [kg]"] for ww in w],
            sus_s=[Suspension(2 * bb["ks [N/m]"], 2 * bb["cs [Ns/m]"], 0, 0) for bb in b],
            sus_p=[Suspension(0, 0, 2 * ww["kp [N/m]"], 2 * ww["cp [Ns/m]"]) for ww in w],
            s_bogie=[c1 - cg, c2 - cg], x_axles=list(xa), P_axles=list(Pa)))
    return Vehicle(s.name, cars, source=dict(file=s.source_file, sheet=s.name, **{k: v for k, v in s.meta.items()}))
