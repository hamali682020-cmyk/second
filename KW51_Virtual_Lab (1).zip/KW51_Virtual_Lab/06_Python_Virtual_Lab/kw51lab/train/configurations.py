"""
configurations.py - پیکربندی قطارها: قطار مرجع KW51 (Desiro MS08)، چند مجموعه‌ی متصل، حالت کنترل‌شده‌ی جرم.

وضعیت اطلاعات:
 * آرایش محورها و بار محورها: از simulate_trainpassage.m (مرجع [Maes & Lombaert 2023, table 3]) = اطلاعات واقعی KW51
 * پارامترهای واگن/تعلیق Desiro MS08: در دسترس نیست  ->  آنالوگ از مجموعه‌داده‌ی Zenodo (فرضی، باید تأیید شود)
 * فاصله‌ی بین دو مجموعه‌ی متصل و اتصال سه مجموعه: فرضی (تأیید عملیاتی نشده)
"""
import copy
import numpy as np
from .axle_loads import Train, desiro_ms08
from .vehicle import Vehicle, Car, G
from .suspension import Suspension

# kinematics of the two reference passages of simulate_trainpassage.m
REFERENCE_PASSAGES = {
    "عبور ۱: Desiro، خط B، از لوون (۲۸ ژوئن ۲۰۲۰ 06:50 UTC)": dict(track="B", x0_front=116.316, direction=-1, v0=27.95, a=-0.343, t=(-2.0, 10.0)),
    "عبور ۲: Desiro، خط A، از بروکسل (۵ سپتامبر ۲۰۲۰ 21:11 UTC)": dict(track="A", x0_front=0.0, direction=+1, v0=27.84, a=-0.626, t=(-2.0, 10.0)),
}
INTER_UNIT_GAP = 5.2          # [m] ASSUMPTION: same as the intercar distance 20.9 -> 26.1 m of the Desiro pattern


def desiro_units(n_units=1, gap=INTER_UNIT_GAP):
    """n coupled Desiro MS08 sets (12 axles each). Axle pattern/load: simulate_trainpassage.m. Coupling gap: ASSUMPTION."""
    base = desiro_ms08()
    pos, P = [], []
    for u in range(n_units):
        off = u * (base.axle_pos.max() + gap)
        pos += list(base.axle_pos + off); P += list(base.axle_loads)
    return Train(f"Desiro MS08 × {n_units}", np.array(P), np.array(pos))


def mass_normalised(train, total_weight=None, ref=None):
    """Control case: scale axle loads so that the total weight equals that of `ref` (default: one Desiro unit),
    isolating the effect of train length / axle arrangement from the effect of total mass."""
    tw = total_weight if total_weight is not None else (ref or desiro_ms08()).axle_loads.sum()
    s = tw / train.axle_loads.sum()
    return Train(train.name + " (جرم کل ثابت)", train.axle_loads * s, train.axle_pos.copy())


def train_length_physical(train, car_overhang=2.0):
    """physical length != first-to-last axle distance; the overhang is an ASSUMPTION (documented) unless known."""
    return float(train.axle_pos.max() - train.axle_pos.min()) + 2 * car_overhang


def vehicle_from_axles(train, analog: Vehicle, axles_per_car=4):
    """Vehicle (multi-body) with the axle positions/loads of `train` and the dynamic parameters of an analog
    unpowered car taken from a dataset train. Car body mass is set so that the model weight equals the axle loads.
    ASSUMPTION - to be replaced by real Desiro MS08 data."""
    ref = analog.cars[len(analog.cars) // 2]            # a middle (unpowered) car of the analog train
    ncar = len(train.axle_pos) // axles_per_car
    cars = []
    for k in range(ncar):
        sl = slice(4 * k, 4 * k + 4)
        xa = train.axle_pos[sl]; Pa = train.axle_loads[sl]
        Wtot = Pa.sum()
        m_unsprung = sum(ref.mb) + sum(ref.mw)
        mcb = Wtot / G - m_unsprung
        c1 = (xa[0] + xa[1]) / 2; c2 = (xa[2] + xa[3]) / 2; cg = (c1 + c2) / 2
        scale = mcb / ref.m
        cars.append(Car(name=f"car{k+1}", m=mcb, I=ref.I * scale, mb=list(ref.mb), Ib=list(ref.Ib), aws=list(ref.aws),
                        mw=list(ref.mw), sus_s=list(ref.sus_s), sus_p=list(ref.sus_p),
                        s_bogie=[c1 - cg, c2 - cg], x_axles=list(xa), P_axles=list(Pa)))
    v = Vehicle(train.name + " (multi-body, analog parameters)", cars)
    v.assumptions = [f"suspension/bogie/wheel parameters taken from dataset train '{analog.name}' (unpowered car): NOT Desiro data",
                     "car body mass derived from published axle loads", "carbody pitch inertia scaled with mass"]
    return v


def moving_mass_vehicle(train):
    """Each axle = lumped mass P/g rigidly following the bridge (moving-mass idealisation)."""
    return [P / G for P in train.axle_loads]
