"""suspension.py - پارامترهای تعلیق (ثانویه بین بدنه و بوژی، اولیه بین بوژی و چرخ‌ست)"""
from dataclasses import dataclass


@dataclass(frozen=True)
class Suspension:
    ks: float      # secondary stiffness, both sides together [N/m]  (= 2 x per-side value of the dataset)
    cs: float      # secondary damping [Ns/m]
    kp: float      # primary stiffness per wheelset [N/m]  (= 2 x per-element value)
    cp: float      # primary damping per wheelset [Ns/m]
