"""metrics.py - معیارهای کمی اعتبارسنجی"""
import numpy as np
from scipy import signal


def rel_error(model, ref):
    return (np.asarray(model) - np.asarray(ref)) / np.asarray(ref)


def mac(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    return float((a @ b) ** 2 / ((a @ a) * (b @ b)))


def rmse(sim, meas):
    sim, meas = np.asarray(sim), np.asarray(meas)
    return float(np.sqrt(np.mean((sim - meas) ** 2)))


def nrmse(sim, meas):
    meas = np.asarray(meas)
    return rmse(sim, meas) / float(np.ptp(meas))


def corrcoef(sim, meas):
    return float(np.corrcoef(sim, meas)[0, 1])


def peak_difference(sim, meas):
    """relative difference of the maximum absolute amplitude"""
    ps, pm = np.max(np.abs(sim)), np.max(np.abs(meas))
    return float((ps - pm) / pm)


def peak_time_difference(t, sim, meas):
    """time shift [s] between the largest-|.| peaks"""
    return float(t[np.argmax(np.abs(sim))] - t[np.argmax(np.abs(meas))])


def spectral_comparison(t, sim, meas, nperseg=None):
    fs = 1.0 / np.median(np.diff(t))
    nperseg = nperseg or min(len(t), 1024)
    f, Ps = signal.welch(sim, fs, nperseg=nperseg); _, Pm = signal.welch(meas, fs, nperseg=nperseg)
    return dict(f=f, Psim=Ps, Pmeas=Pm, f_peak_sim=float(f[np.argmax(Ps)]), f_peak_meas=float(f[np.argmax(Pm)]),
                log_spectral_distance=float(np.sqrt(np.mean((10 * np.log10(Ps + 1e-30) - 10 * np.log10(Pm + 1e-30)) ** 2))))


def split_calibration_validation(sdn, frac_cal=0.5, block_days=7, seed=0):
    """Independent split of a monitoring time axis into calibration / validation BLOCKS (never mixed).
    Parameters of the model must be tuned on `cal` only; reported validation uses `val` only."""
    sdn = np.asarray(sdn)
    blocks = np.floor((sdn - sdn[0]) / block_days).astype(int)
    ub = np.unique(blocks)
    rng = np.random.default_rng(seed)
    cal_b = set(rng.choice(ub, size=int(len(ub) * frac_cal), replace=False))
    cal = np.array([b in cal_b for b in blocks])
    return cal, ~cal
