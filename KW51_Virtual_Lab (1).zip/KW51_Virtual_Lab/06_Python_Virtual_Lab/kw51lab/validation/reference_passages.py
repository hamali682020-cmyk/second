"""reference_passages.py - اجرای دو عبور مرجع Desiro با سه مدل بار (بار متحرک، VBI، جرم متحرک)"""
import time
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from ..analysis.moving_load import run_moving_load, response
from ..analysis.vbi import run_vbi
from ..analysis.moving_mass import run_moving_mass
from ..train.configurations import REFERENCE_PASSAGES


def run(labA, mb, train, veh, cache, figpath=None):
    passages = {}
    fig, axs = plt.subplots(2, 2, figsize=(11, 7))
    for ip, (name, ps) in enumerate(REFERENCE_PASSAGES.items()):
        tr = ps["track"]; v0 = ps["direction"] * ps["v0"]; g = "girderA" if tr == "B" else "girderC"; out = {}
        for mname, fn in (("بار متحرک", lambda: run_moving_load(labA, mb, train, tr, ps["x0_front"], v0, ps["a"], dt=0.002)),
                          ("VBI (پارامتر آنالوگ)", lambda: run_vbi(labA, mb, train, veh, tr, ps["x0_front"], v0, ps["a"], dt=0.002)),
                          ("جرم متحرک", lambda: run_moving_mass(labA, mb, train, tr, ps["x0_front"], v0, ps["a"], dt=0.002))):
            t0 = time.time(); rr = fn(); cost = time.time() - t0
            uz = response(mb, rr, g, 58.158, "uz", il_cache=cache[tr]); Mz = response(mb, rr, g, 58.158, "M", il_cache=cache[tr])
            acc = mb.accel_modal()[2] @ rr["qdd"]
            out[mname] = dict(min_uz_mm=float(uz.min() * 1e3), t_of_min=float(rr["t"][uz.argmin()]), max_M_kNm=float(Mz.max() / 1e3),
                              min_M_kNm=float(Mz.min() / 1e3), peak_acc=float(np.abs(acc).max()), cost_s=cost,
                              separation=bool(rr.get("separation", False)), t_end=float(rr["t"][-1]))
            axs[0, ip].plot(rr["t"], uz * 1e3, label=mname); axs[1, ip].plot(rr["t"], acc, lw=.6, label=mname)
        axs[0, ip].set_title(name[:30], fontsize=8); axs[0, ip].set_ylabel("u_z mid-span (mm)")
        axs[1, ip].set_ylabel("a aBD17Az (m/s²)"); axs[1, ip].set_xlabel("t (s)"); axs[0, ip].legend(fontsize=7)
        passages[name] = out
    fig.tight_layout()
    if figpath:
        fig.savefig(figpath, dpi=140)
    plt.close(fig)
    return passages
