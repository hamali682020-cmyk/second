"""signal_validation.py - مقایسه‌ی سری‌های زمانی شبیه‌سازی و اندازه‌گیری (شتاب/کرنش/جابه‌جایی).
توجه: داده‌ی عبور واقعی (traindata_*.mat) در فایل‌های ارسالی نبود؛ این ماژول فقط روی سیگنال مصنوعی آزمون شده است."""
import numpy as np
from . import metrics as M


def compare_signals(t, sim, meas):
    sim = np.asarray(sim); meas = np.asarray(meas)
    out = dict(rmse=M.rmse(sim, meas), nrmse=M.nrmse(sim, meas), corr=M.corrcoef(sim, meas),
               peak_diff=M.peak_difference(sim, meas), peak_dt=M.peak_time_difference(t, sim, meas))
    out["spectral"] = M.spectral_comparison(t, sim, meas)
    return out
