"""modal_validation.py - مقایسه‌ی فرکانس و شکل مود مدل با مودهای ردیابی‌شده‌ی KW51"""
import numpy as np
from ..analysis.core import match_modes

RETROFIT_START_DEFAULT = 737560            # datenum 2019-05-15  (ASSUMPTION - not stated in the supplied files)
RETROFIT_END_DEFAULT = 737698              # datenum 2019-09-30  (ASSUMPTION)


def periods(md, start=RETROFIT_START_DEFAULT, end=RETROFIT_END_DEFAULT):
    return md["sdn"] < start, md["sdn"] > end


def modal_validation(lab, md, which="pre", nmodes=60, window=0.12, start=RETROFIT_START_DEFAULT, end=RETROFIT_END_DEFAULT):
    pre, post = periods(md, start, end)
    sel = pre if which == "pre" else post
    f_fe, S = lab.fe_sensor_shapes(nmodes)
    fm = np.nanmedian(md["f"][sel], axis=0)
    res, Mc = match_modes(f_fe, S, fm, md["shapes"], window)
    rows = []
    for k, j, mcv, err in res:
        rows.append(dict(measured_mode=k + 1, f_meas=float(fm[k]), fe_mode=None if j is None else j + 1,
                         f_fe=None if j is None else float(f_fe[j]), err_pct=err, MAC=mcv))
    return rows, f_fe, Mc
