"""geometry.py - استخراج جداول هندسه از مدل (گره‌ها، المان‌ها، ابعاد کلیدی)"""
import numpy as np
from .fem_model import zarch


def nodes_table(m):
    rows = []
    for n, (x, y, z) in sorted(m.nodes.items()):
        fam = n // 1000 if n > 4 else 0
        rows.append(dict(node=n, family=fam, x=x, y=y, z=z, is_reference=int(z >= 20), has_dof=int(n in m.nidx)))
    return rows


def beams_table(m):
    rows = []
    for b, (dofs, Tm, Kl, L) in zip(m.beams, m.beam_info):
        rows.append(dict(element=b["id"], group=b["group"], node1=b["n1"], node2=b["n2"], ref_node=b["ref"] or 0,
                         section=b["sec"], material=b["mat"], length=L))
    return rows


def shells_table(m):
    return [dict(element=s["id"], thickness=s["t"], material=s["mat"], n1=s["nodes"][0], n2=s["nodes"][1],
                 n3=s["nodes"][2], n4=s["nodes"][3]) for s in m.shells]


def key_dimensions(m):
    xs = [v[0] for n, v in m.nodes.items() if n // 1000 in (101, 102) and v[2] < 20]
    ys = [v[1] for n, v in m.nodes.items() if n // 1000 in (101, 102) and v[2] < 20]
    arch = [v for n, v in m.nodes.items() if n // 1000 in (103, 104)]
    zmax = max(v[2] for v in arch)
    return dict(model_length=max(xs) - min(xs), girder_spacing=max(ys) - min(ys),
                bearing_distance=m.xb2 - m.xb1, arch_crown_z=zmax,
                arch_rise_above_girder=zmax - 0.2719, deck_plate_z=1.156, ballast_thickness=m.h_ballast,
                n_transverse_beams=len(m.xtr), n_ubeams=len(m.yu), n_x_nodes=m.N)
