"""
fem.py - هسته المان محدود (تیر تیموشنکو سه‌بعدی + پوسته چهارگرهی MITC4) و ابزار قیود.
Core FE routines: 3D Timoshenko beam, 4-node Mindlin shell (MITC4 shear, membrane, drilling stabilisation),
and a generic master/slave constraint elimination (equivalent of Stabil's `tconstr`).

DOF order per node: [ux, uy, uz, rx, ry, rz]
Units: kg, m, s, N, Pa.
"""
import numpy as np
import scipy.sparse as sp

# ----------------------------------------------------------------------------------------------
# Beam
# ----------------------------------------------------------------------------------------------
def beam_axes(p1, p2, ref=None):
    """Port of Stabil trans_beam: rows of the returned matrix are local x, y, z.
    Nz = Nx x (ref - p1);  Ny = Nz x Nx  (local y points towards the reference node).
    When the third node is 0 (not given), Stabil leaves it at the origin (0,0,0); same here."""
    ex = p2 - p1
    L = np.linalg.norm(ex)
    ex = ex / L
    if ref is None:
        ref = np.zeros(3)
    ez = np.cross(ex, ref - p1)
    ez /= np.linalg.norm(ez)
    ey = np.cross(ez, ex)
    return np.vstack([ex, ey, ez]), L


def beam_local_km(E, G, rho, A, ky, kz, Ixx, Iyy, Izz, L, rot_inertia=True):
    """12x12 local K and consistent M, line-by-line port of Stabil kelcs_beam.m"""
    K = np.zeros((12, 12))
    M = np.zeros((12, 12))

    def sK(i, j, v):
        K[i - 1, j - 1] = v; K[j - 1, i - 1] = v

    def sM(i, j, v):
        M[i - 1, j - 1] = v; M[j - 1, i - 1] = v
    phy = 12 * E * Izz / (G * A * (ky + 1e-250) * L**2)
    phz = 12 * E * Iyy / (G * A * (kz + 1e-250) * L**2)
    sK(1, 1, A * E / L); sK(7, 7, A * E / L); sK(7, 1, -A * E / L)
    sK(4, 4, Ixx * G / L); sK(10, 10, Ixx * G / L); sK(10, 4, -Ixx * G / L)
    k22 = 12 * E * Izz / (L**3 * (1 + phy)); k62 = 6 * E * Izz / (L**2 * (1 + phy))
    sK(2, 2, k22); sK(8, 8, k22); sK(8, 2, -k22)
    sK(6, 2, k62); sK(12, 2, k62); sK(8, 6, -k62); sK(12, 8, -k62)
    k66 = E * Izz / L * (4 + phy) / (1 + phy); k126 = E * Izz / L * (2 - phy) / (1 + phy)
    sK(6, 6, k66); sK(12, 12, k66); sK(12, 6, k126)
    k33 = 12 * E * Iyy / (L**3 * (1 + phz)); k95 = 6 * E * Iyy / (L**2 * (1 + phz))
    sK(3, 3, k33); sK(9, 9, k33); sK(9, 3, -k33)
    sK(9, 5, k95); sK(11, 9, k95); sK(5, 3, -k95); sK(11, 3, -k95)
    k55 = E * Iyy / L * (4 + phz) / (1 + phz); k115 = E * Iyy / L * (2 - phz) / (1 + phz)
    sK(5, 5, k55); sK(11, 11, k55); sK(11, 5, k115)

    ry = np.sqrt(Iyy / A) if rot_inertia else 0.0
    rz = np.sqrt(Izz / A) if rot_inertia else 0.0
    rAL = rho * A * L
    sM(1, 1, rAL / 3); sM(7, 7, rAL / 3); sM(7, 1, rAL / 6)
    sM(4, 4, rho * L * (Iyy + Izz) / 3); sM(10, 10, rho * L * (Iyy + Izz) / 3); sM(10, 4, rho * L * (Iyy + Izz) / 6)
    f = rAL / (1 + phy) ** 2
    m22 = f * (13 / 35 + 7 / 10 * phy + 1 / 3 * phy**2 + 6 / 5 * (rz / L) ** 2)
    m82 = f * (9 / 70 + 3 / 10 * phy + 1 / 6 * phy**2 - 6 / 5 * (rz / L) ** 2)
    m62 = f * (11 / 210 + 11 / 120 * phy + 1 / 24 * phy**2 + (1 / 10 - 1 / 2 * phy) * (rz / L) ** 2) * L
    m86 = f * (13 / 420 + 3 / 40 * phy + 1 / 24 * phy**2 - (1 / 10 - 1 / 2 * phy) * (rz / L) ** 2) * L
    m66 = f * (1 / 105 + 1 / 60 * phy + 1 / 120 * phy**2 + (2 / 15 + 1 / 6 * phy + 1 / 3 * phy**2) * (rz / L) ** 2) * L**2
    m126 = -f * (1 / 140 + 1 / 60 * phy + 1 / 120 * phy**2 + (1 / 30 + 1 / 6 * phy - 1 / 6 * phy**2) * (rz / L) ** 2) * L**2
    sM(2, 2, m22); sM(8, 8, m22); sM(8, 2, m82)
    sM(6, 2, m62); sM(12, 8, -m62); sM(8, 6, m86); sM(12, 2, -m86)
    sM(6, 6, m66); sM(12, 12, m66); sM(12, 6, m126)
    f = rAL / (1 + phz) ** 2
    m33 = f * (13 / 35 + 7 / 10 * phz + 1 / 3 * phz**2 + 6 / 5 * (ry / L) ** 2)
    m93 = f * (9 / 70 + 3 / 10 * phz + 1 / 6 * phz**2 - 6 / 5 * (ry / L) ** 2)
    m53 = -f * (11 / 210 + 11 / 120 * phz + 1 / 24 * phz**2 + (1 / 10 - 1 / 2 * phz) * (ry / L) ** 2) * L
    m95 = -f * (13 / 420 + 3 / 40 * phz + 1 / 24 * phz**2 - (1 / 10 - 1 / 2 * phz) * (ry / L) ** 2) * L
    m55 = f * (1 / 105 + 1 / 60 * phz + 1 / 120 * phz**2 + (2 / 15 + 1 / 6 * phz + 1 / 3 * phz**2) * (ry / L) ** 2) * L**2
    m115 = -f * (1 / 140 + 1 / 60 * phz + 1 / 120 * phz**2 + (1 / 30 + 1 / 6 * phz - 1 / 6 * phz**2) * (ry / L) ** 2) * L**2
    sM(3, 3, m33); sM(9, 9, m33); sM(9, 3, m93)
    sM(5, 3, m53); sM(11, 9, -m53); sM(9, 5, m95); sM(11, 3, -m95)
    sM(5, 5, m55); sM(11, 11, m55); sM(11, 5, m115)
    return K, M


def beam_matrices(p1, p2, ref, sec, mat):
    """Global 12x12 K, M and the 12x12 rotation matrix of a beam. sec=(A,ky,kz,Ixx,Iyy,Izz); mat=(E,nu,rho)"""
    R, L = beam_axes(p1, p2, ref)
    E, nu, rho = mat
    G = E / (2 * (1 + nu))
    A, ky, kz, Ixx, Iyy, Izz = sec
    Kl, Ml = beam_local_km(E, G, rho, A, ky, kz, Ixx, Iyy, Izz, L)
    Tm = np.kron(np.eye(4), R)          # global -> local
    return Tm.T @ Kl @ Tm, Tm.T @ Ml @ Tm, Tm, Kl, L


# ----------------------------------------------------------------------------------------------
# Shell : port of Stabil shell4 (bilinear membrane with incompatible modes + 4 overlaid DKT triangles)
# ----------------------------------------------------------------------------------------------
def _q_dkt(b, c, det):
    CC = np.array([[-b[1] / det / 4, -b[2] / det / 4], [-c[1] / det / 4, -c[2] / det / 4]])
    d = b**2 + c**2
    p = 6 * c / d; q = 3 * b * c / d; r = 3 * b**2 / d; s = 3 * c**2 / d; t = 6 * b / d
    ro1 = (b[0] * b[1] + c[0] * c[1]) / (b[0] ** 2 + c[0] ** 2)
    ro2 = (b[1] * b[2] + c[1] * c[2]) / (b[1] ** 2 + c[1] ** 2)
    ro3 = (b[2] * b[0] + c[2] * c[0]) / (b[2] ** 2 + c[2] ** 2)
    AA = np.zeros((2, 9))
    for i in range(2):
        e1, e2 = CC[i, 0], CC[i, 1]
        AA[i, 0] = e1 * (30 * ro2 - 114) - e2 * (30 * ro3 + 144)
        AA[i, 3] = e1 * (30 * ro1 + 144) + e2 * 30 * (ro1 + ro3 + 1)
        AA[i, 6] = -e1 * 30 * (ro1 + ro2 + 1) + e2 * (114 - 30 * ro1)
        AA[i, 1] = e1 * (c[1] * (14 - 15 * ro2) - 7 * c[2]) + e2 * (7 * c[1] - c[2] * (29 + 15 * ro3))
        AA[i, 2] = -e1 * (b[1] * (14 - 15 * ro2) - 7 * b[2]) - e2 * (7 * b[1] - b[2] * (29 + 15 * ro3))
        AA[i, 4] = e1 * (c[0] * (29 + 15 * ro1) - 7 * c[2]) + e2 * (c[0] * (22 + 15 * ro1) - c[2] * (15 * ro3 - 7))
        AA[i, 5] = -e1 * (b[0] * (29 + 15 * ro1) - 7 * b[2]) - e2 * (b[0] * (22 + 15 * ro1) - b[2] * (15 * ro3 - 7))
        AA[i, 7] = e1 * (c[0] * (15 * ro1 - 7) - c[1] * (15 * ro2 + 22)) + e2 * (7 * c[1] + c[0] * (15 * ro1 - 14))
        AA[i, 8] = -e1 * (b[0] * (15 * ro1 - 7) - b[1] * (15 * ro2 + 22)) - e2 * (7 * b[1] + b[0] * (15 * ro1 - 14))
    p1, p2, p3 = p; q1, q2, q3 = q; r1, r2, r3 = r; s1, s2, s3 = s; t1, t2, t3 = t
    G = np.zeros((10, 9))
    G[0] = [3 * p2 + 4 * p3 + AA[0, 0], 16 - 3 * s2 + 4 * s3 + AA[0, 1], 3 * q2 - 4 * q3 + AA[0, 2],
            -3 * p1 - 4 * p3 + AA[0, 3], 2 - 3 * s1 + 4 * s3 + AA[0, 4], 3 * q1 - 4 * q3 + AA[0, 5],
            3 * (p1 - p2) + AA[0, 6], 9 - 3 * (s1 + s2) + AA[0, 7], 3 * (q1 + q2) + AA[0, 8]]
    G[1] = [-4 * p2 - 3 * p3 + AA[0, 0], 16 + 4 * s2 - 3 * s3 + AA[0, 1], 3 * q3 - 4 * q2 + AA[0, 2],
            3 * (p3 - p1) + AA[0, 3], 9 - 3 * (s1 + s3) + AA[0, 4], 3 * (q1 + q3) + AA[0, 5],
            3 * p1 + 4 * p2 + AA[0, 6], 2 - 3 * s1 + 4 * s2 + AA[0, 7], 3 * q1 - 4 * q2 + AA[0, 8]]
    G[3] = [4 * (p2 - p3) - AA[0, 0], -9 - 4 * (s2 + s3) - AA[0, 1], 4 * (q2 + q3) - AA[0, 2],
            10 * p1 + 4 * p3 - AA[0, 3], 10 * s1 - 9 - 4 * s3 - AA[0, 4], 4 * q3 - 10 * q1 - AA[0, 5],
            -10 * p1 - 4 * p2 - AA[0, 6], 10 * s1 - 9 - 4 * s2 - AA[0, 7], 4 * q2 - 10 * q1 - AA[0, 8]]
    G[5] = [-3 * t2 - 4 * t3 + AA[1, 0], 3 * q2 - 4 * q3 + AA[1, 1], 16 - 3 * r2 + 4 * r3 + AA[1, 2],
            3 * t1 + 4 * t3 + AA[1, 3], 3 * q1 - 4 * q3 + AA[1, 4], 2 + 4 * r3 - 3 * r1 + AA[1, 5],
            3 * (t2 - t1) + AA[1, 6], 3 * (q1 + q2) + AA[1, 7], 9 - 3 * (r1 + r2) + AA[1, 8]]
    G[6] = [4 * t2 + 3 * t3 + AA[1, 0], 3 * q3 - 4 * q2 + AA[1, 1], 16 + 4 * r2 - 3 * r3 + AA[1, 2],
            3 * (t1 - t3) + AA[1, 3], 3 * (q1 + q3) + AA[1, 4], 9 - 3 * (r1 + r3) + AA[1, 5],
            -3 * t1 - 4 * t2 + AA[1, 6], 3 * q1 - 4 * q2 + AA[1, 7], 2 + 4 * r2 - 3 * r1 + AA[1, 8]]
    G[8] = [4 * (t3 - t2) - AA[1, 0], 4 * (q2 + q3) - AA[1, 1], -9 - 4 * (r2 + r3) - AA[1, 2],
            -10 * t1 - 4 * t3 - AA[1, 3], -10 * q1 + 4 * q3 - AA[1, 4], 10 * r1 - 9 - 4 * r3 - AA[1, 5],
            10 * t1 + 4 * t2 - AA[1, 6], -10 * q1 + 4 * q2 - AA[1, 7], 10 * r1 - 9 - 4 * r2 - AA[1, 8]]
    G[2] = -G[0]; G[4] = -G[1]; G[7] = -G[5]; G[9] = -G[6]
    G[2, 1] += 7; G[2, 4] -= 7; G[4, 1] += 7; G[4, 7] -= 7
    G[7, 2] += 7; G[7, 5] -= 7; G[9, 2] += 7; G[9, 8] -= 7
    Q = np.zeros((9, 9))
    Q[0] = (b[1] * G[0] + b[2] * G[1]) / 7
    Q[1] = (2 * b[1] * G[2] + b[2] * G[3]) / 7
    Q[2] = (b[1] * G[3] + 2 * b[2] * G[4]) / 7
    Q[3] = (c[1] * G[5] + c[2] * G[6]) / 7
    Q[4] = (2 * c[1] * G[7] + c[2] * G[8]) / 7
    Q[5] = (c[1] * G[8] + 2 * c[2] * G[9]) / 7
    Q[6] = (c[1] * G[0] + c[2] * G[1] + b[1] * G[5] + b[2] * G[6]) / 7
    Q[7] = (2 * c[1] * G[2] + c[2] * G[3] + 2 * b[1] * G[7] + b[2] * G[8]) / 7
    Q[8] = (c[1] * G[3] + 2 * c[2] * G[4] + b[1] * G[8] + 2 * b[2] * G[9]) / 7
    tmp = Q[:, [1, 4, 7]].copy()
    Q[:, [1, 4, 7]] = Q[:, [2, 5, 8]]
    Q[:, [2, 5, 8]] = -tmp
    return Q


_IT1 = [420, 140, 140, 70, 35, 70]


def _sh_t(Lc, b, c):
    Ni = np.zeros(9)
    n1 = [1, 2, 0]; n2 = [2, 0, 1]
    L = np.asarray(Lc)
    Ni[0:9:3] = L + L**2 * L[n1] + L**2 * L[n2] - L * L[n1] ** 2 - L * L[n2] ** 2
    Ni[1:9:3] = b[n1] * (L[n2] * L**2 + L[0] * L[1] * L[2] / 2) - b[n2] * (L**2 * L[n1] + L[0] * L[1] * L[2] / 2)
    Ni[2:9:3] = c[n1] * (L[n2] * L**2 + L[0] * L[1] * L[2] / 2) - c[n2] * (L**2 * L[n1] + L[0] * L[1] * L[2] / 2)
    return Ni


def _ke_dkt(Node, h, E, nu, rho):
    D = E / (12 * (1 - nu**2)) * np.array([[1, nu, 0], [nu, 1, 0], [0, 0, (1 - nu) / 2]])
    b = np.array([Node[1, 1] - Node[2, 1], Node[2, 1] - Node[0, 1], Node[0, 1] - Node[1, 1]])
    c = np.array([Node[2, 0] - Node[1, 0], Node[0, 0] - Node[2, 0], Node[1, 0] - Node[0, 0]])
    det = b[1] * c[2] - b[2] * c[1]
    XX = np.zeros((3, 3)); k = 0
    for i in range(3):
        for j in range(i, 3):
            XX[i, j] = _IT1[k] * h**3; XX[j, i] = XX[i, j]; k += 1
    Em = np.zeros((9, 9))
    for i in range(3):
        for j in range(i, 3):
            for k1 in range(3):
                for k2 in range(3):
                    ii = i * 3 + k1; jj = j * 3 + k2
                    Em[ii, jj] = D[i, j] * XX[k1, k2] / det / 840
                    Em[jj, ii] = Em[ii, jj]
    Q = _q_dkt(b, c, det)
    Ke = Q.T @ Em @ Q
    Me = np.zeros((9, 9))
    x = np.array([[4, 1, 1], [1, 4, 1], [1, 1, 4]]) / 6.0
    for g in range(3):
        Ni = _sh_t(x[:, g], b, c)
        Me += np.outer(Ni, Ni) * rho * (1 / 3) * h * det / 2
    return Ke, Me


def shell4_local(Node_lc, h, E, nu, rho):
    """Port of kelcs_shell4.m  (24x24 K and M in the element coordinate system)"""
    Dm = E * h / (1 - nu**2) * np.array([[1, nu, 0], [nu, 1, 0], [0, 0, (1 - nu) / 2]])
    g = 1 / np.sqrt(3)
    xm = [(-g, -g), (g, -g), (g, g), (-g, g)]
    J0 = np.array([0.25 * np.array([-1, 1, 1, -1]) @ Node_lc[:, :2], 0.25 * np.array([-1, -1, 1, 1]) @ Node_lc[:, :2]])
    K1 = np.zeros((8, 8)); K21 = np.zeros((4, 8)); K2 = np.zeros((4, 4)); K12 = np.zeros((8, 4))
    K = np.zeros((24, 24)); M = np.zeros((24, 24))
    uv = [0, 1, 6, 7, 12, 13, 18, 19]
    XI = np.array([-1, 1, 1, -1.0]); ET = np.array([-1, -1, 1, 1.0])
    for xi, eta in xm:
        Ni = 0.25 * (1 + XI * xi) * (1 + ET * eta)
        dxi = 0.25 * XI * (1 + ET * eta); det_ = 0.25 * ET * (1 + XI * xi)
        J = np.array([[dxi @ Node_lc[:, 0], dxi @ Node_lc[:, 1]], [det_ @ Node_lc[:, 0], det_ @ Node_lc[:, 1]]])
        dNi = np.linalg.solve(J, np.vstack([dxi, det_]))
        Bm = np.zeros((3, 8))
        Bm[0, 0::2] = dNi[0]; Bm[1, 1::2] = dNi[1]; Bm[2, 0::2] = dNi[1]; Bm[2, 1::2] = dNi[0]
        Nex = np.array([[-2 * xi, 0], [0, -2 * eta]])
        dNex = np.linalg.solve(J0, (np.linalg.det(J0) / np.linalg.det(J)) * Nex.T)
        Bex = np.zeros((3, 4))
        Bex[0, [0, 2]] = dNex[0]; Bex[1, [1, 3]] = dNex[1]; Bex[2, [0, 2]] = dNex[1]; Bex[2, [1, 3]] = dNex[0]
        dj = np.linalg.det(J)
        K1 += Bm.T @ Dm @ Bm * dj; K21 += Bex.T @ Dm @ Bm * dj
        K2 += Bex.T @ Dm @ Bex * dj; K12 += Bm.T @ Dm @ Bex * dj
        N = np.zeros((2, 8)); N[0, 0::2] = Ni; N[1, 1::2] = Ni
        M[np.ix_(uv, uv)] += N.T @ N * rho * h * dj
    K[np.ix_(uv, uv)] = K1 - K12 @ np.linalg.solve(K2, K21)
    seq = [[0, 1, 2], [0, 2, 3], [0, 1, 3], [1, 2, 3]]
    for sq in seq:
        Kt, Mt = _ke_dkt(Node_lc[sq, :], h, E, nu, rho)
        for i in range(3):
            for j in range(3):
                ri = np.arange(2, 5) + 6 * sq[i]; rj = np.arange(2, 5) + 6 * sq[j]
                K[np.ix_(ri, rj)] += Kt[3 * i:3 * i + 3, 3 * j:3 * j + 3] / 2
                M[np.ix_(ri, rj)] += Mt[3 * i:3 * i + 3, 3 * j:3 * j + 3] / 2
    kd = np.diag(K)
    mn = kd[kd != 0].min()
    for e in (5, 11, 17, 23):
        K[e, e] = mn / 1000
    return K, M


def shell4_matrices(Node, h, E, nu, rho):
    """Global 24x24 K, M of a flat Stabil shell4 (trans_shell4 with W = I for planar elements)"""
    Nx = Node[1] - Node[0]; Nx = Nx / np.linalg.norm(Nx)
    V24 = Node[3] - Node[1]; V13 = Node[2] - Node[0]
    Nz = np.cross(V13, V24); Nz /= np.linalg.norm(Nz)
    Ny = np.cross(Nz, Nx); Nx = np.cross(Ny, Nz)
    t = np.vstack([Nx / np.linalg.norm(Nx), Ny / np.linalg.norm(Ny), Nz])
    Node_lc = (Node - Node.mean(axis=0)) @ t.T
    assert np.abs(Node_lc[:, 2]).max() < 1e-9, "non-planar shell"
    Kl, Ml = shell4_local(Node_lc, h, E, nu, rho)
    T = np.kron(np.eye(8), t)
    return T.T @ Kl @ T, T.T @ Ml @ T


# ----------------------------------------------------------------------------------------------
# Constraints (master / slave elimination)
# ----------------------------------------------------------------------------------------------
def rigid_link(slave_node, master_node, d, constraints, dofs=range(6)):
    """slave = master + theta x d    (d = x_slave - x_master)
    The rotations are tied one-to-one.  Appends (slave_dof, [(coef, master_dof), ...]) entries."""
    dx, dy, dz = d
    s, m = slave_node, master_node
    eq = {
        0: [(1, (m, 0)), (dz, (m, 4)), (-dy, (m, 5))],
        1: [(1, (m, 1)), (-dz, (m, 3)), (dx, (m, 5))],
        2: [(1, (m, 2)), (dy, (m, 3)), (-dx, (m, 4))],
        3: [(1, (m, 3))],
        4: [(1, (m, 4))],
        5: [(1, (m, 5))],
    }
    for c in dofs:
        terms = [(cf, md) for cf, md in eq[c] if cf != 0]
        constraints.append(((s, c), terms))


def tconstr(constraints, dof_list):
    """Return (T, master_dofs): u_full = T @ u_master for the dofs in `dof_list`.
    `dof_list` : list of (node, comp) tuples; constraints: list of ((node,comp), [(coef,(node,comp)),..])"""
    index = {d: i for i, d in enumerate(dof_list)}
    slave = {}
    for s, terms in constraints:
        if s in slave:
            raise ValueError(f"DOF {s} constrained twice")
        slave[s] = terms
    masters = [d for d in dof_list if d not in slave]
    midx = {d: i for i, d in enumerate(masters)}
    cache = {}

    def expand(d):
        """dict master_index -> coefficient"""
        if d in cache:
            return cache[d]
        if d in midx:
            r = {midx[d]: 1.0}
        else:
            r = {}
            for cf, md in slave[d]:
                if md not in index:
                    raise KeyError(f"master DOF {md} unknown")
                for k, v in expand(md).items():
                    r[k] = r.get(k, 0.0) + cf * v
        cache[d] = r
        return r

    rows, cols, vals = [], [], []
    for d in dof_list:
        for k, v in expand(d).items():
            if v != 0.0:
                rows.append(index[d]); cols.append(k); vals.append(v)
    T = sp.csr_matrix((vals, (rows, cols)), shape=(len(dof_list), len(masters)))
    return T, masters
