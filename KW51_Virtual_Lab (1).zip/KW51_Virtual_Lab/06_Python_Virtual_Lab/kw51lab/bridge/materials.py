"""materials.py - مصالح مدل (طبق model_kw51.m، بخش MATERIALS DEFINITION)"""
def materials_table(m):
    names = {1: "فولاد (اعضای اصلی)", 2: "فولاد (ورق عرشه)", 3: "بالاست", 4: "فولاد (آویزها/مهاربند)"}
    return [dict(material=k, name=names[k], E=v[0], nu=v[1], rho=v[2]) for k, v in sorted(m.mats.items())]
