"""sections.py - مقاطع مدل (طبق model_kw51.m): A, ky, kz (Stabil: سطح برشی = k*A)، Ixx, Iyy, Izz"""
NAMES = {1: "تیر اصلی (Main girder)", 2: "قوس (Arch)", 3: "آویز مورب - میانی", 4: "مهاربند بین قوس‌ها",
         5: "تیر U طولی", 6: "تیر عرضی", 9: "آویز - اتصالات انتهایی (Id_rel, Ad_rel)", 10: "آویز با جعبه‌ی تقویتی"}
def sections_table(m):
    return [dict(section=k, name=NAMES.get(k, ""), A=v[0], ky=v[1], kz=v[2], Ixx=v[3], Iyy=v[4], Izz=v[5])
            for k, v in sorted(m.secs.items())]
