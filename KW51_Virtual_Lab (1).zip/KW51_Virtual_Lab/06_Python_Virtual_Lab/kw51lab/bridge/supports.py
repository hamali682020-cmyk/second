"""supports.py - تکیه‌گاه‌ها: گره‌های ۱..۴ در z=-0.15 m؛ اتصال صلب تا تیر اصلی؛ شرایط مرزی طبق پارامتر fixed"""
def bearings_table(m):
    rows = []
    for n in (1, 2, 3, 4):
        x, y, z = m.nodes[n]
        fixed = sorted(c for (nn, c) in m.bc_dofs if nn == n)
        rows.append(dict(bearing=f"N{n}", x=x, y=y, z=z, fixed_translations="".join("xyz"[c] for c in fixed),
                         spring_kxx=(m.p["kxx"] if (m.p["fixed"] == 0 and n in (3, 4)) else 0.0)))
    return rows
