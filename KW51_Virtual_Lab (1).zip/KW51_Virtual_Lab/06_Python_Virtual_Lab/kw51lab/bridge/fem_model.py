"""
model.py - پورت پایتون مدل اجزای محدود پل KW51 (model_kw51.m  از KU Leuven / Stabil)
Python port of the KW51 finite-element model (KU Leuven, Maes / van de Velde / Lombaert).

Geometry, sections, materials, element connectivity and all constraint equations follow the
original MATLAB file line by line.  The element formulations themselves (Stabil's `beam` and
`shell4`) are re-implemented in fem.py (Timoshenko beam / Mindlin MITC4 shell).
Units: kg, m, s.
"""
import numpy as np
import scipy.sparse as sp
from .elements import beam_matrices, shell4_matrices, rigid_link, tconstr


def zarch(x):
    return -0.0056679878 * x**2 + 0.659277672 * x + 0.341695


class KW51Model:
    def __init__(self, Es_rel=1.0, hb_rel=1.0, kxx=1e13, Id_rel=1.0, Ad_rel=1.0,
                 fixed=1, addmass=0, diags_box=(), verbose=False):
        self.p = dict(Es_rel=Es_rel, hb_rel=hb_rel, kxx=kxx, Id_rel=Id_rel, Ad_rel=Ad_rel,
                      fixed=fixed, addmass=addmass, diags_box=list(diags_box))
        self.verbose = verbose
        self.nodes = {}          # id -> (x,y,z)
        self.beams = []          # dicts
        self.shells = []         # dicts
        self._build_geometry()
        self._build_elements()
        self._assemble()
        self._constraints()

    # ------------------------------------------------------------------ geometry
    def _add(self, nid, x, y, z):
        self.nodes[int(nid)] = (float(x), float(y), float(z))

    def _build_geometry(self):
        p = self.p
        self.h_ballast = 0.6 * p["hb_rel"]
        # ---- x-coordinates (mm) -------------------------------------------------
        xn = [0, 658, 2313 / 3, 658 + 401, 2313 / 3 * 2, 2313]

        def ext(xn, steps):
            last = xn[-1]
            return xn + [last + s for s in steps]
        xn = ext(xn, [1878 * .5, 1878])
        xn = ext(xn, [3534 * .5, 3534])
        xn = ext(xn, [3533 * .5, 3533])
        xn = ext(xn, [3833 * .5, 3833])
        xn = ext(xn, [3834 / 2, 5900 - 3833, 3834])
        xn = ext(xn, [3833 * .5, 3833])
        for _ in range(3):
            xn = ext(xn, [3933 * .5, 3933])
            xn = ext(xn, [3934 * .5, 3934])
            xn = ext(xn, [3933 * .5, 3933])
        xn += [115000 / 2 + 658 - 13767 - 23400, 115000 / 2 + 658 - 13767]
        xn = np.sort(np.array(xn, float))
        xn = np.concatenate([xn, xn[-1] + (xn[-1] - xn[-2::-1])])
        xn = np.sort(np.append(xn, 115000 / 2 + 658 + 3933 / 2 + 300)) / 1000.0
        self.xn = xn
        N = len(xn)
        self.N = N
        I = np.arange(1, N + 1)
        nd = self._add

        # ---- main girders, arches ---------------------------------------------------
        nd(101000, 0, 0, 20)
        nd(102000, 0, 11.75, 20)
        for i in range(N):
            nd(101001 + i, xn[i], 0, 0.2719)
            nd(102001 + i, xn[i], 11.75, 0.2719)
        for i in range(1, N - 1):                       # arch nodes index 2..N-1 (1-based)
            nd(103001 + i, xn[i], 0, zarch(xn[i]))
            nd(104001 + i, xn[i], 11.75, zarch(xn[i]))

        def find(prefix, x):
            """node id  prefix*1000+i with coordinate x (index search on the main grid)"""
            i = int(np.argmin(abs(xn - x)))
            assert abs(xn[i] - x) < 1e-6, (prefix, x)
            return prefix * 1000 + i + 1

        self.find = find
        # ---- diagonal connection nodes ----------------------------------------------
        xdl = [658 + 10600]
        xdl += [xdl[-1] + 11500]
        for _ in range(6):
            xdl += [xdl[-1] + 11800]
        xdl += [xdl[-1] + 11500]
        xdl = np.array(xdl) / 1000.0
        xdu = [658 + 10600 + 5900]
        xdu += [xdu[-1] + 5600 + 5900]
        for _ in range(5):
            xdu += [xdu[-1] + 11800]
        xdu += [xdu[-1] + 5600 + 5900]
        xdu = np.array(xdu) / 1000.0
        ndl = np.array([105000 + find(101, x) - 101000 for x in xdl])
        ndu = np.array([find(103, x) for x in xdu])
        zdl = (80 + 693) / 1000
        for n, x in zip(ndl, xdl):
            nd(n, x, 0, zdl)
            nd(n + 1000, x, 11.75, zdl)
        self.ndl, self.ndu, self.xdl, self.xdu = ndl, ndu, xdl, xdu

        # ---- braces ----------------------------------------------------------------
        Nebr = 6
        xbr1 = 0.658 + 115 / 2 + np.array([-23400 - 13767, -13767, 13767, 13767 + 23400]) / 1000
        ybr = np.linspace(0, 11.75, Nebr)
        ybr = np.concatenate([ybr[:-1], [ybr[-1] - 0.85, ybr[-1]]])       # 7 values
        nbr = np.zeros((Nebr + 1, 4), int)
        for k in range(4):
            xk = xbr1[k]
            nbr[0, k] = find(103, xk)
            nbr[-1, k] = find(104, xk)
            zk = self.nodes[nbr[-1, k]][2]
            nbr[1:-1, k] = 107000 + k * 1000 + np.arange(1, Nebr)
            for r in range(1, Nebr):
                nd(nbr[r, k], xk, ybr[r], zk)
            nd(107000 + k * 1000, xk, 0, 20)                     # reference node
        self.nbr = nbr

        # ---- diagonals: nodes 0.8 m inside from tube ends -----------------------------
        zref = zdl
        # (index of xdl (1-based), sign, a, Lc, dxlen, H)
        low = [(1, +1, 2.383, 10.9394, 5.900, 9.2120), (2, +1, 2.252, 15.0151, 5.900, 13.8074),
               (3, +1, 2.302, 17.9606, 5.900, 16.9639), (4, +1, 2.404, 19.4585, 5.900, 18.5425),
               (5, +1, 2.404, 19.4585, 5.900, 18.5425), (6, +1, 2.395, 17.9606, 5.900, 16.9639),
               (7, +1, 2.302, 15.0151, 5.900, 13.8074), (8, +1, 2.399, 10.7806, 5.600, 9.2120),
               (2, -1, 2.399, 10.7806, 5.600, 9.2120), (3, -1, 2.302, 15.0151, 5.900, 13.8074),
               (4, -1, 2.395, 17.9606, 5.900, 16.9639), (5, -1, 2.404, 19.4585, 5.900, 18.5425),
               (6, -1, 2.404, 19.4585, 5.900, 18.5425), (7, -1, 2.302, 17.9606, 5.900, 16.9639),
               (8, -1, 2.252, 15.0151, 5.900, 13.8074), (9, -1, 2.383, 10.9394, 5.900, 9.2120)]
        ndlb = np.concatenate([ndl[:8] + 6000, ndl[1:9] + 7000])
        xdlb = np.zeros(16); zdlb = np.zeros(16)
        for k, (m, s, a, Lc, dxl, H) in enumerate(low):
            r = (a + 0.8) / Lc
            xdlb[k] = xdl[m - 1] + s * r * dxl
            zdlb[k] = zref + r * H
        up = [(1, -1, 3.484, 10.9394, 5.900, 9.2120), (2, -1, 2.741, 15.0151, 5.900, 13.8074),
              (3, -1, 2.559, 17.9606, 5.900, 16.9639), (4, -1, 2.502, 19.4585, 5.900, 18.5425),
              (5, -1, 2.4136, 19.4585, 5.900, 18.5425), (6, -1, 2.402, 17.9606, 5.900, 16.9639),
              (7, -1, 1.389, 15.0151, 5.900, 13.8074), (8, -1, 2.652, 10.7806, 5.600, 9.2120),
              (1, +1, 2.652, 10.7806, 5.600, 9.2120), (2, +1, 1.389, 15.0151, 5.900, 13.8074),
              (3, +1, 2.402, 17.9606, 5.900, 16.9639), (4, +1, 2.4136, 19.4585, 5.900, 18.5425),
              (5, +1, 2.502, 19.4585, 5.900, 18.5425), (6, +1, 2.559, 17.9606, 5.900, 16.9639),
              (7, +1, 2.741, 15.0151, 5.900, 13.8074), (8, +1, 3.484, 10.9394, 5.900, 9.2120)]
        ndub = np.concatenate([ndu + 10000, ndu + 11000])
        xdub = np.zeros(16); zdub = np.zeros(16)
        for k, (m, s, a, Lc, dxl, H) in enumerate(up):
            r = (a + 0.8) / Lc
            xdub[k] = xdu[m - 1] + s * r * dxl
            zdub[k] = zarch(xdu[m - 1]) - r * H
        for k in range(16):
            nd(ndlb[k], xdlb[k], 0, zdlb[k]); nd(ndlb[k] + 4000, xdlb[k], 11.75, zdlb[k])
            nd(ndub[k], xdub[k], 0, zdub[k]); nd(ndub[k] + 4000, xdub[k], 11.75, zdub[k])
        nd(111000, 0, 0, 20); nd(115000, 0, 11.75, 20)
        nd(113000, 0, 0, 20); nd(117000, 0, 11.75, 20)
        self.ndlb, self.ndub = ndlb, ndub

        # ---- U-shaped longitudinal beams --------------------------------------------
        yu = (11750 / 2 - 375 - 5 * 750 + np.arange(0, 750 * 11 + 1, 750)) / 1000.0
        self.yu = yu
        for k, y in enumerate(yu, start=1):
            nd(121000 + k * 1000, 0, y, 20)
            for i in range(N):
                nd(121000 + k * 1000 + i + 1, xn[i], y, 1.011)

        # ---- transverse beams -------------------------------------------------------
        xt = [0, 2313]
        for s in [1878, 3534, 3533, 3833, 3834, 3833]:
            xt.append(xt[-1] + s)
        for _ in range(3):
            for s in [3933, 3934, 3933]:
                xt.append(xt[-1] + s)
        xt = np.array(xt, float)
        xt = np.concatenate([xt, xt[-1] + (xt[-1] - xt[-2::-1])]) / 1000.0
        self.xtr = xt
        ytr = np.concatenate([[0], yu, [11.75]])
        self.ytr = ytr
        for c in range(len(xt)):
            for r in range(14):
                nd(140000 + (c + 1) * 1000 + (r + 1), xt[c], ytr[r], 0.2539)
            nd(140000 + (c + 1) * 1000, xt[c], 0, 20)

        # ---- plates & ballast nodes ---------------------------------------------------
        yp = np.concatenate([[0, 5.875 - 5.076], (11750 / 2 - 375 - 5 * 750 + np.arange(0, 750 * 11 + 1, 750)) / 1000.0,
                             [5.875 + 5.076, 11.75]])
        self.yp = yp
        zp = 1.156
        zb = zp + self.h_ballast / 2
        for i in range(N):
            nd(181000 + i + 1, xn[i], yp[0], zp)
            nd(182000 + i + 1, xn[i], yp[1], zp)
        for k in range(3, len(yp) - 1):                      # MATLAB ind1 = 3 .. len-2
            y = yp[k - 1]
            for i in range(N):
                nd(180000 + k * 1000 + i + 1, xn[i], y - 0.16, zp)
                nd(180500 + k * 1000 + i + 1, xn[i], y + 0.16, zp)
        for i in range(N):
            nd(180000 + (len(yp) - 1) * 1000 + i + 1, xn[i], yp[-2], zp)
            nd(180000 + len(yp) * 1000 + i + 1, xn[i], yp[-1], zp)
        for i in range(N):
            nd(282000 + i + 1, xn[i], yp[1], zb)
        for k in range(3, len(yp) - 1):
            y = yp[k - 1]
            for i in range(N):
                nd(280000 + k * 1000 + i + 1, xn[i], y - 0.16, zb)
                nd(280500 + k * 1000 + i + 1, xn[i], y + 0.16, zb)
        for i in range(N):
            nd(280000 + (len(yp) - 1) * 1000 + i + 1, xn[i], yp[-2], zb)

        # ---- bearings ----------------------------------------------------------------
        xb1 = 1.059
        xb2 = (115000 + 658 - 401) / 1000
        nd(1, xb1, 0, -0.15); nd(2, xb1, 11.75, -0.15)
        nd(3, xb2, 0, -0.15); nd(4, xb2, 11.75, -0.15)
        self.xb1, self.xb2 = xb1, xb2

    # ------------------------------------------------------------------ elements
    def _build_elements(self):
        p = self.p
        Es = 200e9 * p["Es_rel"]
        self.mats = {1: (Es, .3, 7850.), 2: (Es, .3, 7850.), 3: (550e6, .3, 1700.), 4: (Es, .3, 7850.)}
        Id, Ad = p["Id_rel"], p["Ad_rel"]
        self.secs = {            # A ky kz Ixx Iyy Izz
            1: (7.688e-2, 2.93, 1.91, 1.010e-4, 1.440e-3, 1.010e-2),
            2: (2.097e-1, 2.04, 2.84, 6.610e-2, 3.790e-2, 5.430e-2),
            3: (2.089e-2, 2.35, 2.30, 5.960e-4, 3.840e-4, 3.760e-4),
            4: (3.289e-2, 2.00, 2.00, 5.770e-3, 2.880e-3, 2.880e-3),
            5: (1.339e-2, 2.21, 2.68, 3.060e-4, 1.640e-4, 2.900e-4),
            6: (5.244e-2, 2.65, 2.08, 2.760e-5, 9.010e-4, 5.630e-3),
            9: (2.089e-2 * Ad, 2.35, 2.30, 5.960e-4, 3.840e-4 * Id, 3.760e-4),
            10: (2.089e-2 * 0.94, 2.35, 2.30, 5.960e-4, 3.840e-4 * 0.085, 3.760e-4)}
        N = self.N
        B = self.beams
        add = lambda eid, sec, mat, n1, n2, ref, grp: B.append(
            dict(id=int(eid), sec=sec, mat=mat, n1=int(n1), n2=int(n2), ref=(int(ref) if ref else None), group=grp))
        for i in range(1, N):
            add(101000 + i, 1, 1, 101000 + i, 101001 + i, 101000, "girderA")
            add(102000 + i, 1, 1, 102000 + i, 102001 + i, 102000, "girderC")
        for i in range(2, N - 1):
            add(103000 + i, 2, 1, 103000 + i, 103001 + i, 101000, "archA")
            add(104000 + i, 2, 1, 104000 + i, 104001 + i, 102000, "archC")
        # diagonals
        ndl, ndu, ndlb, ndub = self.ndl, self.ndu, self.ndlb, self.ndub
        ndm = np.column_stack([ndl[[0, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 8]], ndlb, ndub,
                               ndu[[0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7]]])
        order = [15, 7, 14, 6, 13, 5, 12, 4, 11, 3, 10, 2, 9, 1, 8, 0]
        ndm = ndm[order]
        self.diag_nodes = ndm
        db = p["diags_box"]
        def boxed(grp, k):
            return any((d // 100 == grp) and (d - (d // 100) * 100 == k) for d in db)
        for k in range(1, 17):
            r = ndm[k - 1]
            add(105000 + (k - 1) * 3 + 1, 10 if boxed(10, k) else 9, 4, r[0], r[1], 111000, f"diagB{k}")
            add(105000 + (k - 1) * 3 + 2, 3, 1, r[1], r[2], 111000, f"diagB{k}")
            add(105000 + (k - 1) * 3 + 3, 10 if boxed(20, k) else 9, 4, r[2], r[3], 111000, f"diagB{k}")
            add(106000 + (k - 1) * 3 + 1, 10 if boxed(30, k) else 9, 4, r[0] + 1000, r[1] + 4000, 115000, f"diagA{k}")
            add(106000 + (k - 1) * 3 + 2, 3, 1, r[1] + 4000, r[2] + 4000, 115000, f"diagA{k}")
            add(106000 + (k - 1) * 3 + 3, 10 if boxed(40, k) else 9, 4, r[2] + 4000, r[3] + 1000, 115000, f"diagA{k}")
        for k in range(4):
            for j in range(6):
                add(107000 + k * 1000 + j + 1, 4, 1, self.nbr[j, k], self.nbr[j + 1, k], 107000 + k * 1000, "brace")
        for k in range(1, 13):
            for i in range(1, N):
                add(121000 + k * 1000 + i, 5, 1, 121000 + k * 1000 + i, 121000 + k * 1000 + i + 1, None, f"ubeam{k}")
        nc = len(self.xtr)
        for c in range(1, nc + 1):
            for r in range(1, 14):
                add(140000 + r * 1000 + c, 6, 1, 140000 + c * 1000 + r, 140000 + c * 1000 + r + 1, 140000 + c * 1000, "transv")
        # shells
        S = self.shells
        yp = self.yp
        def sh(eid, t, mat, nds):
            S.append(dict(id=int(eid), t=t, mat=mat, nodes=[int(n) for n in nds]))
        tp = 0.015
        for i in range(1, N):
            sh(181000 + i, tp, 2, [181000 + i, 181001 + i, 182001 + i, 182000 + i])
            sh(182000 + i, tp, 2, [182000 + i, 182001 + i, 183001 + i, 183000 + i])
        for k in range(3, len(yp) - 1):
            for i in range(1, N):
                sh(180000 + k * 1000 + i, tp, 2, [180500 + k * 1000 + i, 180501 + k * 1000 + i,
                                                  180000 + (k + 1) * 1000 + i + 1, 180000 + (k + 1) * 1000 + i])
        L = len(yp)
        for i in range(1, N):
            sh(180000 + (L - 1) * 1000 + i, tp, 2, [180000 + (L - 1) * 1000 + i, 180000 + (L - 1) * 1000 + i + 1,
                                                    180000 + L * 1000 + i + 1, 180000 + L * 1000 + i])
        hb = self.h_ballast
        for i in range(1, N):
            sh(282000 + i, hb, 3, [282000 + i, 282001 + i, 283001 + i, 283000 + i])
        for k in range(3, L - 1):
            for i in range(1, N):
                sh(280000 + k * 1000 - 500 + i, hb, 3, [280000 + k * 1000 + i + 1, 280000 + k * 1000 + i,
                                                        280500 + k * 1000 + i, 280500 + k * 1000 + i + 1])
                sh(280000 + k * 1000 + i, hb, 3, [280500 + k * 1000 + i, 280500 + k * 1000 + i + 1,
                                                  280000 + (k + 1) * 1000 + i + 1, 280000 + (k + 1) * 1000 + i])

    # ------------------------------------------------------------------ assembly
    def _assemble(self):
        used = set()
        for b in self.beams:
            used.update([b["n1"], b["n2"]])
        for s in self.shells:
            used.update(s["nodes"])
        used.update([1, 2, 3, 4])
        self.node_ids = np.array(sorted(used))
        self.nidx = {int(n): i for i, n in enumerate(self.node_ids)}
        # bearings have only translational dofs
        self.dof_list = []
        for n in self.node_ids:
            for c in range(6):
                if n <= 4 and c >= 3:
                    continue
                self.dof_list.append((int(n), c))
        self.ndof = len(self.dof_list)
        self.dofi = {d: i for i, d in enumerate(self.dof_list)}
        rows, cols, kv, mv = [], [], [], []

        def put(dofs, Ke, Me):
            r, c = np.meshgrid(dofs, dofs, indexing="ij")
            rows.append(r.ravel()); cols.append(c.ravel())
            kv.append(Ke.ravel()); mv.append(Me.ravel())

        self.beam_info = []
        for b in self.beams:
            p1 = np.array(self.nodes[b["n1"]]); p2 = np.array(self.nodes[b["n2"]])
            ref = np.array(self.nodes[b["ref"]]) if b["ref"] else None
            Kg, Mg, Tm, Kl, L = beam_matrices(p1, p2, ref, self.secs[b["sec"]], self.mats[b["mat"]])
            dofs = np.array([self.dofi[(b["n1"], c)] for c in range(6)] + [self.dofi[(b["n2"], c)] for c in range(6)])
            put(dofs, Kg, Mg)
            self.beam_info.append((dofs, Tm, Kl, L))
        cache = {}
        for s in self.shells:
            xyz = np.array([self.nodes[n] for n in s["nodes"]])
            E, nu, rho = self.mats[s["mat"]]
            key = (tuple(np.round(xyz - xyz[0], 6).ravel()), s["t"], s["mat"])
            if key not in cache:
                cache[key] = shell4_matrices(xyz, s["t"], E, nu, rho)
            Ke, Me = cache[key]
            dofs = np.array([self.dofi[(n, c)] for n in s["nodes"] for c in range(6)])
            put(dofs, Ke, Me)
        r = np.concatenate(rows); c = np.concatenate(cols)
        self.K = sp.csr_matrix((np.concatenate(kv), (r, c)), shape=(self.ndof, self.ndof))
        self.M = sp.csr_matrix((np.concatenate(mv), (r, c)), shape=(self.ndof, self.ndof)).tolil()

        # ---- retrofit boxes (added mass)
        mbox = 333.0
        p = self.p
        if p["addmass"] == 1 or p["diags_box"]:
            nd_ = self.diag_nodes
            for k in range(16):
                sel = []
                if p["addmass"] == 1 and not p["diags_box"]:
                    sel = [("B", 1), ("B", 2), ("A", 1), ("A", 2)]
                else:
                    db = p["diags_box"]
                    for grp, side, col in [(10, "B", 1), (20, "B", 2), (30, "A", 1), (40, "A", 2)]:
                        if any((d // 100 == grp) and (d % 100 == k + 1) for d in db):
                            sel.append((side, col))
                for side, col in sel:
                    node = nd_[k, col + 0] if col == 1 else nd_[k, 2]
                    node = nd_[k, 1] if col == 1 else nd_[k, 2]
                    node = node + (4000 if side == "A" else 0)
                    for c in range(3):
                        i = self.dofi[(int(node), c)]
                        self.M[i, i] += mbox
        self.M = self.M.tocsr()

    # ------------------------------------------------------------------ constraints
    def _constraints(self):
        nodes = self.nodes
        con = []
        N, yp, xn = self.N, self.yp, self.xn
        P = lambda n: np.array(nodes[n])

        def link(slave, master, dofs=range(6)):
            rigid_link(slave, master, P(slave) - P(master), con, dofs)

        L = len(yp)
        # 1) ballast -> plates
        for k in range(2, L):
            for i in range(1, N + 1):
                if k == 2:
                    pl, ba = 182000 + i, 282000 + i
                    link(ba, pl)
                elif k == L - 1:
                    pl, ba = 180000 + (L - 1) * 1000 + i, 280000 + (L - 1) * 1000 + i
                    link(ba, pl)
                else:
                    link(280000 + k * 1000 + i, 180000 + k * 1000 + i)
                    link(280500 + k * 1000 + i, 180500 + k * 1000 + i)
        # 2.1 diagonals -> main girders
        for x, nl in zip(self.xdl, self.ndl):
            link(nl, self.find(101, x))
            link(nl + 1000, self.find(102, x))
        # 2.2 arch begin / end -> main girders
        for (gi, ai) in [(101, 103), (102, 104)]:
            for idx in (2, N - 1):
                link(ai * 1000 + idx, gi * 1000 + idx)
        # 2.3 plates -> main girders
        for i in range(1, N + 1):
            link(181000 + i, 101000 + i)
            link(196000 + i, 102000 + i)
        # 2.4 plates -> U beams
        for k in range(1, 13):
            for i in range(1, N + 1):
                m = 121000 + k * 1000 + i
                link(180000 + (k + 2) * 1000 + i, m)
                link(180500 + (k + 2) * 1000 + i, m)
        # 2.5 transverse beams -> girders / U beams
        nc = len(self.xtr)
        for c in range(1, nc + 1):
            x = self.xtr[c - 1]
            for r in range(1, 15):
                if r == 1:
                    master = self.find(101, x)
                elif r == 14:
                    master = self.find(102, x)
                else:
                    master = self.find(120 + r, x)
                link(140000 + c * 1000 + r, master)
        # 3) girders -> bearings (translations only)
        dz_bc = nodes[self.find(101, self.xb1)][2] - nodes[1][2]
        for bn, g in [(1, self.find(101, self.xb1)), (2, self.find(102, self.xb1)),
                      (3, self.find(101, self.xb2)), (4, self.find(102, self.xb2))]:
            con.append(((g, 0), [(1, (bn, 0)), (dz_bc, (g, 4))]))
            con.append(((g, 1), [(1, (bn, 1)), (-dz_bc, (g, 3))]))
            con.append(((g, 2), [(1, (bn, 2))]))
        # boundary conditions
        seldof = [(1, 0), (1, 1), (1, 2), (2, 0), (2, 2)]
        fixed = self.p["fixed"]
        seldof += [(3, 1), (3, 2)] + ([(3, 0)] if fixed == 1 else [])
        seldof += [(4, 2)] + ([(4, 0)] if fixed == 1 else [])
        self.T0, self.masters0 = tconstr(list(con), self.dof_list)       # without boundary conditions (reactions)
        for d in seldof:
            con.append((d, []))
        self.bc_dofs = seldof
        self.T, self.masters = tconstr(con, self.dof_list)
        K = self.K.tolil()
        if fixed == 0 and self.p["kxx"]:
            for d in [(3, 0), (4, 0)]:
                i = self.dofi[d]
                K[i, i] += self.p["kxx"]
        self.K = K.tocsr()
        self.Kr = (self.T.T @ self.K @ self.T).tocsc()
        self.Mr = (self.T.T @ self.M @ self.T).tocsc()
        self.nr = self.Kr.shape[0]

    # ------------------------------------------------------------------ helpers
    def dof(self, node, comp):
        return self.dofi[(int(node), comp)]

    def nearest_node(self, x, y, z=None, families=None):
        best, bd = None, 1e18
        for n, (xx, yy, zz) in self.nodes.items():
            if zz >= 20 or n <= 4:
                continue
            if families is not None and (n // 1000) not in families:
                continue
            d = (xx - x) ** 2 + (yy - y) ** 2 + (0 if z is None else (zz - z) ** 2)
            if d < bd:
                best, bd = n, d
        return best
