"""run_validation_suite.py - همه‌ی آزمون‌های اعتبارسنجی + مطالعه‌ی پارامتری  ->  05_Results/ (JSON, CSV, نمودار)"""
import os, sys, json, time, csv
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kw51lab.analysis.core import Lab, PRESETS
from kw51lab.analysis.modal import ModalBridge, modal_table
from kw51lab.analysis.moving_load import run_moving_load, response
from kw51lab.analysis.vbi import run_vbi
from kw51lab.analysis.moving_mass import run_moving_mass
from kw51lab.analysis.static import self_weight
from kw51lab.analysis.sensitivity import frequency_sensitivity, speed_sweep
from kw51lab.bridge.elements import beam_matrices, shell4_matrices
from kw51lab.data.import_data import read_train_sheet, list_sheets, load_trackedmodes
from kw51lab.train.vehicle import vehicle_from_sheet
from kw51lab.train.configurations import *
from kw51lab.validation.modal_validation import modal_validation
from kw51lab.validation import metrics

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
P = lambda *a: os.path.join(ROOT, *a)
FIG = P("05_Results/Figures"); TAB = P("05_Results/Tables"); os.makedirs(FIG, exist_ok=True); os.makedirs(TAB, exist_ok=True)
R = {}
t_all = time.time()

# ---------------------------------------------------------------- 1. elements
E, nu, rho = 2e11, .3, 7850.; A, ky, kz, Ixx, Iyy, Izz, Lb = 0.01, 2.0, 2.0, 1e-4, 1e-4, 2e-4, 5.0
K, M, *_ = beam_matrices(np.zeros(3), np.array([Lb, 0, 0.]), np.array([0, 0, 20.]), (A, ky, kz, Ixx, Iyy, Izz), (E, nu, rho))
G = E / 2 / (1 + nu); f = np.zeros(6); f[2] = 1000.
u = np.linalg.solve(K[6:, 6:], f)[2]; ex = 1000 * Lb**3 / (3 * E * Izz) + 1000 * Lb / (G * ky * A)
R["beam_cantilever_err_pct"] = 100 * (u / ex - 1)
import scipy.sparse as sp, scipy.sparse.linalg as sla
t_, n_ = 0.015, 8; h = 1.0 / n_; nid = lambda i, j: i * (n_ + 1) + j
rows, cols, vals = [], [], []
for i in range(n_):
    for j in range(n_):
        ns = [nid(i, j), nid(i + 1, j), nid(i + 1, j + 1), nid(i, j + 1)]
        Ke, _ = shell4_matrices(np.array([[k // (n_ + 1) * h, k % (n_ + 1) * h, 0] for k in ns]), t_, E, nu, rho)
        d = np.concatenate([6 * k + np.arange(6) for k in ns]); r, c = np.meshgrid(d, d, indexing="ij")
        rows.append(r.ravel()); cols.append(c.ravel()); vals.append(Ke.ravel())
Ks = sp.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(6 * (n_ + 1) ** 2,) * 2)
fixed = [6 * nid(i, j) + 2 for i in range(n_ + 1) for j in range(n_ + 1) if i in (0, n_) or j in (0, n_)] + [0, 1, 6 * nid(n_, 0) + 1, 5]
free = np.setdiff1d(np.arange(Ks.shape[0]), sorted(set(fixed))); fl = np.zeros(Ks.shape[0]); fl[6 * nid(n_ // 2, n_ // 2) + 2] = -1000.
uu = sla.spsolve(Ks[np.ix_(free, free)].tocsc(), fl[free]); w = np.zeros(Ks.shape[0]); w[free] = uu
D = E * t_**3 / 12 / (1 - nu**2); R["plate_center_err_pct"] = 100 * (w[6 * nid(n_ // 2, n_ // 2) + 2] / (-0.0116 * 1000 / D) - 1)

json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False); print("checkpoint", sorted(R)[-1], flush=True)
# ---------------------------------------------------------------- 2. bridge models
labA = Lab(**PRESETS["پس از مقاوم‌سازی (simulate_trainpassage.m)"]); labB = Lab(**PRESETS["پیش از مقاوم‌سازی (modal_analysis.m)"])
Pm = labA.ld.load_vector("B", [58.158], [1e6], 0.0, centrifugal=False); Um = labA.solve(Pm); Rr = labA.reactions(Um, Pm)
R["equilibrium_unit_load_err_pct"] = 100 * (Rr[:, 2].sum() / 1e6 - 1) if Rr[:, 2].sum() > 0 else 100 * (-Rr[:, 2].sum() / 1e6 - 1)
R["equilibrium_unit_load_sumRz_kN"] = float(Rr[:, 2].sum() / 1e3)
sw = self_weight(labA); R["self_weight_mass_t"] = sw["mass"] / 1e3; R["self_weight_Rz_err_pct"] = 100 * (sw["Rz_sum"] / sw["weight"] - 1)
R["self_weight_mid_uz_mm"] = float(sw["U"][labA.m.dofi[(101039, 2)]] * 1e3)
tab = modal_table(labA, 120); R["effective_mass_cum_120modes"] = tab["cum"][-1].tolist()

json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False); print("checkpoint", sorted(R)[-1], flush=True)
# ---------------------------------------------------------------- 3. modal vs monitoring
md = load_trackedmodes(P("00_Original_Files/KW51_Monitoring/trackedmodes.mat"))
labA_pinned = Lab(**dict(PRESETS["پس از مقاوم‌سازی (simulate_trainpassage.m)"], fixed=1, kxx=0))
for which, lab_, tabname in (("pre", labB, "pre"), ("post", labA_pinned, "post"), ("post_free_supports", labA, "post_free")):
    rows, f_fe, Mc = modal_validation(lab_, md, "pre" if which == "pre" else "post")
    ok = [r for r in rows if r["fe_mode"] is not None]
    R[f"modal_{which}"] = dict(rows=rows, mean_abs_err_1_9=float(np.mean([abs(r["err_pct"]) for r in ok[:9]])),
                               mean_abs_err_all=float(np.mean([abs(r["err_pct"]) for r in ok])),
                               min_MAC_1_9=float(min(r["MAC"] for r in ok[:9])), n_matched=len(ok))
    with open(os.path.join(TAB, f"modal_validation_{which}.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        wr = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)

json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False); print("checkpoint", sorted(R)[-1], flush=True)
# ---------------------------------------------------------------- 4. dynamics verification
mb = ModalBridge(labA, 120)
cache = {"B": labA.influence("B", 0.25), "A": labA.influence("A", 0.25)}
train = desiro_units(1)
P_ = "/".join([P("00_Original_Files/Train_Datasets"), "zenodo_conventional.xlsx"])
analog = vehicle_from_sheet(read_train_sheet(P_, "ICE2 ERRI"))
veh = vehicle_from_axles(train, analog)
R["vehicle_weight_model_vs_axle_kN"] = [float(x / 1e3) for x in veh.weight_check()]
R["vehicle_rigid_track_freqs_Hz"] = [float(x) for x in veh.natural_frequencies(on_rigid_track=True)[:6]]
# 4a slow passage: modal+correction vs direct static
x0 = 116.316
res = run_moving_load(labA, mb, train, "B", x0, -2.0, 0.0, dt=0.02)
r = response(mb, res, "girderA", 58.158, "uz", il_cache=cache["B"])
idx = np.arange(0, len(res["t"]), max(1, len(res["t"]) // 60)); qs = []
for k in idx:
    Pk = labA.ld.load_vector("B", res["xa"][k], train.axle_loads, 0.0, centrifugal=False); qs.append(labA.response(labA.solve(Pk), "girderA", 58.158, "uz"))
R["slow_modal_vs_direct_max_diff_mm"] = float(np.abs(r[idx] - np.array(qs)).max() * 1e3)
R["slow_direct_min_uz_mm"] = float(np.min(qs) * 1e3)
# 4b VBI vs moving load at slow speed
rv = run_vbi(labA, mb, train, veh, "B", x0, -4.0, 0.0, dt=0.01)
rl = run_moving_load(labA, mb, train, "B", x0, -4.0, 0.0, dt=0.01)
a_, b_ = response(mb, rv, "girderA", 58.158, "uz", il_cache=cache["B"]).min(), response(mb, rl, "girderA", 58.158, "uz", il_cache=cache["B"]).min()
R["slow_vbi_vs_movingload_pct"] = 100 * (a_ / b_ - 1)
# 4c convergence (reference passage 1)
conv = {}
for dt in (0.004, 0.002, 0.001):
    rr = run_vbi(labA, mb, train, veh, "B", x0, -27.95, -0.343, dt=dt)
    conv[f"dt={dt}"] = dict(min_uz_mm=float(response(mb, rr, "girderA", 58.158, "uz", il_cache=cache["B"]).min() * 1e3),
                            peak_acc=float(np.abs(mb.accel_modal()[2] @ rr["qdd"]).max()))
for nm in (40, 80, 120):
    mb2 = ModalBridge(labA, nm); rr = run_vbi(labA, mb2, train, veh, "B", x0, -27.95, -0.343, dt=0.002)
    conv[f"modes={nm}"] = dict(min_uz_mm=float(response(mb2, rr, "girderA", 58.158, "uz", il_cache=cache["B"]).min() * 1e3),
                               peak_acc=float(np.abs(mb2.accel_modal()[2] @ rr["qdd"]).max()))
R["convergence"] = conv

json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False); print("checkpoint", sorted(R)[-1], flush=True)
# ---------------------------------------------------------------- 5. reference passages: 3 load models
def targets(track):
    g = "girderA" if track == "B" else "girderC"
    return g
from kw51lab.validation.reference_passages import run as _run_passages
passages = _run_passages(labA, mb, train, veh, cache, os.path.join(FIG, "reference_passages_models.png"))
R["reference_passages"] = passages

json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False); print("checkpoint", sorted(R)[-1], flush=True)
# ---------------------------------------------------------------- 6. parametric study (configs x speed), moving load + VBI
cfgs = {"1 مجموعه": desiro_units(1), "2 مجموعه": desiro_units(2), "3 مجموعه": desiro_units(3),
        "3 مجموعه (جرم کل = ۱ مجموعه)": mass_normalised(desiro_units(3))}
rows = []
for cname, tr_ in cfgs.items():
    vh = vehicle_from_axles(tr_, analog) if len(tr_.axle_pos) % 4 == 0 else None
    for vk in (80, 140):
        v0 = -vk / 3.6
        for mname in ("بار متحرک", "VBI"):
            t0 = time.time()
            rr = run_moving_load(labA, mb, tr_, "B", 116.316, v0, 0.0, dt=0.004) if mname == "بار متحرک" else \
                 run_vbi(labA, mb, tr_, vh, "B", 116.316, v0, 0.0, dt=0.004)
            cost = time.time() - t0
            def peak(group, x, kind):
                s_ = response(mb, rr, group, x, kind, il_cache=cache["B"]); k = int(np.argmax(np.abs(s_)))
                return float(s_[k]), float(rr["t"][k])
            uz, tu = peak("girderA", 58.158, "uz"); Mz, tm = peak("girderA", 58.158, "M"); V, tv = peak("girderA", 5.0, "V")
            N, tn = peak("girderA", 58.158, "N"); T_, tt_ = peak("girderA", 58.158, "T")
            ei, s_ = labA.locate("girderA", 58.158)
            from kw51lab.analysis.static import strain_functional
            d_, c_ = strain_functional(labA, ei, s_, -0.4, 0.0); fvs = c_ @ mb.Phi[d_, :]
            eps = fvs @ rr["q"]; ke = int(np.argmax(np.abs(eps)))
            acc = mb.accel_modal()[2] @ rr["qdd"]; ka = int(np.argmax(np.abs(acc)))
            rows.append({"config": cname, "n_axles": len(tr_.axle_pos), "length_axles_m": tr_.length, "weight_kN": tr_.axle_loads.sum() / 1e3,
                         "speed_kmh": vk, "model": mname, "max_uz_mm": uz * 1e3, "t_uz_s": tu, "max_M_kNm": Mz / 1e3, "max_V_support_kN": V / 1e3,
                         "max_N_kN": N / 1e3, "max_T_kNm": T_ / 1e3, "max_strain_microstrain_illustrative": eps[ke] * 1e6,
                         "max_acc_aBD17Az": acc[ka], "t_acc_s": float(rr["t"][ka]), "cost_s": cost,
                         "separation": bool(rr.get("separation", False))})
for rw in rows:
    ref = next(x for x in rows if x["config"] == rw["config"] and x["speed_kmh"] == rw["speed_kmh"] and x["model"] == "بار متحرک")
    rw["uz_diff_vs_movingload_pct"] = 100 * (rw["max_uz_mm"] / ref["max_uz_mm"] - 1)
with open(os.path.join(TAB, "parametric_train_configs.csv"), "w", newline="", encoding="utf-8-sig") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)
R["parametric_rows"] = rows

json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False); print("checkpoint", sorted(R)[-1], flush=True)
# ---------------------------------------------------------------- 7. sensitivity
vals, F = frequency_sensitivity(param="hb_rel", values=(0.9, 1.0, 1.1, 1.2), nmodes=8)
R["freq_sens_hb_rel"] = dict(values=vals.tolist(), f=F.tolist())
speeds = np.arange(40, 241, 20)
sw_ = speed_sweep(labA, mb, desiro_units(1), "B", "girderA", 58.158, "uz", speeds, cache["B"], dt=0.004, direction=-1)
sw_acc = []
for vk in speeds:
    rr = run_moving_load(labA, mb, desiro_units(1), "B", 116.316, -vk / 3.6, 0.0, dt=0.004); sw_acc.append(np.abs(mb.accel_modal()[2] @ rr["qdd"]).max())
R["speed_sweep"] = dict(speeds=speeds.tolist(), peak_uz_mm=(sw_ * 1e3).tolist(), peak_acc=np.array(sw_acc).tolist())
fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
ax[0].plot(speeds, sw_ * 1e3, "o-"); ax[0].set_xlabel("speed (km/h)"); ax[0].set_ylabel("peak |u_z| mid-span A (mm)")
ax[1].plot(speeds, sw_acc, "o-"); ax[1].set_xlabel("speed (km/h)"); ax[1].set_ylabel("peak |a| aBD17Az (m/s²)")
for a in ax: a.grid(alpha=.3)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "speed_sweep.png"), dpi=140); plt.close(fig)

json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False); print("checkpoint", sorted(R)[-1], flush=True)
# ---------------------------------------------------------------- 8. dataset QC summary
qs_ = []
for sh in list_sheets(P_):
    try: v_ = vehicle_from_sheet(read_train_sheet(P_, sh)); W, Pp = v_.weight_check(); qs_.append(W / Pp)
    except Exception: pass
R["dataset_weight_ratio_min_max"] = [float(min(qs_)), float(max(qs_))]; R["dataset_n_ok"] = len(qs_)
R["runtime_s"] = time.time() - t_all
json.dump(R, open(P("05_Results/Validation_Reports/validation_results.json"), "w"), indent=1, ensure_ascii=False)
print("suite done in %.0fs" % R["runtime_s"])
for k in ("beam_cantilever_err_pct", "plate_center_err_pct", "equilibrium_unit_load_err_pct", "self_weight_Rz_err_pct",
          "slow_modal_vs_direct_max_diff_mm", "slow_vbi_vs_movingload_pct"):
    print(k, round(R[k], 4))
print("modal pre:", {k: v for k, v in R["modal_pre"].items() if k != "rows"}); print("modal post:", {k: v for k, v in R["modal_post"].items() if k != "rows"})
