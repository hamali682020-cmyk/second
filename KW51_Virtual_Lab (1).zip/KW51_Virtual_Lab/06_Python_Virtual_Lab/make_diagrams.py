"""make_diagrams.py - تولید تصاویر و جدول‌های: خط تأثیر در نقاط مختلف مسیر، نمودار برش و لنگر، پوش نیروها  ->  05_Results/"""
import os, sys, csv
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kw51lab.analysis.core import Lab, PRESETS
from kw51lab.analysis.static import envelope
from kw51lab.train.configurations import desiro_units
from kw51lab.train.axle_loads import axle_positions

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
FIG = os.path.join(ROOT, "05_Results", "Figures"); TAB = os.path.join(ROOT, "05_Results", "Tables")
lab = Lab(**PRESETS["پس از مقاوم‌سازی (simulate_trainpassage.m)"])
track = "B"; cache = lab.influence(track, 0.5); xs = cache[0]
pts = [10, 20, 30, 40, 50, 58.158, 70, 80, 90, 100, 110]
kinds = [("uz", "Vertical displacement (mm per kN)", 1e6), ("M", "Sagging moment (kN·m per kN)", 1.0),
         ("V", "Vertical shear (kN per kN)", 1.0), ("N", "Axial force, tension + (kN per kN)", 1.0)]
fig, axs = plt.subplots(4, 1, figsize=(10, 14), sharex=True)
cm = plt.cm.viridis(np.linspace(0, 1, len(pts)))
for ax, (k, lab_, fac) in zip(axs, kinds):
    table = {"x_load_m": xs}
    for c, xp in zip(cm, pts):
        _, il = lab.influence_line(track, "girderA", xp, k, cache=cache)
        ax.plot(xs, il * fac, color=c, lw=1.2, label=f"x={xp:g} m"); table[f"IL_at_x={xp:g}"] = il * fac
    ax.set_ylabel(lab_, fontsize=9); ax.grid(alpha=.3); ax.axhline(0, c="k", lw=.5)
    with open(os.path.join(TAB, f"influence_lines_girderA_trackB_{k}.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh); w.writerow(table.keys()); w.writerows(zip(*table.values()))
axs[0].legend(ncol=4, fontsize=7); axs[-1].set_xlabel("position of the unit load on track B, x (m)")
axs[0].set_title("Influence lines of main girder A (response at x = 10 … 110 m) for a unit load moving on track B")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "influence_lines_girderA_multiple_points.png"), dpi=140); plt.close(fig)

# --- shear / moment / axial diagrams along girder A for several train positions
tr = desiro_units(1); fronts = [20, 40, 58.158, 80, 100]
fig, axs = plt.subplots(3, 1, figsize=(10, 11), sharex=True)
rows = []
for f in fronts:
    P = lab.ld.load_vector(track, axle_positions(tr, f, +1), tr.axle_loads, 0.0, centrifugal=False); U = lab.solve(P)
    x, N, V, M = lab.girder_diagram(U, "A")
    axs[0].plot(x, V / 1e3, label=f"front axle at x={f:g} m"); axs[1].plot(x, M / 1e3); axs[2].plot(x, N / 1e3)
    rows += [dict(front_axle_x=f, x=a, V_kN=v / 1e3, M_kNm=m / 1e3, N_kN=n / 1e3) for a, v, m, n in zip(x, V, M, N)]
for ax, l in zip(axs, ("Vertical shear V (kN)", "Sagging moment M (kN·m)", "Axial force N (kN, tension +)")):
    ax.set_ylabel(l); ax.grid(alpha=.3); ax.axhline(0, c="k", lw=.5)
axs[0].legend(fontsize=7); axs[-1].set_xlabel("x along main girder A (m)")
axs[0].set_title("Internal-force diagrams of girder A, Desiro MS08 (12 axles) on track B, moving towards +x")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "girderA_shear_moment_axial_diagrams.png"), dpi=140); plt.close(fig)
with open(os.path.join(TAB, "girderA_internal_forces_vs_train_position.csv"), "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

# --- envelopes along both girders
fig, axs = plt.subplots(3, 2, figsize=(12, 10), sharex=True)
for j, side in enumerate(("A", "C")):
    env = envelope(lab, tr, track, +1, step=1.0, side=side)
    for i, (k, l) in enumerate((("V", "V (kN)"), ("M", "M (kN·m)"), ("N", "N (kN)"))):
        axs[i, j].fill_between(env["x"], env[k + "_min"] / 1e3, env[k + "_max"] / 1e3, alpha=.35)
        axs[i, j].plot(env["x"], env[k + "_max"] / 1e3, lw=.8); axs[i, j].plot(env["x"], env[k + "_min"] / 1e3, lw=.8)
        axs[i, j].set_ylabel(l); axs[i, j].grid(alpha=.3)
    axs[0, j].set_title(f"Envelope, girder {side} (Desiro MS08, track B)")
    with open(os.path.join(TAB, f"envelope_girder{side}_desiro_trackB.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh); w.writerow(["x_m", "V_min_kN", "V_max_kN", "M_min_kNm", "M_max_kNm", "N_min_kN", "N_max_kN"])
        for r in zip(env["x"], env["V_min"] / 1e3, env["V_max"] / 1e3, env["M_min"] / 1e3, env["M_max"] / 1e3, env["N_min"] / 1e3, env["N_max"] / 1e3):
            w.writerow(r)
for ax in axs[-1]: ax.set_xlabel("x (m)")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "envelopes_girderA_girderC.png"), dpi=140); plt.close(fig)
print("done")
