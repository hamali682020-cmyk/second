"""
app.py - آزمایشگاه مجازی پل راه‌آهن KW51  (Streamlit)
اجرا:   streamlit run kw51lab/app.py        (از پوشه‌ی بالاتر از kw51lab)
"""
import os, sys, datetime as dt
import numpy as np
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
ROOT = os.path.dirname(HERE)
from kw51lab.analysis.core import Lab, PRESETS, measured_modes, match_modes, mac
from kw51lab.train.axle_loads import wagon_train, desiro_ms08, axle_positions
from kw51lab.analysis.load_distribution import BRIDGE_LEN, track_y
from kw51lab.analysis.modal import ModalBridge, modal_table
from kw51lab.analysis.moving_load import run_moving_load, response as modal_response
from kw51lab.analysis.vbi import run_vbi
from kw51lab.analysis.moving_mass import run_moving_mass
from kw51lab.data.import_data import read_train_sheet, list_sheets
from kw51lab.train.vehicle import vehicle_from_sheet
from kw51lab.train.configurations import desiro_units, mass_normalised, vehicle_from_axles, REFERENCE_PASSAGES

st.set_page_config(page_title="آزمایشگاه مجازی KW51", layout="wide")
st.markdown("""<style>html,body,[class*="css"]{direction:rtl;text-align:right;font-family:Vazirmatn,Tahoma,sans-serif}
.stPlotlyChart{direction:ltr}</style>""", unsafe_allow_html=True)
DATA = os.path.join(ROOT, "00_Original_Files", "KW51_Monitoring", "trackedmodes.mat")
TRAIN_XLSX = os.path.join(ROOT, "00_Original_Files", "Train_Datasets", "zenodo_conventional.xlsx")


@st.cache_resource(show_spinner="در حال ساخت مدل اجزای محدود و تجزیه‌ی ماتریس سختی ...")
def get_lab(key):
    return Lab(**dict(key))


@st.cache_data(show_spinner=False)
def get_measured(path, mtime):
    return measured_modes(path)


@st.cache_data(show_spinner="محاسبه‌ی مودها ...")
def get_modal(key, n):
    lab = get_lab(key)
    f, S = lab.fe_sensor_shapes(n)
    return f, S


@st.cache_resource(show_spinner="محاسبه‌ی خطوط تأثیر (بار واحد متحرک) ...")
def get_il(key, track, step):
    return get_lab(key).influence(track, step)


# ---------------------------------------------------------------- sidebar
st.sidebar.title("تنظیمات")
preset = st.sidebar.selectbox("وضعیت مدل", list(PRESETS))
p = dict(PRESETS[preset])
with st.sidebar.expander("پارامترهای پیشرفته‌ی مدل"):
    p["hb_rel"] = st.number_input("ضخامت نسبی بالاست h_b/0.6", 0.5, 2.0, float(p["hb_rel"]), 0.01)
    p["Es_rel"] = st.number_input("مدول الاستیسیته‌ی نسبی فولاد", 0.8, 1.2, float(p["Es_rel"]), 0.01)
    p["Id_rel"] = st.number_input("ضریب I خارج از صفحه‌ی اتصال آویزها", 0.01, 2.0, float(p["Id_rel"]), 0.01)
    p["Ad_rel"] = st.number_input("ضریب سطح اتصال آویزها", 0.2, 1.5, float(p["Ad_rel"]), 0.01)
    p["fixed"] = st.selectbox("تکیه‌گاه N3/N4 در جهت x", [0, 1], index=int(p["fixed"]),
                              format_func=lambda v: "آزاد (فنر)" if v == 0 else "مقید")
    p["kxx"] = st.number_input("سختی فنر kxx (N/m)", 0.0, 1e14, float(p["kxx"]), format="%.3g")
    p["addmass"] = st.selectbox("جرم جعبه‌های مقاوم‌سازی", [0, 1], index=int(p["addmass"]))
key = tuple(sorted((k, (tuple(v) if isinstance(v, list) else v)) for k, v in p.items()))
lab = get_lab(key)

st.sidebar.markdown("---")
track = st.sidebar.radio("خط ریلی", ["B", "A"], format_func=lambda t: f"خط {t}")
direction = st.sidebar.radio("جهت حرکت", [+1, -1], format_func=lambda d: "بروکسل ← لوون" if d > 0 else "لوون ← بروکسل")
speed_kmh = st.sidebar.slider("سرعت قطار (km/h)", 20, 200, 100, 5)
v = speed_kmh / 3.6
st.sidebar.markdown("**قطار (واگن یکسان)**")
axle = st.sidebar.number_input("بار محوری (kN)", 50.0, 250.0, 110.0, 5.0)
wb = st.sidebar.number_input("فاصله‌ی محورهای یک بوژی (m)", 1.5, 3.5, 2.5, 0.1)
bs = st.sidebar.number_input("فاصله‌ی مرکز بوژی‌ها (m)", 10.0, 22.0, 19.0, 0.5)
wl = st.sidebar.number_input("فاصله‌ی مرکز واگن‌ها (m)", 20.0, 30.0, 26.4, 0.1)
n_short = st.sidebar.slider("تعداد واگن قطار کوتاه", 1, 6, 2)
n_long = st.sidebar.slider("تعداد واگن قطار بلند", 3, 14, 8)
trains = {
    f"قطار کوتاه ({n_short} واگن)": wagon_train(n_short, axle * 1e3, wb, bs, wl),
    f"قطار بلند ({n_long} واگن)": wagon_train(n_long, axle * 1e3, wb, bs, wl),
}
trains["Desiro (مرجع MATLAB)"] = desiro_ms08()

st.title("آزمایشگاه مجازی تحلیل پل راه‌آهن KW51")
st.caption("مدل: پورت پایتون مدل Stabil/KU Leuven  |  تیر + پوسته، %d گره، %d درجه‌ی آزادی (پس از قیود: %d)"
           % (len(lab.m.node_ids), lab.m.ndof, lab.m.nr))
tabs = st.tabs(["مدل", "مودال و مقایسه با پایش", "خط تأثیر", "عبور قطار", "قطار چندجرمی / VBI", "اعتبارسنجی و وضعیت"])

GROUPS = {"تیر اصلی A (y=0)": "girderA", "تیر اصلی C (y=11.75)": "girderC",
          "قوس A": "archA", "قوس C": "archC"}
for k in range(1, 13):
    GROUPS[f"تیر U شماره {k}"] = f"ubeam{k}"
KINDS = {"تغییرمکان قائم": "uz", "لنگر خمشی (کششی‌پایین +)": "M", "نیروی برشی قائم": "V", "نیروی محوری (کشش +)": "N"}
UNITS = {"uz": ("mm", 1e3), "M": ("kN·m", 1e-3), "V": ("kN", 1e-3), "N": ("kN", 1e-3)}


def line3d(groups, U=None, scale=0, nodes=None):
    xs, ys, zs = [], [], []
    for b in lab.m.beams:
        if not any(b["group"].startswith(g) for g in groups):
            continue
        pts = []
        for n in (b["n1"], b["n2"]):
            q = np.array(lab.m.nodes[n])
            if U is not None:
                q = q + scale * np.array([U[lab.m.dofi[(n, c)]] for c in range(3)])
            pts.append(q)
        xs += [pts[0][0], pts[1][0], None]; ys += [pts[0][1], pts[1][1], None]; zs += [pts[0][2], pts[1][2], None]
    return xs, ys, zs


def fig3d(U=None, scale=0.0, title=""):
    f = go.Figure()
    for name, g, col in [("تیرهای اصلی", ["girder"], "#1f77b4"), ("قوس‌ها", ["arch"], "#d62728"),
                         ("آویزها", ["diag"], "#2ca02c"), ("مهاربندها", ["brace"], "#9467bd"),
                         ("تیرهای عرضی", ["transv"], "#aaaaaa")]:
        x, y, z = line3d(g, U, scale)
        f.add_trace(go.Scatter3d(x=x, y=y, z=z, mode="lines", line=dict(color=col, width=3), name=name))
    f.update_layout(scene=dict(aspectmode="data", xaxis_title="x (m)", yaxis_title="y (m)", zaxis_title="z (m)"),
                    height=520, margin=dict(l=0, r=0, t=30, b=0), title=title)
    return f


# ---------------------------------------------------------------- tab 1: model
with tabs[0]:
    st.plotly_chart(fig3d(), width="stretch")
    c = st.columns(4)
    c[0].metric("المان تیر", len(lab.m.beams)); c[1].metric("المان پوسته", len(lab.m.shells))
    c[2].metric("DOF کل", lab.m.ndof); c[3].metric("DOF پس از قیود", lab.m.nr)
    st.markdown("پل کمان‌وتری فولادی، دهانه ≈ ۱۱۵ m، عرض ۱۲٫۴ m. عرشه: ۲ تیر اصلی، ۱۲ تیر U طولی، ۳۳ تیر عرضی، "
                "ورق ۱۵ mm و بالاست (پوسته)؛ ۱۶ آویز مورب در هر صفحه‌ی قوس و ۴ مهاربند بین قوس‌ها.")

# ---------------------------------------------------------------- tab 2: modal
with tabs[1]:
    nm = st.slider("تعداد مودها", 10, 60, 45)
    f_fe, S_fe = get_modal(key, nm)
    f_arr, Phi, _ = lab.modal(nm)
    c1, c2 = st.columns([1, 1])
    with c1:
        st.subheader("فرکانس‌های مدل")
        mode_sel = st.number_input("شماره‌ی مود برای نمایش شکل", 1, nm, 1)
        sc = st.slider("ضریب بزرگ‌نمایی", 1, 200, 40)
        U = Phi[:, mode_sel - 1]
        U = U / np.abs(U).max()
        st.plotly_chart(fig3d(U, sc, f"مود {mode_sel}: {f_fe[mode_sel-1]:.3f} Hz"), width="stretch")
    with c2:
        st.subheader("مقایسه با فرکانس‌های اندازه‌گیری‌شده (پایش ۱۵ ماهه)")
        src = DATA
        up = st.file_uploader("trackedmodes.mat (اختیاری، در صورت نبود فایل پیش‌فرض)", type="mat")
        if up is not None:
            src = "/tmp/_tracked.mat"; open(src, "wb").write(up.read())
        if os.path.exists(src):
            md = get_measured(src, os.path.getmtime(src))
            d0 = st.date_input("آغاز مقاوم‌سازی (فرض)", dt.date(2019, 5, 15))
            d1 = st.date_input("پایان مقاوم‌سازی (فرض)", dt.date(2019, 9, 30))
            o = lambda d: dt.datetime(d.year, d.month, d.day).toordinal() + 366
            pre = md["sdn"] < o(d0); post = md["sdn"] > o(d1)
            fm_pre = np.nanmedian(md["f"][pre], axis=0); fm_post = np.nanmedian(md["f"][post], axis=0)
            fm = fm_pre if "پیش" in preset else fm_post
            res, Mc = match_modes(f_fe, S_fe, fm, md["shapes"])
            rows = []
            for k, j, mcv, err in res:
                rows.append({"مود اندازه‌گیری": k + 1, "f اندازه‌گیری (Hz)": round(float(fm[k]), 3),
                             "مود مدل": None if j is None else j + 1,
                             "f مدل (Hz)": None if j is None else round(float(f_fe[j]), 3),
                             "خطا %": None if j is None else round(err, 1),
                             "MAC": None if j is None else round(mcv, 2)})
            st.dataframe(rows, width="stretch", hide_index=True)
            st.caption("توجه: برای مقایسه‌ی مودال با پایش، تکیه‌گاه N3/N4 را «مقید» انتخاب کنید (در حالت لغزنده‌ی ایده‌آل MAC چند مود بسیار پایین می‌شود؛ Validation_Log V07b).")
            kk = st.selectbox("روند زمانی مود اندازه‌گیری‌شده", list(range(1, 15)), 5)
            fg = go.Figure()
            t_dt = [dt.datetime.fromordinal(int(x) - 366) for x in md["sdn"]]
            fg.add_trace(go.Scattergl(x=t_dt, y=md["f"][:, kk - 1], mode="markers", marker=dict(size=3), name="اندازه‌گیری"))
            fg.add_hline(y=float(fm[kk - 1]), line_dash="dot", annotation_text="میانه")
            j = res[kk - 1][1]
            if j is not None:
                fg.add_hline(y=float(f_fe[j]), line_color="red", annotation_text="مدل اجزای محدود")
            fg.update_layout(height=320, yaxis_title="f (Hz)", margin=dict(l=0, r=0, t=10, b=0))
            st.plotly_chart(fg, width="stretch")
        else:
            st.info("فایل trackedmodes.mat را بارگذاری کنید.")

# ---------------------------------------------------------------- tab 3: influence lines
with tabs[2]:
    st.subheader("خط تأثیر در نقطه‌ی دلخواه")
    mode = st.radio("نوع نقطه", ["روی یک عضو (تیر/قوس)", "نقطه‌ی دلخواه روی عرشه (تغییرمکان)"], horizontal=True)
    step = 0.5
    cache = get_il(key, track, step)
    colA, colB = st.columns(2)
    if mode.startswith("روی"):
        gname = colA.selectbox("عضو", list(GROUPS))
        kname = colA.selectbox("کمیت", list(KINDS))
        xr = colB.slider("مکان x روی عضو (m)", 0.0, BRIDGE_LEN, 58.158, 0.1)
        kind = KINDS[kname]
        xs, il = lab.influence_line(track, GROUPS[gname], xr, kind, cache=cache)
        un, fac = UNITS[kind]
        title = f"خط تأثیر {kname} - {gname} در x={xr:.1f} m (بار واحد روی خط {track})"
        ylab = f"{un} به‌ازای ۱ kN"; ilplot = il * fac * 1e3
    else:
        xp = colA.slider("x نقطه (m)", 0.0, BRIDGE_LEN, 58.158, 0.1)
        yp = colB.slider("y نقطه (m)", 0.0, 11.75, 4.0, 0.05)
        xs, il, nn = lab.deck_point_il(track, xp, yp, cache=cache)
        kind = "uz"
        title = f"خط تأثیر تغییرمکان قائم گره‌ی عرشه {nn} (x={lab.m.nodes[nn][0]:.2f}, y={lab.m.nodes[nn][1]:.2f})"
        ylab = "mm به‌ازای ۱ kN"; ilplot = il * 1e6
        gname = None
    fig = go.Figure(go.Scatter(x=xs, y=ilplot, mode="lines", fill="tozeroy"))
    fig.update_layout(title=title, xaxis_title="موقعیت بار واحد x (m)", yaxis_title=ylab, height=380,
                      margin=dict(l=0, r=0, t=40, b=0))
    st.plotly_chart(fig, width="stretch")
    st.markdown("**اثر دو قطار با برهم‌نهی خط تأثیر (شبه‌استاتیکی، بدون نیروی گریز از مرکز)**")
    fig2 = go.Figure(); rows = []
    fronts = np.arange(-80, BRIDGE_LEN + 10, 0.5)
    for nme, tr in trains.items():
        if "Desiro" in nme:
            continue
        resp = np.array([sum(AL * np.interp(x, xs, il, left=0, right=0) for x, AL in
                             zip(axle_positions(tr, fx, direction), tr.axle_loads)) for fx in fronts])
        if kind == "uz":
            resp_pl = resp * 1e3 * (1 if mode.startswith("روی") else 1)
        else:
            resp_pl = resp * UNITS[kind][1]
        fig2.add_trace(go.Scatter(x=fronts, y=resp_pl, name=nme))
        rows.append({"قطار": nme, "طول (m)": round(tr.length, 1), "وزن کل (kN)": round(tr.total_weight / 1e3),
                     "بیشینه": round(float(resp_pl.max()), 3), "کمینه": round(float(resp_pl.min()), 3)})
    fig2.update_layout(xaxis_title="موقعیت محور جلویی (m)", yaxis_title="پاسخ", height=350,
                       margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(fig2, width="stretch")
    st.dataframe(rows, hide_index=True, width="stretch")

# ---------------------------------------------------------------- tab 4: train passage
with tabs[3]:
    st.subheader("عبور قطار (شبه‌استاتیکی / دینامیکی)")
    sel = st.multiselect("قطارها", list(trains), default=list(trains)[:2])
    dyn = st.checkbox("پاسخ دینامیکی (برهم‌نهی مودال، ۴۰ مود)", False)
    zeta = st.slider("میرایی مودال ζ (%)", 0.5, 5.0, 1.0, 0.5) / 100
    gname = st.selectbox("عضو مورد بررسی", list(GROUPS), key="g4")
    kname = st.selectbox("کمیت", list(KINDS), key="k4")
    xr = st.slider("مکان x (m)", 0.0, BRIDGE_LEN, 58.158, 0.1, key="x4")
    kind = KINDS[kname]; un, fac = UNITS[kind]
    results = {}
    for nme in sel:
        tr = trains[nme]
        t, front, P, U = lab.passage(tr, track, v, direction, dt=0.5 / v)
        r_qs = np.array([lab.response(U[:, i], GROUPS[gname], xr, kind) for i in range(U.shape[1])]) * fac
        r_dy = None
        if dyn:
            Ud = lab.dynamic(t, P, 40, zeta, U_qs=U)
            r_dy = np.array([lab.response(Ud[:, i], GROUPS[gname], xr, kind) for i in range(Ud.shape[1])]) * fac
        results[nme] = (t, front, P, U, r_qs, r_dy)
    if results:
        fig = go.Figure(); rows = []
        for nme, (t, front, P, U, r_qs, r_dy) in results.items():
            fig.add_trace(go.Scatter(x=t, y=r_qs, name=nme + " (شبه‌استاتیکی)"))
            if r_dy is not None:
                fig.add_trace(go.Scatter(x=t, y=r_dy, name=nme + " (دینامیکی)", line=dict(dash="dot")))
            ext = lambda r: r[np.argmax(np.abs(r))]
            row = {"قطار": nme, f"اکسترمم شبه‌استاتیکی ({un})": round(float(ext(r_qs)), 3)}
            if r_dy is not None:
                row[f"اکسترمم دینامیکی ({un})"] = round(float(ext(r_dy)), 3)
                row["ضریب دینامیکی DAF"] = round(float(ext(r_dy) / ext(r_qs)), 3)
            rows.append(row)
        fig.update_layout(title=f"{kname} - {gname} در x={xr:.1f} m، سرعت {speed_kmh} km/h", xaxis_title="زمان (s)",
                          yaxis_title=un, height=400, margin=dict(l=0, r=0, t=40, b=0))
        st.plotly_chart(fig, width="stretch")
        st.dataframe(rows, hide_index=True, width="stretch")

        st.markdown("**نمودار نیروهای داخلی در طول تیر اصلی** (برای یک لحظه‌ی دلخواه)")
        nm0 = st.selectbox("قطار", list(results), key="dg")
        t, front, P, U, *_ = results[nm0]
        side = st.radio("تیر اصلی", ["A", "C"], horizontal=True)
        i = st.slider("لحظه (شماره‌ی گام زمانی)", 0, len(t) - 1, int(np.argmin(np.abs(front - BRIDGE_LEN / 2))))
        x, N_, V_, M_ = lab.girder_diagram(U[:, i], side)
        fg = make_subplots(rows=2, cols=1, shared_xaxes=True,
                           subplot_titles=("نیروی برشی قائم V (kN)", "لنگر خمشی M (kN·m)"))
        fg.add_trace(go.Scatter(x=x, y=V_ / 1e3, line=dict(shape="hv")), 1, 1)
        fg.add_trace(go.Scatter(x=x, y=M_ / 1e3, fill="tozeroy"), 2, 1)
        for xa, AL in zip(axle_positions(trains[nm0], front[i], direction), trains[nm0].axle_loads):
            if 0 <= xa <= BRIDGE_LEN:
                fg.add_vline(x=xa, line_width=1, line_dash="dot", line_color="gray")
        fg.update_layout(height=520, showlegend=False, xaxis2_title="x (m)", margin=dict(l=0, r=0, t=30, b=0))
        st.plotly_chart(fg, width="stretch")
        R = lab.reactions(U[:, i], P[:, i])
        st.markdown("واکنش‌های تکیه‌گاهی (kN):")
        st.dataframe([{"تکیه‌گاه": f"N{k+1}", "Rx": round(R[k, 0] / 1e3, 1), "Ry": round(R[k, 1] / 1e3, 1),
                       "Rz": round(R[k, 2] / 1e3, 1)} for k in range(4)], hide_index=True)


# ---------------------------------------------------------------- tab 5: multibody train / moving mass / VBI
@st.cache_resource(show_spinner="ساخت پایه‌ی مودال ...")
def get_mb(key, n, zeta):
    return ModalBridge(get_lab(key), n, zeta)


with tabs[4]:
    st.subheader("قطار چندجرمی، جرم متحرک و اندرکنش قطار–پل (VBI)")
    st.warning("وضعیت: بار متحرک و VBI قائم (مدل صفحه‌ای چندجرمی + فنر تماس هرتز) پیاده‌سازی و راستی‌آزمایی شده‌اند. "
               "مدل ریل/تراورس/پد، ناهمواری ریل و قطارهای مفصلی پیاده‌سازی نشده‌اند. پارامترهای واگن Desiro فرضی (آنالوگ از مجموعه‌داده) است. "
               "نتایج شتاب جرم متحرک اعتبارسنجی نشده است. داده‌ی عبور واقعی برای مقایسه‌ی سری زمانی در دسترس نبود.")
    if os.path.exists(TRAIN_XLSX):
        with st.expander("کتابخانه‌ی قطارهای مجموعه‌داده‌ی Zenodo (واگن متعارف)"):
            sh = st.selectbox("قطار", list_sheets(TRAIN_XLSX), index=5)
            try:
                v_ = vehicle_from_sheet(read_train_sheet(TRAIN_XLSX, sh)); W, Pp = v_.weight_check()
                st.write(f"{len(v_.cars)} واگن، {len(v_.axle_x)} محور، طول اول‌تا‌آخر محور {v_.length_axles:.1f} m، وزن {Pp/1e3:.0f} kN، "
                         f"وزن مدل / بار محورها = {W/Pp:.4f}")
                st.dataframe([dict(car=c.name, m=round(c.m), I=round(c.I), mb=round(c.mb[0]), ks=c.sus_s[0].ks, cs=c.sus_s[0].cs,
                                   kp=c.sus_p[0].kp, cp=c.sus_p[0].cp, mw=round(c.mw[0])) for c in v_.cars], hide_index=True)
                st.caption("فرکانس‌های مودهای سیستم تعلیق روی ریل صلب (Hz): " + ", ".join(f"{x:.2f}" for x in v_.natural_frequencies(True)[:5]))
            except Exception as e:
                st.error(f"{type(e).__name__}: {e}")
    c1, c2, c3 = st.columns(3)
    nunits = c1.slider("تعداد مجموعه‌ی Desiro متصل (فرض عملیاتی)", 1, 3, 1)
    norm = c1.checkbox("حالت کنترل: جرم کل برابر یک مجموعه")
    scen = c2.selectbox("سناریوی حرکت", list(REFERENCE_PASSAGES) + ["سفارشی"])
    nm = c2.selectbox("تعداد مودهای پل", [40, 80, 120], 2)
    zt = c2.slider("میرایی مودال ζ (%)", 0.5, 3.0, 1.0, 0.5) / 100
    dt_ = c3.selectbox("گام زمانی (s)", [0.004, 0.002], 0)
    kH = c3.number_input("سختی تماس k_H (N/m) - فرض", 1e8, 1e11, 1e9, format="%.2e")
    models = st.multiselect("مدل‌ها", ["بار متحرک", "جرم متحرک", "VBI"], default=["بار متحرک", "VBI"])
    analog = st.selectbox("قطار آنالوگ برای پارامتر تعلیق (فرض)", ["ICE2 ERRI", "ICE2 DB new", "Alfa Pendular", "ICE4 measured"] if os.path.exists(TRAIN_XLSX) else ["-"])
    if scen == "سفارشی":
        ps = dict(track=track, x0_front=(BRIDGE_LEN if direction < 0 else 0.0), direction=direction, v0=v, a=0.0)
    else:
        ps = REFERENCE_PASSAGES[scen]
    if st.button("اجرای تحلیل"):
        tr_ = desiro_units(nunits)
        if norm:
            tr_ = mass_normalised(tr_)
        mb = get_mb(key, nm, zt)
        cache = get_il(key, ps["track"], 0.25)
        v0 = ps["direction"] * ps["v0"]
        gname = "girderA" if ps["track"] == "B" else "girderC"
        out = {}
        for mname in models:
            with st.spinner(f"{mname} ..."):
                if mname == "بار متحرک":
                    r_ = run_moving_load(lab, mb, tr_, ps["track"], ps["x0_front"], v0, ps["a"], dt=dt_)
                elif mname == "جرم متحرک":
                    r_ = run_moving_mass(lab, mb, tr_, ps["track"], ps["x0_front"], v0, ps["a"], dt=dt_)
                else:
                    veh_ = vehicle_from_axles(tr_, vehicle_from_sheet(read_train_sheet(TRAIN_XLSX, analog)))
                    r_ = run_vbi(lab, mb, tr_, veh_, ps["track"], ps["x0_front"], v0, ps["a"], dt=dt_, kH=kH)
                out[mname] = r_
        fg = make_subplots(rows=3, cols=1, shared_xaxes=True, subplot_titles=("تغییرمکان قائم وسط دهانه (mm)", "لنگر خمشی وسط دهانه (kN·m)", "شتاب aBD17Az (m/s²)"))
        rows = []
        for mname, r_ in out.items():
            uz = modal_response(mb, r_, gname, 58.158, "uz", il_cache=cache); Mz = modal_response(mb, r_, gname, 58.158, "M", il_cache=cache)
            ac = mb.accel_modal()[2] @ r_["qdd"]
            fg.add_trace(go.Scatter(x=r_["t"], y=uz * 1e3, name=mname), 1, 1)
            fg.add_trace(go.Scatter(x=r_["t"], y=Mz / 1e3, name=mname, showlegend=False), 2, 1)
            fg.add_trace(go.Scatter(x=r_["t"], y=ac, name=mname, showlegend=False, line=dict(width=1)), 3, 1)
            rows.append({"مدل": mname, "min u_z (mm)": round(float(uz.min() * 1e3), 3), "M: min/max (kN·m)": f"{Mz.min()/1e3:.0f} / {Mz.max()/1e3:.0f}",
                         "max |a| (m/s²)": round(float(np.abs(ac).max()), 3), "جدایی تماس": bool(r_.get("separation", False))})
        fg.update_layout(height=700, xaxis3_title="t (s)", margin=dict(l=0, r=0, t=30, b=0))
        st.plotly_chart(fg, width="stretch")
        st.dataframe(rows, hide_index=True, width="stretch")
        if "جرم متحرک" in out:
            st.caption("هشدار: شتاب و جدایی تماس در مدل جرم متحرک به هموار نبودن پخش بار روی گره‌های بالاست حساس است و معتبر نیست؛ فقط تغییرمکان را بخوانید.")
        spec = go.Figure()
        for mname, r_ in out.items():
            ac = mb.accel_modal()[2] @ r_["qdd"]; fq = np.fft.rfftfreq(len(ac), r_["t"][1] - r_["t"][0]); sp_ = np.abs(np.fft.rfft(ac))
            spec.add_trace(go.Scatter(x=fq[fq < 30], y=sp_[fq < 30], name=mname))
        spec.update_layout(title="طیف دامنه‌ی شتاب", xaxis_title="f (Hz)", height=300, margin=dict(l=0, r=0, t=30, b=0))
        st.plotly_chart(spec, width="stretch")

# ---------------------------------------------------------------- tab 6: validation
with tabs[5]:
    st.subheader("آزمون‌های اعتبارسنجی (زنده)")
    P1 = lab.ld.load_vector(track, [58.158], [1e6], 0.0, centrifugal=False)
    U1 = lab.solve(P1)
    R1 = lab.reactions(U1, P1)
    st.write(f"تعادل: مجموع واکنش‌های قائم = {R1[:,2].sum()/1e3:.2f} kN (بار اعمالی ۱۰۰۰ kN)")
    st.write("گزارش کامل: 05_Results/Validation_Reports و 08_Documentation/Validation_Log.xlsx. اجرای مجدد همه‌ی آزمون‌ها: python run_validation_suite.py")
    st.markdown("**وضعیت قابلیت‌ها:** ✅ استاتیکی/مودال/خط تأثیر/بار متحرک/VBI قائم  |  ⚠️ جرم متحرک (فقط تغییرمکان)  |  ❌ مدل ریل، قطار مفصلی، مقایسه‌ی سری زمانی با پایش (داده‌ی عبور موجود نیست)، بازتولید Octave (باید روی سیستم شما اجرا شود)")
