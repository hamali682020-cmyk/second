"""pytest - آزمون‌های خودکار هسته (اجرا:  pytest -q  در پوشه‌ی 06_Python_Virtual_Lab)"""
import os, sys
import numpy as np
import pytest
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
ROOT = os.path.dirname(os.path.dirname(HERE))
from kw51lab.analysis.core import Lab, PRESETS
from kw51lab.analysis.modal import ModalBridge
from kw51lab.analysis.moving_load import run_moving_load, response
from kw51lab.analysis.vbi import run_vbi
from kw51lab.bridge.elements import beam_matrices, shell4_matrices
from kw51lab.data.import_data import read_train_sheet, list_sheets, load_trackedmodes
from kw51lab.train.vehicle import vehicle_from_sheet
from kw51lab.train.configurations import desiro_units, vehicle_from_axles
from kw51lab.validation.modal_validation import modal_validation
from kw51lab.validation import metrics

XLSX = os.path.join(ROOT, "00_Original_Files", "Train_Datasets", "zenodo_conventional.xlsx")
MODES = os.path.join(ROOT, "00_Original_Files", "KW51_Monitoring", "trackedmodes.mat")


@pytest.fixture(scope="module")
def lab():
    return Lab(**PRESETS["پس از مقاوم‌سازی (simulate_trainpassage.m)"])


def test_beam_cantilever_timoshenko():
    E, nu = 2e11, .3; A, ky, Izz = 0.01, 2.0, 2e-4; L = 5.0
    K, *_ = beam_matrices(np.zeros(3), np.array([L, 0, 0.]), np.array([0, 0, 20.]), (A, ky, 2.0, 1e-4, 1e-4, Izz), (E, nu, 7850.))
    f = np.zeros(6); f[2] = 1000.
    u = np.linalg.solve(K[6:, 6:], f)[2]
    exact = 1000 * L**3 / (3 * E * Izz) + 1000 * L / (E / 2 / (1 + nu) * ky * A)   # Stabil: shear area = k*A
    assert abs(u / exact - 1) < 1e-6


def test_shell_rigid_body_and_symmetry():
    Ke, Me = shell4_matrices(np.array([[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0.]]), 0.015, 2e11, .3, 7850.)
    assert np.allclose(Ke, Ke.T) and np.allclose(Me, Me.T)
    rb = np.zeros(24); rb[2::6] = 1.0                              # rigid vertical translation
    assert np.abs(Ke @ rb).max() < 1e-6 * np.abs(Ke).max()
    assert abs(sum(Me[2 + 6 * i, 2 + 6 * j] for i in range(4) for j in range(4)) - 7850 * 0.015) < 1e-9


def test_dataset_parser_and_qc():
    ok, bad = 0, []
    for sh in list_sheets(XLSX):
        try:
            v = vehicle_from_sheet(read_train_sheet(XLSX, sh)); W, P = v.weight_check()
            assert abs(W / P - 1) < 1e-3
            ok += 1
        except ValueError:
            bad.append(sh)
    assert ok == 13 and bad == ["Railjet"]                         # Railjet sheet is inconsistent in the source file


def test_equilibrium_and_self_weight(lab):
    P = lab.ld.load_vector("B", [58.158], [1e6], 0.0, centrifugal=False)
    R = lab.reactions(lab.solve(P), P)
    assert abs(R[:, 2].sum() / 1e6 - 1) < 1e-4          # observed 8e-6 (round-off of the sparse LU)
    from kw51lab.analysis.static import self_weight
    sw = self_weight(lab)
    assert abs(sw["Rz_sum"] / sw["weight"] - 1) < 1e-4


def test_modal_vs_monitoring():
    labB = Lab(**PRESETS["پیش از مقاوم‌سازی (modal_analysis.m)"])
    rows, *_ = modal_validation(labB, load_trackedmodes(MODES), "pre")
    ok = [r for r in rows if r["fe_mode"] is not None]
    assert np.mean([abs(r["err_pct"]) for r in ok[:9]]) < 4.0
    assert min(r["MAC"] for r in ok[:9]) > 0.9


def test_vbi_slow_limit_equals_moving_load(lab):
    mb = ModalBridge(lab, 80)
    train = desiro_units(1)
    analog = vehicle_from_sheet(read_train_sheet(XLSX, "ICE2 ERRI"))
    veh = vehicle_from_axles(train, analog)
    cache = lab.influence("B", 0.5)
    rv = run_vbi(lab, mb, train, veh, "B", 116.316, -4.0, 0.0, dt=0.02)
    rl = run_moving_load(lab, mb, train, "B", 116.316, -4.0, 0.0, dt=0.02)
    a = response(mb, rv, "girderA", 58.158, "uz", il_cache=cache).min()
    b = response(mb, rl, "girderA", 58.158, "uz", il_cache=cache).min()
    assert abs(a / b - 1) < 0.01


def test_metrics():
    t = np.linspace(0, 1, 200); x = np.sin(2 * np.pi * 5 * t)
    assert metrics.rmse(x, x) == 0 and abs(metrics.corrcoef(x, x) - 1) < 1e-12
    assert abs(metrics.mac(np.array([1., 2, 3]), np.array([2., 4, 6])) - 1) < 1e-12
    assert abs(metrics.spectral_comparison(t, x, x)["f_peak_sim"] - 5) < 1.5
